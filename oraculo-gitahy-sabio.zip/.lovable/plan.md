
# Oráculo Gitahy Ribeiro Borges

Aplicação web em português com IA (RAG) para responder dúvidas fundamentadas exclusivamente nos documentos oficiais da GOSC.

## Visual

- Paleta: azul-marinho profundo (#0B1B3B), dourado (#C9A961), branco/marfim.
- Tipografia: Cormorant Garamond (display, serifa elegante) + Inter (corpo).
- Estilo sóbrio com detalhes maçônicos discretos (esquadro/compasso como ornamento sutil), bordas finas douradas, sombras suaves.
- Responsivo (desktop/mobile).

## Páginas

**1. Home (`/`)**
- Cabeçalho: logo + nome "Oráculo Gitahy Ribeiro Borges" + subtítulo "Deixe sua dúvida que Gitahy responde."
- Seção boas-vindas: retrato do Gitahy (imagem enviada) ao lado do texto de boas-vindas.
- Campo de pergunta grande com placeholder e 5 chips de exemplo clicáveis.
- Botão "Consultar Oráculo".
- Resposta em card elegante com: Resposta, Fundamentação (Documento/Capítulo/Artigo/Inciso), Trecho citado.
- Ações: Copiar, Exportar PDF, Compartilhar, "FAZER OUTRA PERGUNTA".
- Sidebar/rodapé: contador de consultas + histórico das últimas 10 consultas (localStorage).

**2. Admin (`/admin`)**
- Login por senha (Lovable Cloud Auth — email/senha; somente usuários com role `admin` acessam).
- Lista documentos cadastrados (nome, data, nº de chunks).
- Upload de PDF/MD (drag & drop).
- Excluir documento.
- Botão "Reindexar base" (regenera embeddings).

## Backend (Lovable Cloud)

Tabelas:
- `documents` (id, title, source_filename, created_at)
- `document_chunks` (id, document_id, chunk_index, content, embedding vector(1536), metadata jsonb com capítulo/artigo/inciso/página)
- `consultations` (id, question, answer, sources jsonb, created_at) — para contador global
- `user_roles` (padrão) com role `admin`

Server functions:
- `ask` (público): gera embedding da pergunta → busca top-5 chunks via pgvector cosine → chama Lovable AI (google/gemini-3-flash-preview) com prompt restritivo ("responda APENAS com base no contexto; se insuficiente, retorne mensagem padrão; sempre cite documento/capítulo/artigo/inciso/trecho") → retorna JSON estruturado (resposta + fontes) → registra em `consultations`.
- `uploadDocument` (admin): aceita texto MD ou PDF (extrai com pdf-parse), divide em chunks ~1000 chars com overlap 150, tenta extrair metadata (Título/Capítulo/Art./§/Inciso via regex), gera embeddings via Lovable AI Gateway (`google/gemini-embedding-001`, dims=1536), insere em lote.
- `deleteDocument` (admin)
- `reindex` (admin): regera embeddings de todos os chunks.
- `getStats`: total de consultas.

## Seed inicial

Os 5 documentos enviados (Constituição/Princípios Gerais, Regulamento Geral, Código de Ética, Código Eleitoral, Código de Procedimentos) serão incluídos no repositório (`src/data/seed/`) e carregados via script de seed acionado por botão "Carregar documentos iniciais" na área admin (primeiro acesso).

## Recursos extras

- Histórico (localStorage) com clique para revisar.
- Copiar (clipboard), Exportar PDF (jsPDF), Compartilhar (Web Share API + fallback link).
- Contador global de consultas (vindo do DB).

## Perguntas antes de implementar

1. **Senha admin**: criar fluxo de cadastro de admin via email/senha (Lovable Cloud Auth) e você define a senha no primeiro login? Ou prefere uma senha única fixa simples (menos segura)?
2. **Logo GOSC**: tentar extrair do site gosc.org.br via fetch, ou usar apenas um monograma "ⓖ" estilizado com esquadro/compasso? (Logos oficiais podem ter restrição de uso.)
3. **Imagem do Gitahy** será embarcada como asset do app na seção boas-vindas — ok?
