import { createOpenAICompatible } from "@ai-sdk/openai-compatible";

export function createLovableAiGatewayProvider(apiKey: string) {
  return createOpenAICompatible({
    name: "lovable",
    baseURL: "https://ai.gateway.lovable.dev/v1",
    headers: {
      "Lovable-API-Key": apiKey,
      "X-Lovable-AIG-SDK": "vercel-ai-sdk",
    },
  });
}

export async function embedText(input: string): Promise<number[]> {
  const apiKey = process.env.LOVABLE_API_KEY;
  if (!apiKey) throw new Error("LOVABLE_API_KEY ausente");
  const res = await fetch("https://ai.gateway.lovable.dev/v1/embeddings", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Lovable-API-Key": apiKey,
    },
    body: JSON.stringify({
      model: "google/gemini-embedding-001",
      input,
      dimensions: 1536,
    }),
  });
  if (!res.ok) {
    const t = await res.text();
    throw new Error(`Embedding falhou (${res.status}): ${t}`);
  }
  const json = (await res.json()) as { data: { embedding: number[] }[] };
  return json.data[0].embedding;
}

export async function embedBatch(inputs: string[]): Promise<number[][]> {
  const apiKey = process.env.LOVABLE_API_KEY;
  if (!apiKey) throw new Error("LOVABLE_API_KEY ausente");
  const out: number[][] = [];
  // chamadas individuais (gateway pode rejeitar batch grande); paralelizar em pequenos lotes
  const concurrency = 4;
  for (let i = 0; i < inputs.length; i += concurrency) {
    const slice = inputs.slice(i, i + concurrency);
    const embs = await Promise.all(slice.map((t) => embedText(t)));
    out.push(...embs);
  }
  return out;
}