import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import seedPrincipios from "@/data/seed/principios-gerais.md?raw";
import seedRegulamento from "@/data/seed/regulamento-geral.md?raw";
import seedEtica from "@/data/seed/codigo-de-etica.md?raw";
import seedEleitoral from "@/data/seed/codigo-eleitoral.md?raw";
import seedProcedimentos from "@/data/seed/codigo-procedimentos.md?raw";

/**
 * Quebra texto em chunks ~1000 chars com overlap ~150.
 * Tenta preservar parágrafos.
 */
function chunkText(text: string, target = 1000, overlap = 150) {
  const paragraphs = text.split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean);
  const chunks: string[] = [];
  let buf = "";
  for (const p of paragraphs) {
    if ((buf + "\n\n" + p).length > target && buf.length > 0) {
      chunks.push(buf.trim());
      const tail = buf.slice(-overlap);
      buf = tail + "\n\n" + p;
    } else {
      buf = buf ? buf + "\n\n" + p : p;
    }
  }
  if (buf.trim()) chunks.push(buf.trim());
  return chunks;
}

function extractRefs(content: string) {
  const titulo = content.match(/T[ÍI]TULO\s+[IVXLCDM\d]+[^\n]*/i)?.[0];
  const capitulo = content.match(/CAP[ÍI]TULO\s+[IVXLCDM\d]+[^\n]*/i)?.[0];
  const artigo = content.match(/Art\.?\s*\d+[ºo°]?/i)?.[0];
  const inciso = content.match(/\b[IVX]+\s*-\s*/)?.[0]?.trim();
  const paragrafo = content.match(/§\s*\d+[ºo°]?/)?.[0];
  return { titulo, capitulo, artigo, paragrafo, inciso };
}

const EMPTY_FOUNDATION = {
  documento: "",
  capitulo: "",
  artigo: "",
  inciso: "",
  trecho: "",
};

function isTemporaryDatabaseError(message: string) {
  return /\b(521|502|503|504)\b|web server is down|fetch failed|connection/i.test(message);
}

async function wait(ms: number) {
  await new Promise((resolve) => setTimeout(resolve, ms));
}

// ---------- ASK (público) ----------
export const askOracle = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ question: z.string().min(3).max(2000) }).parse(d))
  .handler(async ({ data }) => {
    const { embedText } = await import("@/lib/ai-gateway.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("LOVABLE_API_KEY ausente");

    // 1. embed da pergunta
    const queryEmb = await embedText(data.question);

    // 2. busca chunks relevantes
    let matches: any[] | null = null;
    for (let attempt = 0; attempt < 3; attempt += 1) {
      const result = await supabaseAdmin.rpc("match_chunks", {
        query_embedding: queryEmb as unknown as string,
        match_count: 6,
      });
      if (!result.error) {
        matches = result.data;
        break;
      }

      const message = result.error.message ?? "";
      if (!isTemporaryDatabaseError(message)) throw new Error(`Busca falhou: ${message}`);
      if (attempt < 2) await wait(500 * (attempt + 1));
    }

    if (!matches) {
      return {
        resposta: "",
        fundamentacao: EMPTY_FOUNDATION,
        encontrado: false,
        error: "A base de documentos está temporariamente indisponível. Tente novamente em alguns instantes.",
      };
    }

    const docIds = Array.from(new Set((matches ?? []).map((m: any) => m.document_id)));
    const { data: docs } = await supabaseAdmin
      .from("documents")
      .select("id, title")
      .in("id", docIds.length ? docIds : ["00000000-0000-0000-0000-000000000000"]);
    const docMap = new Map((docs ?? []).map((d) => [d.id, d.title]));

    const contextBlocks = (matches ?? []).map((m: any, i: number) => {
      const title = docMap.get(m.document_id) ?? "Documento";
      const meta = m.metadata || {};
      return `[FONTE ${i + 1}] Documento: ${title}\n${meta.titulo ? "Título: " + meta.titulo + "\n" : ""}${meta.capitulo ? "Capítulo: " + meta.capitulo + "\n" : ""}${meta.artigo ? "Artigo: " + meta.artigo + "\n" : ""}${meta.inciso ? "Inciso: " + meta.inciso + "\n" : ""}Trecho:\n"""${m.content}"""`;
    }).join("\n\n---\n\n");

    const systemPrompt = `Você é o Oráculo Gitahy Ribeiro Borges, assistente especializado nos documentos oficiais da Maçonaria — exclusivamente os documentos do Grande Oriente de Santa Catarina (GOSC) carregados na base de conhecimento.

REGRAS ABSOLUTAS:
1. Responda SOMENTE com base nas FONTES fornecidas abaixo. NUNCA use conhecimento externo.
2. Se as fontes NÃO contiverem fundamento suficiente, responda EXATAMENTE: "Não encontrei fundamento documental suficiente para responder esta pergunta nos regulamentos e normas atualmente cadastrados."
3. Sempre cite a fonte usada (documento, capítulo, artigo, inciso) e o trecho literal.
4. Linguagem clara, sóbria, fraterna, em português.

Retorne JSON estrito (sem markdown):
{
  "resposta": "texto da resposta",
  "fundamentacao": {
    "documento": "...",
    "capitulo": "...",
    "artigo": "...",
    "inciso": "...",
    "trecho": "..."
  },
  "encontrado": true|false
}
Se encontrado for false, "resposta" deve ser a frase padrão acima e os campos de fundamentação devem ser strings vazias.`;

    const userPrompt = `PERGUNTA: ${data.question}\n\nFONTES DISPONÍVEIS:\n\n${contextBlocks || "(nenhuma fonte recuperada)"}`;

    const aiRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Lovable-API-Key": apiKey,
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        response_format: { type: "json_object" },
      }),
    });

    if (aiRes.status === 429) throw new Error("Muitas requisições, tente novamente em instantes.");
    if (aiRes.status === 402) throw new Error("Créditos de IA esgotados no workspace.");
    if (!aiRes.ok) {
      const t = await aiRes.text();
      throw new Error(`IA falhou (${aiRes.status}): ${t}`);
    }
    const aiJson = await aiRes.json();
    const content = aiJson.choices?.[0]?.message?.content ?? "{}";
    let parsed: any;
    try {
      parsed = JSON.parse(content);
    } catch {
      parsed = {
        resposta: content,
        fundamentacao: { documento: "", capitulo: "", artigo: "", inciso: "", trecho: "" },
        encontrado: true,
      };
    }

    // registrar consulta
    await supabaseAdmin.from("consultations").insert({
      question: data.question,
      answer: parsed.resposta ?? null,
      sources: parsed.fundamentacao ?? null,
    });

    return {
      ...parsed,
      sources_raw: (matches ?? []).map((m: any) => ({
        document: docMap.get(m.document_id),
        metadata: m.metadata,
        similarity: m.similarity,
      })),
    };
  });

// ---------- STATS (público) ----------
export const getStats = createServerFn({ method: "GET" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { count: consultations } = await supabaseAdmin
    .from("consultations").select("*", { count: "exact", head: true });
  const { count: documents } = await supabaseAdmin
    .from("documents").select("*", { count: "exact", head: true });
  return { consultations: consultations ?? 0, documents: documents ?? 0 };
});

// ---------- LIST DOCS (público) ----------
export const listDocuments = createServerFn({ method: "GET" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("documents")
    .select("id, title, source_filename, chunk_count, created_at")
    .order("created_at", { ascending: false });
  if (error) throw new Error(error.message);
  return data ?? [];
});

// ---------- UPLOAD DOC (admin) ----------
export const uploadDocument = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({
      title: z.string().min(1).max(200),
      filename: z.string().max(200).optional(),
      content: z.string().min(10),
    }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId, _role: "admin",
    });
    if (!isAdmin) throw new Error("Acesso negado");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { embedBatch } = await import("@/lib/ai-gateway.server");

    const { data: doc, error: dErr } = await supabaseAdmin
      .from("documents")
      .insert({ title: data.title, source_filename: data.filename ?? null })
      .select().single();
    if (dErr) throw new Error(dErr.message);

    const chunks = chunkText(data.content);
    let lastTitulo = ""; let lastCapitulo = "";
    const metadatas = chunks.map((c) => {
      const refs = extractRefs(c);
      if (refs.titulo) lastTitulo = refs.titulo;
      if (refs.capitulo) lastCapitulo = refs.capitulo;
      return {
        titulo: refs.titulo ?? lastTitulo,
        capitulo: refs.capitulo ?? lastCapitulo,
        artigo: refs.artigo ?? "",
        inciso: refs.inciso ?? "",
        paragrafo: refs.paragrafo ?? "",
      };
    });
    const embeddings = await embedBatch(chunks);
    const rows = chunks.map((c, i) => ({
      document_id: doc.id, chunk_index: i, content: c, metadata: metadatas[i],
      embedding: embeddings[i] as unknown as string,
    }));
    for (let i = 0; i < rows.length; i += 50) {
      const { error: cErr } = await supabaseAdmin.from("document_chunks").insert(rows.slice(i, i + 50));
      if (cErr) throw new Error(cErr.message);
    }

    await supabaseAdmin.from("documents")
      .update({ chunk_count: chunks.length }).eq("id", doc.id);

    return { id: doc.id, chunks: chunks.length };
  });

// ---------- DELETE DOC (admin) ----------
export const deleteDocument = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId, _role: "admin",
    });
    if (!isAdmin) throw new Error("Acesso negado");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("documents").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ---------- SEED INICIAL (admin) - um documento por chamada ----------
export const seedInitialDocs = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ index: z.number().int().min(0).optional() }).parse(d ?? {}))
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId, _role: "admin",
    });
    if (!isAdmin) throw new Error("Acesso negado");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { embedBatch } = await import("@/lib/ai-gateway.server");

    const seeds = [
      { title: "Princípios Gerais da Maçonaria", file: "principios-gerais.md", content: seedPrincipios },
      { title: "Regulamento Geral GOSC (Lei nº 12/2003, atualizado até Lei nº 174/2026)", file: "regulamento-geral.md", content: seedRegulamento },
      { title: "Código de Ética GOSC (Lei nº 99/2010, atualizado até Lei nº 167/2025)", file: "codigo-de-etica.md", content: seedEtica },
      { title: "Código Eleitoral GOSC (Lei nº 32/2004, atualizado até Lei nº 154/2023)", file: "codigo-eleitoral.md", content: seedEleitoral },
      { title: "Código de Procedimentos GOSC (atualizado até Lei nº 174)", file: "codigo-procedimentos.md", content: seedProcedimentos },
    ];

    const startIdx = data.index ?? 0;
    // achar o próximo seed não importado a partir de startIdx
    let s: typeof seeds[number] | null = null;
    let curIdx = startIdx;
    for (let i = startIdx; i < seeds.length; i++) {
      const candidate = seeds[i];
      const { data: existing } = await supabaseAdmin
        .from("documents").select("id").eq("title", candidate.title).maybeSingle();
      if (!existing) { s = candidate; curIdx = i; break; }
    }
    if (!s) return { done: true, nextIndex: seeds.length, total: seeds.length };

    {
      const { data: doc, error: dErr } = await supabaseAdmin
        .from("documents")
        .insert({ title: s.title, source_filename: s.file })
        .select().single();
      if (dErr) throw new Error(dErr.message);

      const chunks = chunkText(s.content);
      let lastTitulo = ""; let lastCapitulo = "";
      const metadatas = chunks.map((c) => {
        const refs = extractRefs(c);
        if (refs.titulo) lastTitulo = refs.titulo;
        if (refs.capitulo) lastCapitulo = refs.capitulo;
        return {
          titulo: refs.titulo ?? lastTitulo,
          capitulo: refs.capitulo ?? lastCapitulo,
          artigo: refs.artigo ?? "",
          inciso: refs.inciso ?? "",
          paragrafo: refs.paragrafo ?? "",
        };
      });
      const embeddings = await embedBatch(chunks);
      const rows = chunks.map((c, i) => ({
        document_id: doc.id, chunk_index: i, content: c, metadata: metadatas[i],
        embedding: embeddings[i] as unknown as string,
      }));
      // inserir em lotes de 50
      for (let i = 0; i < rows.length; i += 50) {
        const { error: cErr } = await supabaseAdmin.from("document_chunks").insert(rows.slice(i, i + 50));
        if (cErr) throw new Error(cErr.message);
      }
      await supabaseAdmin.from("documents")
        .update({ chunk_count: chunks.length }).eq("id", doc.id);
      return {
        done: curIdx + 1 >= seeds.length,
        nextIndex: curIdx + 1,
        total: seeds.length,
        indexed: { title: s.title, chunks: chunks.length },
      };
    }
  });

// ---------- CHECK ROLE (autenticado) ----------
export const checkAdminRole = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase.rpc("has_role", {
      _user_id: context.userId, _role: "admin",
    });
    return { isAdmin: !!data };
  });