import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Loader2, Copy, Share2, FileDown, BookOpen, ScrollText, Sparkles } from "lucide-react";
import { askOracle, getStats } from "@/lib/oracle.functions";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { SiteHeader } from "@/components/SiteHeader";
import { toast } from "sonner";
import gitahyPortrait from "@/assets/gitahy.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Oráculo Gitahy Ribeiro Borges" },
      { name: "description", content: "Consulte normas, regulamentos e tradições maçônicas do GOSC com respostas fundamentadas nos documentos oficiais." },
      { property: "og:title", content: "Oráculo Gitahy Ribeiro Borges" },
      { property: "og:description", content: "Deixe sua dúvida que Gitahy responde." },
    ],
  }),
  component: Index,
});

const EXAMPLES = [
  "Qual o procedimento para iniciação?",
  "Como ocorre a eleição dos oficiais?",
  "Qual o quórum necessário para abertura dos trabalhos?",
  "O que determina o regulamento sobre frequência?",
  "Quais são as atribuições do Orador?",
];

type HistoryItem = { q: string; at: number };

type AnswerShape = {
  resposta: string;
  fundamentacao: { documento: string; capitulo: string; artigo: string; inciso: string; trecho: string };
  encontrado: boolean;
  error?: string;
  sources_raw?: { document?: string; metadata?: any; similarity?: number }[];
};

function Index() {
  const askFn = useServerFn(askOracle);
  const statsFn = useServerFn(getStats);
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState<AnswerShape | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const stats = useQuery({
    queryKey: ["stats"],
    queryFn: () => statsFn(),
    refetchInterval: 30_000,
  });

  useEffect(() => {
    try {
      const raw = localStorage.getItem("oraculo:hist");
      if (raw) setHistory(JSON.parse(raw));
    } catch {}
    inputRef.current?.focus();
  }, []);

  const ask = useMutation({
    mutationFn: async (q: string) => askFn({ data: { question: q } }) as Promise<AnswerShape>,
    onSuccess: (data, q) => {
      if (data.error) {
        toast.error(data.error);
        return;
      }
      setAnswer(data);
      const next = [{ q, at: Date.now() }, ...history.filter((h) => h.q !== q)].slice(0, 10);
      setHistory(next);
      localStorage.setItem("oraculo:hist", JSON.stringify(next));
      stats.refetch();
    },
    onError: (e: any) => toast.error(e?.message ?? "Falha ao consultar o Oráculo"),
  });

  function submit() {
    const q = question.trim();
    if (q.length < 3) {
      toast.error("Digite uma pergunta com pelo menos 3 caracteres.");
      return;
    }
    ask.mutate(q);
  }

  function reset() {
    setAnswer(null);
    setQuestion("");
    setTimeout(() => inputRef.current?.focus(), 50);
  }

  function copyAnswer() {
    if (!answer) return;
    const text = formatAnswerText(answer);
    navigator.clipboard.writeText(text);
    toast.success("Resposta copiada");
  }

  async function exportPdf() {
    if (!answer) return;
    const { jsPDF } = await import("jspdf");
    const doc = new jsPDF({ unit: "pt", format: "a4" });
    const margin = 48;
    const w = doc.internal.pageSize.getWidth() - margin * 2;
    let y = margin;
    doc.setFont("times", "bold");
    doc.setFontSize(16);
    doc.text("Oráculo Gitahy Ribeiro Borges", margin, y);
    y += 22;
    doc.setFont("times", "italic");
    doc.setFontSize(10);
    doc.text("Resposta fundamentada nos documentos oficiais do GOSC", margin, y);
    y += 24;
    doc.setDrawColor(201, 169, 97);
    doc.line(margin, y, margin + w, y);
    y += 18;
    doc.setFont("times", "bold");
    doc.setFontSize(12);
    doc.text("Pergunta", margin, y); y += 14;
    doc.setFont("times", "normal");
    const qLines = doc.splitTextToSize(question || history[0]?.q || "", w);
    doc.text(qLines, margin, y); y += qLines.length * 14 + 8;
    doc.setFont("times", "bold");
    doc.text("Resposta do Oráculo", margin, y); y += 14;
    doc.setFont("times", "normal");
    const rLines = doc.splitTextToSize(answer.resposta, w);
    doc.text(rLines, margin, y); y += rLines.length * 14 + 10;
    if (answer.encontrado) {
      doc.setFont("times", "bold");
      doc.text("Fundamentação", margin, y); y += 14;
      doc.setFont("times", "normal");
      const f = answer.fundamentacao;
      const lines = [
        `Documento: ${f.documento || "—"}`,
        `Capítulo: ${f.capitulo || "—"}`,
        `Artigo: ${f.artigo || "—"}`,
        `Inciso: ${f.inciso || "—"}`,
        "",
        `Trecho: ${f.trecho || ""}`,
      ];
      const fl = doc.splitTextToSize(lines.join("\n"), w);
      doc.text(fl, margin, y);
    }
    doc.save("oraculo-gitahy.pdf");
  }

  async function share() {
    if (!answer) return;
    const text = formatAnswerText(answer);
    if (navigator.share) {
      try { await navigator.share({ title: "Oráculo Gitahy", text }); } catch {}
    } else {
      navigator.clipboard.writeText(text);
      toast.success("Resposta copiada para compartilhar");
    }
  }

  return (
    <div className="min-h-screen">
      <SiteHeader />

      <main className="mx-auto max-w-6xl px-6 py-10">
        {/* Boas-vindas */}
        <section className="grid md:grid-cols-[260px_1fr] gap-8 items-center mb-12">
          <div className="mx-auto md:mx-0">
            <div className="relative">
              <div className="absolute -inset-2 gold-border rounded-md" />
              <img
                src={gitahyPortrait}
                alt="Retrato do Irmão Gitahy Ribeiro Borges"
                className="relative w-52 h-64 object-cover rounded-md shadow-lg"
              />
            </div>
          </div>
          <div>
            <h1 className="font-display text-4xl md:text-5xl font-semibold text-[color:var(--navy-deep)] leading-tight">
              Bem-vindo ao Oráculo Gitahy Ribeiro Borges
            </h1>
            <div className="gold-divider my-4 max-w-xs" />
            <p className="text-base text-[color:var(--muted-foreground)] max-w-2xl leading-relaxed">
              Este ambiente foi criado para auxiliar os irmãos na consulta das normas, regulamentos e
              tradições administrativas da Ordem. Faça sua pergunta e receba uma resposta fundamentada
              nos documentos oficiais cadastrados.
            </p>
            <p className="font-display italic text-lg text-[color:var(--gold)] mt-4">
              "Deixe sua dúvida que Gitahy responde."
            </p>
          </div>
        </section>

        {/* Caixa de pergunta */}
        <section className="bg-card rounded-lg shadow-md gold-border p-6 md:p-8">
          <label className="block font-display text-sm uppercase tracking-[0.2em] text-[color:var(--navy)] mb-3 flex items-center gap-2">
            <ScrollText className="w-4 h-4 text-[color:var(--gold)]" /> Sua consulta
          </label>
          <Textarea
            ref={inputRef}
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="Digite aqui sua dúvida..."
            rows={3}
            className="text-base resize-none border-[color:var(--gold)]/40 focus-visible:ring-[color:var(--gold)]"
            onKeyDown={(e) => {
              if ((e.metaKey || e.ctrlKey) && e.key === "Enter") submit();
            }}
          />
          <div className="mt-4 flex flex-wrap gap-2">
            {EXAMPLES.map((ex) => (
              <button
                key={ex}
                type="button"
                onClick={() => setQuestion(ex)}
                className="text-xs px-3 py-1.5 rounded-full border border-[color:var(--gold)]/40 text-[color:var(--navy)] hover:bg-[color:var(--gold)]/10 transition"
              >
                {ex}
              </button>
            ))}
          </div>
          <div className="mt-6 flex justify-between items-center">
            <p className="text-xs text-[color:var(--muted-foreground)]">
              {stats.data ? <>· {stats.data.consultations} consultas · {stats.data.documents} documentos</> : ""}
            </p>
            <Button
              size="lg"
              onClick={submit}
              disabled={ask.isPending}
              className="bg-[color:var(--navy-deep)] hover:bg-[color:var(--navy)] text-[color:var(--ivory)] font-display tracking-wide px-8"
            >
              {ask.isPending ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Consultando…</>
              ) : (
                <><Sparkles className="w-4 h-4 mr-2" /> Consultar Oráculo</>
              )}
            </Button>
          </div>
        </section>

        {/* Resposta */}
        {answer && (
          <section className="mt-8 bg-card rounded-lg shadow-md gold-border overflow-hidden">
            <header className="navy-gradient text-[color:var(--ivory)] px-6 py-4 flex items-center gap-3">
              <BookOpen className="w-5 h-5 text-[color:var(--gold)]" />
              <h2 className="font-display text-2xl">Resposta do Oráculo</h2>
            </header>
            <div className="p-6 md:p-8 space-y-6">
              <p className="text-base leading-relaxed whitespace-pre-wrap text-[color:var(--foreground)]">
                {answer.resposta}
              </p>

              {answer.encontrado && (
                <div className="bg-[color:var(--ivory)] gold-border rounded-md p-5">
                  <h3 className="font-display text-lg text-[color:var(--navy-deep)] mb-3">Fundamentação</h3>
                  <dl className="grid sm:grid-cols-2 gap-x-6 gap-y-2 text-sm">
                    <Field label="Documento" value={answer.fundamentacao.documento} />
                    <Field label="Capítulo" value={answer.fundamentacao.capitulo} />
                    <Field label="Artigo" value={answer.fundamentacao.artigo} />
                    <Field label="Inciso" value={answer.fundamentacao.inciso} />
                  </dl>
                  {answer.fundamentacao.trecho && (
                    <blockquote className="mt-4 pl-4 border-l-2 border-[color:var(--gold)] italic text-[color:var(--muted-foreground)]">
                      "{answer.fundamentacao.trecho}"
                    </blockquote>
                  )}
                </div>
              )}

              <div className="flex flex-wrap gap-2 pt-2">
                <Button variant="outline" size="sm" onClick={copyAnswer}><Copy className="w-4 h-4 mr-2" /> Copiar</Button>
                <Button variant="outline" size="sm" onClick={exportPdf}><FileDown className="w-4 h-4 mr-2" /> Exportar PDF</Button>
                <Button variant="outline" size="sm" onClick={share}><Share2 className="w-4 h-4 mr-2" /> Compartilhar</Button>
              </div>

              <div className="pt-4 border-t border-[color:var(--border)]">
                <Button
                  onClick={reset}
                  size="lg"
                  className="w-full bg-[color:var(--gold)] hover:bg-[color:var(--gold-soft)] text-[color:var(--navy-deep)] font-display tracking-[0.15em] uppercase"
                >
                  Fazer outra pergunta
                </Button>
              </div>
            </div>
          </section>
        )}

        {/* Histórico */}
        {history.length > 0 && (
          <section className="mt-10">
            <h3 className="font-display text-xl text-[color:var(--navy-deep)] mb-3">Últimas consultas</h3>
            <ul className="space-y-2">
              {history.map((h, i) => (
                <li key={i}>
                  <button
                    onClick={() => { setQuestion(h.q); inputRef.current?.focus(); }}
                    className="w-full text-left text-sm px-4 py-3 bg-card gold-border rounded hover:bg-[color:var(--gold)]/5 transition"
                  >
                    {h.q}
                  </button>
                </li>
              ))}
            </ul>
          </section>
        )}
      </main>

      <footer className="mt-16 border-t border-[color:var(--gold)]/30 bg-[color:var(--navy-deep)] text-[color:var(--ivory)]/70 text-center text-xs py-6">
        <p>Oráculo Gitahy Ribeiro Borges · Grande Oriente de Santa Catarina</p>
        <p className="mt-1 text-[color:var(--gold)]/70">Respostas fundamentadas exclusivamente nos documentos oficiais cadastrados.</p>
      </footer>
    </div>
  );
}

function Field({ label, value }: { label: string; value?: string }) {
  return (
    <div>
      <dt className="text-[10px] uppercase tracking-[0.2em] text-[color:var(--muted-foreground)]">{label}</dt>
      <dd className="text-sm text-[color:var(--navy-deep)]">{value || "—"}</dd>
    </div>
  );
}

function formatAnswerText(a: AnswerShape) {
  const f = a.fundamentacao;
  return [
    "Oráculo Gitahy Ribeiro Borges",
    "",
    a.resposta,
    "",
    a.encontrado ? "Fundamentação:" : "",
    a.encontrado ? `- Documento: ${f.documento}` : "",
    a.encontrado ? `- Capítulo: ${f.capitulo}` : "",
    a.encontrado ? `- Artigo: ${f.artigo}` : "",
    a.encontrado ? `- Inciso: ${f.inciso}` : "",
    a.encontrado && f.trecho ? `\nTrecho: "${f.trecho}"` : "",
  ].filter(Boolean).join("\n");
}
