import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  listDocuments, uploadDocument, deleteDocument, seedInitialDocs, checkAdminRole,
} from "@/lib/oracle.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { SiteHeader } from "@/components/SiteHeader";
import { toast } from "sonner";
import { Loader2, Trash2, Upload, Sparkles, LogOut } from "lucide-react";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Administração · Oráculo Gitahy" }] }),
  component: Admin,
});

function Admin() {
  const nav = useNavigate();
  const [ready, setReady] = useState(false);
  const [authed, setAuthed] = useState(false);

  const listFn = useServerFn(listDocuments);
  const checkFn = useServerFn(checkAdminRole);
  const uploadFn = useServerFn(uploadDocument);
  const deleteFn = useServerFn(deleteDocument);
  const seedFn = useServerFn(seedInitialDocs);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (!data.session) { nav({ to: "/auth" }); return; }
      checkFn().then((r: any) => {
        if (!r.isAdmin) { toast.error("Sua conta não tem acesso administrativo."); nav({ to: "/" }); return; }
        setAuthed(true); setReady(true);
      }).catch(() => { nav({ to: "/auth" }); });
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, sess) => {
      if (!sess) nav({ to: "/auth" });
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  const docs = useQuery({
    queryKey: ["admin-docs"],
    queryFn: () => listFn(),
    enabled: ready,
  });

  const [title, setTitle] = useState("");
  const [filename, setFilename] = useState("");
  const [content, setContent] = useState("");

  const upload = useMutation({
    mutationFn: () => uploadFn({ data: { title, filename, content } }),
    onSuccess: (r: any) => {
      toast.success(`Documento adicionado (${r.chunks} trechos indexados)`);
      setTitle(""); setFilename(""); setContent("");
      docs.refetch();
    },
    onError: (e: any) => toast.error(e?.message ?? "Falha no upload"),
  });

  const del = useMutation({
    mutationFn: (id: string) => deleteFn({ data: { id } }),
    onSuccess: () => { toast.success("Documento excluído"); docs.refetch(); },
    onError: (e: any) => toast.error(e?.message ?? "Erro"),
  });

  const seed = useMutation({
    mutationFn: async () => {
      let next = 0;
      let total = 0;
      let count = 0;
      while (true) {
        const r: any = await seedFn({ data: { index: next } });
        total = r.total;
        if (r.indexed) {
          count++;
          toast.message(`Indexado: ${r.indexed.title} (${r.indexed.chunks} trechos)`);
        }
        if (r.done) return { count, total };
        next = r.nextIndex;
      }
    },
    onSuccess: (r) => { toast.success(`Concluído: ${r.count} documento(s) indexado(s).`); docs.refetch(); },
    onError: (e: any) => toast.error(e?.message ?? "Erro ao carregar documentos iniciais"),
  });

  async function onFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    setFilename(f.name);
    if (!title) setTitle(f.name.replace(/\.(md|txt|pdf)$/i, ""));
    if (f.name.toLowerCase().endsWith(".pdf")) {
      toast.message("PDF detectado: extração de PDF não está disponível neste ambiente. Cole o texto do PDF na área abaixo, ou envie como .md/.txt.");
      return;
    }
    setContent(await f.text());
  }

  if (!ready || !authed) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-[color:var(--gold)]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-5xl px-6 py-10 space-y-8">
        <header className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-3xl text-[color:var(--navy-deep)]">Área Administrativa</h1>
            <p className="text-sm text-[color:var(--muted-foreground)]">Gerencie a base documental do Oráculo.</p>
          </div>
          <Button variant="outline" size="sm" onClick={async () => { await supabase.auth.signOut(); nav({ to: "/" }); }}>
            <LogOut className="w-4 h-4 mr-2" /> Sair
          </Button>
        </header>

        {/* Seed inicial */}
        {(docs.data?.length ?? 0) === 0 && (
          <section className="bg-card gold-border rounded-lg p-6 shadow-sm">
            <h2 className="font-display text-xl text-[color:var(--navy-deep)] mb-2">Carregar documentos iniciais</h2>
            <p className="text-sm text-[color:var(--muted-foreground)] mb-4">
              Importar os 5 documentos oficiais já incluídos (Princípios Gerais, Regulamento Geral, Códigos de Ética, Eleitoral e de Procedimentos).
              A indexação pode levar alguns minutos.
            </p>
            <Button onClick={() => seed.mutate()} disabled={seed.isPending} className="bg-[color:var(--gold)] text-[color:var(--navy-deep)] hover:bg-[color:var(--gold-soft)]">
              {seed.isPending ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Indexando…</> : <><Sparkles className="w-4 h-4 mr-2" /> Carregar e indexar</>}
            </Button>
          </section>
        )}

        {/* Upload */}
        <section className="bg-card gold-border rounded-lg p-6 shadow-sm">
          <h2 className="font-display text-xl text-[color:var(--navy-deep)] mb-4 flex items-center gap-2">
            <Upload className="w-5 h-5 text-[color:var(--gold)]" /> Novo documento
          </h2>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <Label>Título</Label>
              <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Ex.: Regimento Interno da Loja" />
            </div>
            <div>
              <Label>Arquivo (.md ou .txt)</Label>
              <Input type="file" accept=".md,.txt,.markdown" onChange={onFileChange} />
            </div>
          </div>
          <div className="mt-4">
            <Label>Conteúdo</Label>
            <Textarea rows={8} value={content} onChange={(e) => setContent(e.target.value)}
              placeholder="Cole o conteúdo do documento aqui se não tiver um arquivo .md" />
          </div>
          <div className="mt-4 flex justify-end">
            <Button
              onClick={() => upload.mutate()}
              disabled={upload.isPending || !title || content.length < 10}
              className="bg-[color:var(--navy-deep)] hover:bg-[color:var(--navy)]"
            >
              {upload.isPending ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Indexando…</> : "Adicionar e indexar"}
            </Button>
          </div>
        </section>

        {/* Lista de docs */}
        <section className="bg-card gold-border rounded-lg p-6 shadow-sm">
          <h2 className="font-display text-xl text-[color:var(--navy-deep)] mb-4">Documentos cadastrados</h2>
          {docs.isLoading ? (
            <Loader2 className="w-5 h-5 animate-spin" />
          ) : (docs.data?.length ?? 0) === 0 ? (
            <p className="text-sm text-[color:var(--muted-foreground)]">Nenhum documento cadastrado.</p>
          ) : (
            <ul className="divide-y divide-[color:var(--border)]">
              {docs.data!.map((d) => (
                <li key={d.id} className="py-3 flex items-center justify-between gap-4">
                  <div>
                    <div className="font-medium text-[color:var(--navy-deep)]">{d.title}</div>
                    <div className="text-xs text-[color:var(--muted-foreground)]">
                      {d.chunk_count} trechos · {new Date(d.created_at).toLocaleString("pt-BR")}
                    </div>
                  </div>
                  <Button
                    variant="ghost" size="sm"
                    onClick={() => confirm(`Excluir "${d.title}"?`) && del.mutate(d.id)}
                    className="text-[color:var(--destructive)] hover:bg-[color:var(--destructive)]/10"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </section>
      </main>
    </div>
  );
}