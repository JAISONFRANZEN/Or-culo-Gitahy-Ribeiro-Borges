import { Link } from "@tanstack/react-router";
import officialLogo from "@/assets/logo-oficial-gitahy.png.asset.json";

export function SiteHeader() {
  return (
    <header className="border-b border-[color:var(--gold)]/30 bg-[color:var(--navy-deep)] text-[color:var(--ivory)]">
      <div className="mx-auto max-w-6xl px-6 py-5 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3 group">
          <img
            src={officialLogo.url}
            alt="Logo oficial da A.R.B.L.S. Gitahy Ribeiro Borges nº 58"
            className="h-14 w-14 shrink-0 rounded-full object-contain"
          />
          <div className="leading-tight">
            <div className="font-display text-xl font-semibold tracking-wide">Oráculo Gitahy Ribeiro Borges</div>
            <div className="text-[11px] uppercase tracking-[0.25em] text-[color:var(--gold)]/80">GOSC · Sabedoria & Tradição</div>
          </div>
        </Link>
        <nav className="flex items-center gap-6 text-sm">
          <Link to="/" className="hover:text-[color:var(--gold)] transition-colors">Consultar</Link>
          <Link to="/admin" className="hover:text-[color:var(--gold)] transition-colors">Administração</Link>
        </nav>
      </div>
    </header>
  );
}