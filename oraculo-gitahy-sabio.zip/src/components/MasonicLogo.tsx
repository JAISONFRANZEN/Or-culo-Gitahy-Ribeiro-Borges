export function MasonicLogo({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden>
      <circle cx="32" cy="32" r="30" stroke="currentColor" strokeWidth="1.2" opacity="0.4" />
      <path d="M16 46 L32 14 L48 46" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" />
      <path d="M16 46 Q32 30 48 46" stroke="currentColor" strokeWidth="1.6" fill="none" />
      <text x="32" y="42" textAnchor="middle" fontFamily="Cormorant Garamond, serif" fontSize="14" fill="currentColor" fontWeight="600">G</text>
    </svg>
  );
}