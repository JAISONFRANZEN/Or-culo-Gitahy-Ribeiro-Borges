## Regulamento Geral

# REGULAMENTO GERAL

# Lei nº 12, de 07 de julho de 2003

```
Atualizado até a Lei nº 174 , de 03 de abril de 2026
```

## Regulamento Geral

**REGULAMENTO GERAL**


- Apresentação - Dos Princípios Gerais da Maçonaria.............................................................. - Lei nº 12 de 07 de julho de 2003 –
- Título Único - Da Potência Maçônica Grande Oriente de Santa Catarina............................
- Capítulo I - Dos Princípios Normativos....................................................................................
- Capítulo II - Do Colegiado.........................................................................................................
- Seção I - Das Atribuições...........................................................................................................
- Seção II - Das Comissões Permanentes e Temporárias...........................................................
- Seção III - Das Reuniões.............................................................................................................
- Capítulo III - Do Grão-Mestrado..............................................................................................
- Seção I - Das Atribuições do Grão-Mestre...............................................................................
- Seção II - Das Atribuições do Grão-Mestre Adjunto...............................................................
- Seção III – Inelegibilidades (revogado).....................................................................................
- Seção IV - Da Estrutura Organizacional..................................................................................
- Seção V – Do Quadro Funcional................................................................................................
- Seção VI - Do Patrimônio e das Receitas..................................................................................
- Capítulo IV – Das Lojas e Triângulos.......................................................................................
- Seção I – Da Posse dos Veneráveis Mestres..............................................................................
- Seção II - Da Administração das Lojas e Triângulos...............................................................
- Seção III - Do Regimento Interno das Lojas e Triângulos......................................................
- Seção IV - Das Luzes, Dignidades e Oficiais.............................................................................
- Seção V – Das Comissões das Lojas..........................................................................................
- Seção VI - Do Conselho das Lojas.............................................................................................
- Seção VII - Dos Direitos das Lojas e Triângulos......................................................................
- Seção VIII - Dos Deveres das Lojas e Triângulos....................................................................
- Seção IX - Das Proibições das Lojas e Triângulos...................................................................
- Seção X - Do Patrimônio das Lojas e Triângulos.....................................................................
- Seção XI – Das Sessões das lojas e Triângulos
- Seção XII - Da Regularidade das Lojas e Triângulos..............................................................
- Seção XIII - Do Desligamento, Realinhamento e Justaposição das Lojas e Triângulos.......
- Seção XIV - Da Suspensão e Restabelecimento de Loja e Triângulos....................................
- Seção XV - Das Funções Judiciais em Lojas e Triângulos......................................................
- Subseção I - Do Conselho de Família........................................................................................
- Subseção II - Do Tribunal do Júri (revogado).........................................................................
- Capítulo V – Dos Maçons...........................................................................................................
- Seção I – Dos Requisitos para a Admissão................................................................................
- Seção II - Do Processo de Sindicância.......................................................................................
- Seção III - Da Iniciação..............................................................................................................
- Seção IV - Da Filiação................................................................................................................
- Seção V - Da Regularização.......................................................................................................
- Seção V – A - Da Transferência.................................................................................................
- Seção VI - Dos Graus..................................................................................................................
- Seção VII - Da Situação Individual do Maçom........................................................................
- Subseção I - Dos Direitos do Maçom.........................................................................................
- Subseção II - Dos Deveres do Maçom........................................................................................
- Subseção III - Da Regularidade e Irregularidade do Maçom.................................................
- Subseção VI – O Maçom e sua Designação..............................................................................
- Seção VIII - Do Quite-Placet e Placet Ex-Ofício......................................................................
- Seção IX - Da Suspensão e Perda dos Direitos Maçônicos.....................................................
- Seção X - Do Direito de Intervisitação...................................................................................... Regulamento Geral
- Capítulo VI – Das Ações Singulares..........................................................................................
- Seção I – Das Eleições.................................................................................................................
- Seção II - Das Incompatibilidades
- Seção III - Dos Livros Negros e Amarelo.................................................................................
- Seção IV - Da Instalação de Venerável Mestre........................................................................
- Seção V - Da Sagração do Templo.............................................................................................
- Seção VI - Palavra Semestral.....................................................................................................
- Seção VII - Datas Comemorativas............................................................................................
- Seção VIII - Das Condecorações...............................................................................................
- Seção IX - Do Luto Maçônico....................................................................................................
- Seção X - Protocolo de Recepção e Tratamento às Autoridades............................................
- Capítulo VII – Das Disposições Gerais e Transitórias.............................................................


```
Regulamento Geral
Apresentação
Dos Princípios Gerais da Maçonaria
```
A Maçonaria é uma ESCOLA DO CONHECIMENTO e de
APERFEIÇOAMENTO que o homem, em seu percurso histórico, produziu. É,
complementar e subsidiariamente, uma instituição essencialmente iniciática, filosófica,
filantrópica, educativa e progressista, adogmática e apartidária, que tem por finalidade
oferecer instrumentos para formar homens que propugnem por uma sociedade
alicerçada na tríade da liberdade, igualdade e fraternidade.

I – Proclama a prevalência do espírito sobre a matéria; que os homens são
livres e iguais em direitos; que a tolerância constitui o princípio cardeal nas relações
humanas, para que sejam respeitadas as convicções e a dignidade de cada um.

II – Prega o aperfeiçoamento moral, intelectual e social da humanidade, por
meio do cumprimento inflexível do dever, da investigação constante da verdade e da
prática desinteressada da beneficência.

III – Enaltece o mérito da inteligência e da virtude e o valor demonstrado na
prestação de serviços à Ordem, à Pátria e à Humanidade.

IV – Repudia todas as formas de exploração da pessoa humana, os privilégios e
as regalias, combate a ignorância, a superstição e a tirania.

V – Afirma que o sectarismo político e o fanatismo, quer religioso ou racial, são
incompatíveis com a universalidade do espírito maçônico.

VI – Defende a plena liberdade de expressão do pensamento, como direito
fundamental do ser humano, admitida a correlata responsabilidade.

VII – Reconhece o trabalho como um dever social; julga-o dignificante e nobre
sob qualquer forma: manual, intelectual, artística e técnica.

VIII – Considera irmãos todos os maçons, quaisquer que sejam suas raças,
nacionalidades ou crenças.

```
IX – Sustenta que os maçons têm os seguintes deveres essenciais: amor à
família, fidelidade, devotamento à Pátria e obediência à Lei.
```
X – Sustenta que os maçons estendam e liberalizem os laços fraternais que os
unem a todos os homens esparsos pela superfície da Terra.

XI – Recomenda a divulgação de seus ideais pelo exemplo e por todos os meios
de comunicação do pensamento e proscreve, terminantemente, o recurso à força ou à
violência, na solução dos litígios de qualquer ordem, combatendo a ignorância em todas
as suas modalidades.

XII – Adota sinais e emblemas de elevada significação simbólica, os quais,
utilizados nos trabalhos maçônicos, servem, também, para os maçons se reconhecerem


**Regulamento Geral**
e se auxiliarem, onde quer que se encontrem.

Calcado e alicerçado nos princípios maçônicos, o GRANDE ORIENTE DE
SANTA CATARINA, constitui-se em uma POTÊNCIA SIMBÓLICA para as lojas,
triângulos e maçons que a ele se filiem, agindo de maneira própria e independente,
mantendo relações de reconhecimento e amizade com as demais potências maçônicas
regulares e reconhecidas, respeitadas sua Constituição e leis complementares, bem
como os seguintes postulados e princípios normativos da Ordem Maçônica Universal:
da crença na existência de um Princípio Criador, a quem invoca sob a denominação de
Grande Arquiteto do Universo; do simbolismo da Maçonaria Operativa; das lendas
como instrumento didático; do sigilo absoluto e inviolável; do juramento, em presença
do Grande Arquiteto do Universo, sobre o Livro da Lei, obedecido o que consagra o
Rito específico; da presença nas lojas e triângulos das Três Grandes Luzes da Maçonaria

- Livro da Lei, Esquadro e Compasso - durante os trabalhos ritualísticos; da
consagração da virtude, benevolência, educação, tolerância e da livre e consciente
investigação da verdade; da proibição, em Loja, de toda e qualquer discussão em
torno de sectarismo, discriminação, de assuntos religiosos singulares ou de política
partidária; do culto e glorificação da verdade, da justiça e do direito; do respeito às
autoridades legalmente constituídas, às leis do país, à família e às religiões; do
aprofundamento continuado da doutrina, filosofia e os mistérios que a simbologia
maçônica encerra; da obrigatória aceitação dos antigos Landmarks, tradições, usos e
costumes da Antiga Maçonaria, conforme prescrevem as leis de 1723 e outras
universalmente aceitas pela Maçonaria simbólica regular e universal.

```
Título Único
Da Potência Maçônica
Grande Oriente de Santa Catarina
Capítulo I
Dos Princípios Normativos
```
**Art. 1º** O GRANDE ORIENTE DE SANTA CATARINA, que tem como
sigla GOSC, é uma instituição maçônica simbólica, regular, autônoma, soberana,
independente, legal, legítima, resultante da vontade dos obreiros de suas lojas
simbólicas e triângulos no Estado de Santa Catarina, reger-se-á por sua Constituição,
por este Regulamento Geral, pelo Código de Procedimentos, por seus regimentos e pelas
leis brasileiras, dividindo-se em duas partes harmônicas e solidárias entre si:

```
I – COLEGIADO
```
```
II – GRÃO-MESTRADO
```
§ 1º Filiado à Confederação Maçônica do Brasil, que tem como sigla COMAB,
é uma sociedade civil de direito privado, fundada em 12 de abril de 1950, registrada sob
o número 2.980, no livro A (17), à folha 237, na forma da lei dos Registros Públicos,
no Cartório de Registro Civil de Títulos, Documentos e Pessoas Jurídicas de
Florianópolis - SC.


**Regulamento Geral**

```
§ 2º Como sociedade civil de direito privado, de fins culturais, cívicos e
filantrópicos, cujas atividades não têm fins lucrativos e cujos dirigentes não percebem
qualquer remuneração, tem sede e foro na cidade de Florianópolis, Capital do Estado de
Santa Catarina.
```
```
§ 3º Como instituição maçônica tem responsabilidade e governo próprio, não
alienando e nem dividindo o seu poder, quer seja por tratado ou qualquer outro
meio que possa, direta ou indiretamente, sujeitá-lo à ingerência, intromissão ou domínio
de qualquer outro corpo maçônico.
```
```
§ 4º É autoridade única e exclusiva sobre os três graus simbólicos praticados
pelas lojas e triângulos sob sua jurisdição, em qualquer rito adotado respeitados os
Landmarks tradicionais, os ritos reconhecidos, os princípios gerais, fundamentais e
normas da Maçonaria Universal.
```
§ 5º Adota a pluralidade de ritos e a eles referência de acordo com a Sessão e a
Loja.

```
§ 6º Prioriza e cultua o princípio estético da concordância, considerando que
todos seus integrantes são irmãos devendo incentivar a convivência harmônica.
```
§ 7º Tem seu suporte estrutural baseado nas decisões tomadas pelo
COLEGIADO e pelo GRÃO-MESTRADO.

```
§ 8º A adoção ou agregação de outro rito, desde que regular e legítimo, dependerá
da aprovação do COLEGIADO por indicação do GRÃO-MESTRADO. (Acrescentado
pela Lei nº 118/GOSC/2014- 2017 , de 24 de setembro de 2016)
```
```
Capítulo II
Do Colegiado
```
```
Art. 2º O COLEGIADO é o órgão deliberativo do GRANDE ORIENTE DE
SANTA CATARINA, composto pelo Grão-Mestre, Grão-Mestre Adjunto e Veneráveis
Mestres das lojas ou seus representantes legais, da jurisdição, todos com direito a
voto, com as exceções previstas neste regulamento.
```
```
Art. 3º É o órgão donde flui a aplicação, regulamentação e execução dos
direitos, deveres e atos constitucionais da Maçonaria e do Povo Maçônico, com poderes
constitucionais, legislativos, judiciários e eleitorais.
```
```
Art. 4º Tem como presidente o Grão-Mestre, que é substituído, em seus
impedimentos e ausências, pelo Grão-Mestre Adjunto, e este pelo Venerável Mestre
escolhido pelo Colegiado na reunião.
```
```
Art. 5º Em caso de vacância permanente do cargo de Grão-Mestre, seu
substituto tomará posse na presidência do COLEGIADO no mesmo dia em que for
empossado no cargo de Grão-Mestre.
```

```
Regulamento Geral
Art. 6º São substitutos dos veneráveis mestres, respectivamente: o Primeiro
Vigilante; o Segundo Vigilante e, na falta de ambos, por Mestre Maçom ativo e regular
da sua Loja, devidamente credenciado.
```
```
Parágrafo Único Os ritos cuja designação e hierarquia dos cargos mencionados
no caput deste artigo são diferentes manterão suas específicas designações.
```
**Art. 7º** Os veneráveis mestres eleitos tomarão posse como membros do
COLEGIADO na Reunião Ordinária subseqüente a sua posse na respectiva Loja.

```
Art. 8º Os veneráveis mestres eleitos ou nomeados fora da época prevista no
calendário eleitoral, tomarão posse no COLEGIADO após terem sido diplomados,
instalados e empossados em suas lojas, condicionando-se a situação regular perante
o GRANDE ORIENTE DE SANTA CATARINA.
```
```
Art. 9º Nas reuniões do COLEGIADO será permitida a presença de
autoridades maçônicas e de Maçom regular, como assistente, vedada qualquer
manifestação, exceto através de convite formulado, antecipadamente, pelo Presidente.
```
```
Parágrafo Único Será admitida a participação de pessoa que não pertença à
Ordem, em parte da Reunião, para tratar de assunto específico e que não exija sigilo
maçônico, a convite ou concordância do Presidente e dado prévio conhecimento ao
Colegiado.
```
```
Seção I
Das Atribuições
```
```
Art. 10 Compete ao COLEGIADO discutir e deliberar sobre as matérias e as
questões que digam respeito ao GRANDE ORIENTE DE SANTA CATARINA e
especialmente sobre:
```
```
I – a elaboração e deliberação, conforme definido, no Processo Legislativo
do GRANDE ORIENTE DE SANTA CATARINA, sobre:
```
```
a) emendas à Constituição.
b) emendas ao Regulamento Geral.
c) emendas ao Código de Procedimentos.
d) leis complementares.
e) leis ordinárias.
f) resoluções.
g) regimento Interno do COLEGIADO.
```
```
II – a Proposta Orçamentária e a Proposta de Execução Orçamentária oriundas
do Grão-Mestre, na Reunião Ordinária de dezembro, os pedidos de transposição e
suplementação de verbas, podendo incluir rubricas desde que haja recursos para
sustentá-los.
```

```
Regulamento Geral
III – a autorização de empréstimos para atender compromissos assumidos pelo
Executivo.
```
```
IV - (Revogado pela Lei nº 118/GOSC/2014- 2017 , de 24 de setembro de 2016)
```
```
V – a concessão de títulos, recompensas ou qualquer outra premiação a maçons,
lojas ou não-maçons.
```
```
VI – a aprovação de tratados e de convênios com outras potências maçônicas.
```
VII – a concessão de anistia a maçons ou lojas, mediante proposta do Grão-
Mestre.

```
VIII – O reconhecimento, como entidades paramaçônicas ou entidades de
interesse maçônico, de instituições cujas finalidades sejam compatíveis com os
princípios da maçonaria, e a celebração de Tratados de Reconhecimento e Amizade com
as instituições paramaçônicas (Alterado pela Lei nº 149/GOSC/2020-2023, de 26 de
junho de 2021)
```
```
IX – autorizar o GRANDE ORIENTE DE SANTA CATARINA a efetivar
qualquer alienação, aquisição ou gravame de bens imóveis.
```
X – julgar, trimestralmente, por ocasião da Reunião Ordinária, as contas do
GRANDE ORIENTE DE SANTA CATARINA.

```
XI – dar posse ao Grão-Mestre e ao Grão-Mestre Adjunto.
```
```
XII – conceder licença ao Grão-Mestre e ao Grão-Mestre Adjunto para
afastarem-se, simultaneamente, de seus cargos ou de sua jurisdição, pelo prazo superior
a trinta dias.
```
XIII – declarar vago o cargo de Grão-Mestre e de Grão-Mestre Adjunto, isolado
ou simultaneamente, quando ocorrer a vacância.

XIV – encaminhar ao Grão-Mestrado pedido de informação ou esclarecimentos
relacionados às suas atividades.

XV – convocar autoridades ou qualquer Irmão integrante dos quadros do GOSC
e de suas lojas jurisdicionadas para apresentarem, esclarecerem, debaterem assuntos
pertinentes e de interesse da instituição.

```
XVI – processar e julgar membros do COLEGIADO.
```
XVII – processar e julgar o Grão-Mestre e o Grão-Mestre Adjunto nos crimes de
responsabilidade.

XVIII – conceder licença a seus membros para afastamento, por motivos
particulares.

```
XIX – tomar conhecimento da renúncia do Grão-Mestre ou Grão-Mestre Adjunto,
```

**Regulamento Geral**
provendo suas vacâncias.
XX – processar e julgar litígios entre lojas e maçons que não sejam da mesma
Oficina.

XXI – processar e julgar as causas e os conflitos entre o Grão-Mestrado e as lojas
simbólicas e os triângulos da jurisdição.

XXII – julgar, em grau de recurso, o registro e a cassação de candidatos a Grão-
Mestre, Grão-Mestre Adjunto, veneráveis, vigilantes e tesoureiros.

XXIII – aprovar a resolução que fixa o processo eleitoral e a apuração das eleições
de Grão-Mestre, Grão-Mestre Adjunto e dos cargos eletivos das lojas, de acordo com o
previsto no Código Eleitoral. **(Alterado pela Lei nº 118/GOSC/2014- 2017 , de 24 de
setembro de 2016)**

```
XXIV – proceder ao reconhecimento e as decisões de argüições de
inelegibilidade.
```
```
XXV – julgar os litígios sobre os pleitos eleitorais maçônicos.
```
XXVI - Suspender, no todo ou em parte, a execução de lei, depois de constatada
sua inconstitucionalidade.

**Art. 11 (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de
2016)**

```
Seção II
Das Comissões Permanentes e Temporárias
```
**Art. 12 (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de
2016)**

```
Art. 13 Cada Comissão Permanente, integrada exclusivamente por veneráveis
mestres, contará com cinco membros titulares e três suplentes, eleitos pelo plenário,
anualmente, na reunião ordinária no mês de junho.
```
Parágrafo Único **(Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de
setembro de 2016)**

```
Seção III
Das Reuniões
```
```
Art. 14 A abertura das reuniões ocorrerá com o quorum mínimo de maioria
simples do COLEGIADO em primeira convocação, ou trinta minutos após, com
```

```
Regulamento Geral
qualquer número, devendo ser observadas nas deliberações das matérias as disposições
da Constituição, do Regulamento Geral, do Código de Procedimentos e do Regimento
Interno do COLEGIADO, quanto ao número mínimo de votos para sua aprovação.
```
Parágrafo Único **(Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de
setembro de 2016)**

**Art. 15 (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de
2016)**

```
Capítulo III
```
```
Do Grão-Mestrado
```
**Art. 16** As funções executivas do GRANDE ORIENTE DE SANTA CATARINA
são exercidas pelo Grão-Mestre, auxiliado pelo Grão-Mestre Adjunto e pelos titulares e
adjuntos dos cargos designados. **(Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de
setembro de 2016)**

§ 1° Ocorrendo vacância concomitante dos cargos de Grão-Mestre e de Grão-
Mestre Adjunto, assumirá o cargo de Grão-Mestre o Grão-Mestre de Honra,
interinamente. **(Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de
2016)**

§ 2° A Vacância ocorrendo em período igual ou menor a 18(dezoito) meses do
mandato, o Grão-Mestre de Honra convocará novas eleições em até 90 (noventa) dias.
**(Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)**

```
Art. 17 O Grão-Mestre, que tem o tratamento de Sereníssimo, é a mais elevada
representação maçônica da jurisdição e ocupa o primeiro posto dentro do protocolo
maçônico em qualquer sessão ou solenidade do GRANDE ORIENTE DE SANTA
CATARINA.
```
```
§ 1º O protocolo maçônico em qualquer sessão ou solenidade nas lojas e
triângulos jurisdicionados, obedecerá à ordem hierárquica do Grão-Mestre em primeiro
lugar e do Grão-Mestre Adjunto em segundo.
```
§ 2º No período seguinte àquele de suas gestões, o Grão-Mestre e o Grão-Mestre
Adjunto terão, respectivamente, os tratamentos e títulos de Respeitabilíssimo Grão-
Mestre de Honra e Eminente Grão-Mestre Adjunto de Honra, e os anteriores de
Respeitabilíssimo Past Grão-Mestre e Eminente Past Grão-Mestre Adjunto. **(Alterado
pela Lei nº 168, de 27 de outubro de 2025)**

```
Seção I
Das Atribuições do Grão-Mestre
```
```
Art. 18 Compete privativamente ao Grão-Mestre ou ao seu substituto legal,
```

```
Regulamento Geral
quando no exercício do cargo:
```
```
I - cumprir e fazer cumprir as deliberações do COLEGIADO.
```
II – Representar o GRANDE ORIENTE DE SANTA CATARINA, ativa e
passivamente, em juízo e fora dele, em suas relações com as autoridades maçônicas e
não-maçônicas, com as potências maçônicas e os órgãos públicos e privados em geral.

```
III – administrar o GRANDE ORIENTE DE SANTA CATARINA, exigindo das
lojas, dos triângulos, dos titulares e adjuntos de cargos designados e dos maçons o
cumprimento da Constituição, e das Leis, bem como a fiel observância dos Landmarks,
dos Princípios Gerais da Ordem e Tradicionais da Maçonaria. (Alterado pela Lei nº
118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
IV – Administrar o orçamento do GRANDE ORIENTE DE SANTA CATARINA
com base na Lei de Diretrizes Orçamentárias. (Alterado pela Lei nº 118/GOSC/2014-
2017, de 24 de setembro de 2016)
```
```
V – presidir toda sessão maçônica a que comparecer, seja ela especial, magna,
pública ou outra com qualquer denominação.
```
```
VI – publicar e fazer cumprir as leis emanadas do COLEGIADO, e sobre elas
exercer poderes de administração, execução e aplicação; (alterado pela Lei nº
118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
VII – convocar o COLEGIADO, quando entender necessário.
```
```
VIII – designar, contratar, dispensar e demitir membros de órgãos afetos ao
GRANDE ORIENTE DE SANTA CATARINA.
```
```
IX – admitir, nomear, repreender e demitir empregados.
```
```
X – suspender os direitos maçônicos das lojas e Irmãos, por transgressão da lei,
após apreciação e decisão do COLEGIADO; (alterado pela Lei nº 118/GOSC/2014-
2017, de 24 de setembro de 2016)
```
```
XI – intervir na Administração da Loja, submetendo sua decisão à apreciação
do COLEGIADO em sua primeira Reunião Ordinária subseqüente.
```
XII – suspender o mandato de Venerável, submetendo a decisão ao
COLEGIADO.

```
XIII – Apresentar anualmente, no mês de março, ao COLEGIADO, o Relatório
de Atividades relativas ao exercício anterior; trimestralmente a Prestação de Contas do
período anterior, indicando as providências legislativas que julgar convenientes,
relativas ao exercício administrativo e fiscal. (Alterado pela Lei nº 118/GOSC/2014-
2017, de 24 de setembro de 2016)
```
```
XIV – nomear Representantes ou Garantes de Amizade do GRANDE ORIENTE
DE SANTA CATARINA junto às potências maçônicas com as quais mantém Tratado
```

```
Regulamento Geral
de Reconhecimento.
```
```
XV – propor ao COLEGIADO o perdão e a comutação, no todo ou em
parte, de penas que tenham sido impostas às lojas.
```
```
XVI – propor ao COLEGIADO, lei que crie a concessão de títulos honoríficos,
recompensas, insígnias ou distinções oficiais do GRANDE ORIENTE DE SANTA
CATARINA, a serem conferidas a maçons, lojas ou pessoas não- maçons, por
merecimento, em razão de serviços prestados à Ordem.
```
```
XVII – (Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de
2016)
XVIII – dirigir-se ao mundo não-maçônico em nome do GRANDE ORIENTE DE
SANTA CATARINA.
```
```
XIX – autorizar, nos limites da Lei Orçamentária, a abertura de créditos e, além
desse limite, o pagamento de despesas extra-orçamentárias urgentes e inadiáveis, ad-
referendum do COLEGIADO, fundamentando-as na Reunião Ordinária subseqüente.
```
```
XX – inspecionar ou fazer inspecionar as lojas, triângulos e órgãos integrantes
da estrutura administrativa do Grão-Mestrado.
```
XXI – assinar tratados e convênios submetendo-os, na reunião subseqüente, ao
COLEGIADO.

```
XXII – autorizar a participação do GRANDE ORIENTE DE SANTA
CATARINA em conclaves maçônicos ou não, a nível regional, nacional ou
internacional.
```
```
XXIII – dar o exequatur aos Garantes de Amizade e aos representantes de outras
potências.
```
```
XXIV – reunir-se sempre que for necessário com a administração do Grão-
Mestrado; (alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
XXV – transmitir semestralmente aos veneráveis das lojas e triângulos a
PALAVRA SEMESTRAL; (alterado pela Lei nº 118/GOSC/2014-2017, de 24 de
setembro de 2016)
```
```
XXVI – autorizar o funcionamento de lojas na jurisdição e àquelas que
requererem filiação, expedindo as respectivas Cartas Constitutivas.
```
```
XXVII – autorizar o funcionamento provisório de lojas e triângulos.
```
```
XXVIII – reduzir emolumentos ou dívidas das lojas e Triângulos. (Alterado pela
Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
XXIX - autorizar a expedição do placet de iniciação, elevação, exaltação,
regularização, filiação e transferência.
```

```
Regulamento Geral
XXX – autorizar a dispensa do interstício de iniciação, elevação e exaltação de
maçons, bem como autorizar a iniciação de número superior a cinco.
```
XXXI – conceder títulos, recompensas, insígnias ou distinções oficiais do
GRANDE ORIENTE DE SANTA CATARINA a maçons, lojas ou não-maçons.

```
XXXII – fazer editar Boletim Oficial para distribuição a todas as lojas, triângulos,
demais dirigentes do GRANDE ORIENTE DE SANTA CATARINA; (alterado pela
Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
XXXIII – definir a posição do GRANDE ORIENTE DE SANTA CATARINA
nos momentos de crise e insegurança no mundo maçônico e não maçônico, respeitada a
legislação, submetendo-a ao COLEGIADO; (alterado pela Lei nº 118/GOSC/2014-
2017, de 24 de setembro de 2016)
```
```
XXXIV – (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de
2016)
```
XXXV – **(Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de
2016)**

```
XXXVI – baixar decretos regulamentando e disciplinando leis aprovadas pelo
COLEGIADO.
```
```
XXXVII – baixar decretos criando atividades promocionais, visando à
complementação da receita orçamentária; (alterado pela Lei nº 118/GOSC/2014-2017,
de 24 de setembro de 2016)
```
```
XXXVIII – suspender preventivamente os direitos do maçom, que por ação ou
omissão dê causa à repercussão, profana ou maçônica, prejudicial à dignidade e a
imagem da Ordem. (Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro
de 2016)
```
```
a) efetuada a suspensão preventiva, será instaurado o processo a ser instruído pela
Comissão de Conciliação e Justiça de acordo com o Código de Ética. (Alterado pela
Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
b) (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
c) (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
XXXIX - dispensar, em caráter temporário, o recolhimento da contribuição
```
financeira devida ao GRANDE ORIENTE DE SANTA CATARINA de maçons em

comprovada dificuldade financeira e acometido por problema grave de saúde, a pedido

da respectiva Loja. **(Alterado pela Lei n° 115/GOSC/2014- 2017 , de 26 de setembro de**

**2015 )**

```
XL – autorizar a Loja Requerente a adoção ou mudança de rito reconhecido pelo
GOSC. (Acrescentado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```

**Regulamento Geral**
XLI – assinar decreto de reconhecimento de potências, corporações e entidades
maçônicas e paramaçônicas, nos termos da legislação maçônica interna, após aprovação
do reconhecimento pelo Colegiado. **(Acrescentado pela Lei nº 174, de 03 de abril de
2026)**

```
Seção
II
Das Atribuições Do Grão-Mestre Adjunto
```
**Art. 19** O Grão-Mestre Adjunto, que tem o tratamento de Eminente, é o substituto
legal do Grão-Mestre, quando previamente designado, ou em suas ausências ou
impedimentos, exercendo todas as suas atribuições durante esse período, e seu sucessor
na hipótese de vacância do cargo. **(Alterado pela Lei nº 168, de 27 de outubro de
2025)**

§ 1° Ocorrendo vacância do cargo de Grão-Mestre, o Grão-Mestre Adjunto
assumirá o Grão-Mestrado, independente do tempo decorrido e concluirá o mandato.

§ 2° Ocorrendo a vacância no cargo de Grão-Mestre Adjunto, em período igual
ou menor de 12 (doze) meses em relação ao fim do mandato, o Grão-Mestre submeterá
à aprovação do Colegiado, o nome de um Ex-Grão-Mestre ou de um Ex-Grão-
Mestre Adjunto, para concluir o mandato.

§ 3° Ocorrendo a vacância antes do período referido do parágrafo anterior, o
Grão-Mestre submeterá ao Colegiado uma lista tríplice de candidatos, devendo os
mesmos ser Mestres Instalados a mais de 3 (três) anos para que em votação secreta, seja
eleito o sucessor que concluirá o mandato de Grão-Mestre Adjunto.

I – Ocorrendo a desistência de um ou mais nomes constante da lista tríplice, de
imediato, o Grão-Mestre deverá apresentar o (s) nome (s) do (s) substituto (s);

II – Será eleito, o candidato que obtiver no mínimo cinquenta por cento, mais
um voto, do total dos Membros do Colegiado;

III – Não havendo candidato que alcance a maioria de votos prevista no inciso
anterior, nova eleição deverá ser feita, de imediato, na mesma Sessão do Colegiado,
devendo concorrer os dois candidatos mais votados;

IV – Persistindo a eleição sem o alcance do percentual mínimo exigido no inciso
II, a reunião será suspensa por até sessenta minutos, quando então ocorrerá nova (s)
votação (ões) secreta (s), na forma do inciso III, para a escolha do novo Grão-Mestre
Adjunto.

V – O eleito prestará seu compromisso e tomará posse, de imediato, na mesma
Sessão do Colegiado. **(Alterado pela Lei nº 105/2011, art. 1°, de 28 de março de
2011 )**

```
Seção III
```

```
Regulamento Geral
Das Inelegibilidades
```
**Art. 20 (Revogado**^ **pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de
2016)**

```
Seção IV
Da Estrutura Organizacional
```
Art. 21. Para assegurar o regular funcionamento das funções administrativas,
operacionais, políticas e estratégicas do GRANDE ORIENTE DE
SANTA CATARINA, o Grão-Mestre eleito encaminhará ao COLEGIADO, para
deliberação, proposta da estrutura administrativa para o período de seu governo, onde
constará:

```
I – os Órgãos
II – a direção dos órgãos;
III – a competência;
IV – a forma de provimento.
```
```
§ 1º O não encaminhamento pelo Grão-Mestre eleito da proposta referida no
caput deste artigo implica na continuidade da estrutura existente.
```
```
§ 2º A estrutura administrativa, após aprovada e sancionada, será publicada
no Boletim Oficial.
```
```
Seção V
Do Quadro funcional
```
```
Art. 22 Os empregados do GRANDE ORIENTE DE SANTA CATARINA farão
parte do QUADRO DE PESSOAL FIXO regidos pela CLT. (Alterado pela Lei nº
118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
Parágrafo único (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de
setembro de 2016)
```
```
Art. 23 Os maçons detentores de cargos de confiança que fizerem parte da
estrutura administrativa do GRANDE ORIENTE DE SANTA CATARINA poderão
receber ressarcimento a título de indenização de despesas. (Alterado pela Lei nº
118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
Seção VI
Do Patrimônio e das Receitas
```

**Regulamento Geral
Art. 24** O patrimônio do GRANDE ORIENTE DE SANTA CATARINA
independe das lojas e triângulos.

```
Parágrafo Único O GRANDE ORIENTE DE SANTA CATARINA, como suas
lojas, triângulos e entidades civis paramaçônicas, mantém exclusivo domínio, posse,
uso e administração do patrimônio de que são titulares ou venham adquirir.
```
```
Art. 25 As receitas do GRANDE ORIENTE DE SANTA CATARINA, das lojas
e dos triângulos, são independentes. (Alterado pela Lei nº 118/GOSC/2014-2017, de
24 de setembro de 2016)
```
```
Art. 26 São receitas do GRANDE ORIENTE DE SANTA CATARINA:
(Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
I – as constantes da tabela de emolumentos da lei orçamentária e outros; **(alterado
pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)**
II – a cotização das lojas e triângulos da jurisdição.
III – os aluguéis dos templos e prédios de sua propriedade.
IV - **(Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)**
V - **(Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)**

```
Capítulo IV
Das Lojas e Triângulos
```
```
Art. 27 As funções executivas, administrativas, ritualísticas e operacionais das
lojas e dos triângulos são exercidas, respectivamente, pelos veneráveis mestres,
presidentes de triângulos e demais integrantes das administrações. (Alterado pela Lei
nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
Art. 28 Uma Loja Maçônica será fundada tendo, no mínimo, sete mestres maçons
efetivos em seu quadro e em pleno gozo de seus direitos, sendo presidida por um deles,
denominado Venerável Mestre, ou o equivalente no Rito adotado pela Loja, devendo os
demais cargos serem preenchidos de acordo com o Rito respectivo.
```
```
§ 1º Em orientes onde não existir loja regular do GOSC, a Loja poderá ser fundada
tendo, no mínimo, três Mestres Maçons efetivos, que ocuparão os cargos de Venerável
Mestre, Primeiro Vigilante e Segundo Vigilante, e quatro Mestres Maçons filiados, um
dos quais ocupará o cargo de Tesoureiro. (Acrescentado pela Lei nº 128/GOSC/2017-
2020 , de 30 de novembro de 2018)
```
```
§ 2º Serão considerados fundadores os maçons que assinarem a Ata da Fundação
e/ou tenham contribuído efetivamente para sua criação. (renumerado pela Lei nº
128/GOSC/2017- 2020 , de 30 de novembro de 2018)
```
```
Art. 29 Um Triângulo Maçônico é a associação de três ou mais irmãos regulares,
efetivos em seu quadro, com um mínimo de três Mestres Maçons sob a Presidência de
um destes, em pleno gozo de seus direitos maçônicos, reconhecido pelo GRANDE
ORIENTE DE SANTA CATARINA, que se reúnem com o propósito de dar início ao
```

```
Regulamento Geral
processo de formação de uma futura Loja Maçônica.
```
Parágrafo Único Em orientes onde não existir loja regular do GOSC, não haverá
necessidade de membros efetivos. **(Alterado pela Lei nº 118/GOSC/2014-2017, de 24
de setembro de 2016)**

```
Art. 30 As lojas e triângulos, para adquirirem personalidade jurídica, deverão
registrar seus estatutos no Cartório de Registro Civil de Títulos e Documentos e sua
inscrição no Cadastro de Contribuintes de Pessoas Jurídicas - CNPJ.
```
```
Seção I
Da Posse dos Veneráveis Mestres
```
```
Art. 31 A posse do venerável mestre dar-se-á após a diplomação. A instalação
deverá ser realizada pelo Grão-Mestre ou por comissão por ele designada. (Alterado
pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
§ 1º (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
§ 2º Os eleitos para os cargos em Loja, respeitadas as especificações de cada
Rito, tomarão posse na primeira quinzena do mês de julho ou na primeira Sessão
subseqüente a diplomação, em Sessão Especial. (Redação dada pela Lei n. 87/2009, art.
4°).
```
```
§ 3º O Rito que não dispuser de cerimonial próprio, poderá, desde que
aprovado pelo Grão-Mestre, incorporar o cerimonial de outro Rito.
```
```
Seção II
Da Administração das Lojas e Triângulos
```
```
Art. 32 É assegurada às lojas e triângulos da jurisdição, plena autonomia no que
seja peculiar a sua administração nos termos e de acordo com a Constituição e demais
legislação. (Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
Art. 33 A autonomia da Loja e do Triângulo, conforme o Rito adotado será
assegurado:
```
```
I – pela eleição dos cargos eletivos que compõem suas administrações.
```
```
Parágrafo Único (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de
setembro de 2016)
```
II – pela administração própria no que se refere ao exclusivo interesse,
especialmente:

a) a fixação e a arrecadação das contribuições de seus obreiros;
b) a aplicação de suas receitas; **(alterado pela Lei nº 118/GOSC/2014-2017, de
24 de setembro de 2016)**


**Regulamento Geral**
c) pela organização de atividades complementares, tais como: culturais,
beneficentes, sociais e recreativas.

```
Art. 34 As lojas e triângulos designam-se pelos títulos distintivos que
escolherem, desde que aprovados pelo Grão-Mestre, e terão o número de Registro do
GRANDE ORIENTE DE SANTA CATARINA em seqüência numérica crescente.
```
**Art. 35** O venerável é a Primeira Luz e o gestor da loja perante os seus irmãos,
representa a loja, ativa e passivamente, em juízo e fora dele, em todas as relações
maçônicas e não maçônicas, cabendo-lhe não só designar os oficiais não eleitos, seus
respectivos adjuntos e as comissões, mas também guiar, orientar e programar os
trabalhos.

```
§ 1o Substituem o venerável ou equivalente em suas ausências os irmãos 1º e 2º
vigilantes, respectivamente, não podendo iniciar, elevar ou exaltar se não tiverem sido
mestres instalados. (Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro
de 2016)
```
```
§ 2º No impedimento das luzes nominadas no parágrafo anterior, as sessões serão
realizadas pelo venerável de honra, ou na ausência deste, pelo mestre que a loja escolher.
(Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
Art. 36 Não será admitida a eleição do Mestre Maçom para o mesmo cargo em
sua Loja, ou de qualquer Loja jurisdicionada, por período superior a um ano, exceto no
caso de reeleição.
```
### § 1º

```
A reeleição referida no caput deste artigo é permitida uma única vez,
```
ressalvada a situação prevista no parágrafo seguinte.

### § 2º

```
Poderá o MESTRE maçom se candidatar a qualquer cargo eletivo já
exercido, desde que:
```
```
a) fora do exercício do cargo por período mínimo de um ano;
```
```
b) haja recusa formal, registrada em ata, pelos demais mestres maçons aptos ao
exercício do cargo.
```
```
Seção III
Do Regimento Interno Das Lojas e Triângulos
```
```
Art. 37 Cada loja e triângulo deve elaborar seu Regimento Interno, cujas
disposições não poderão conflitar com a Constituição, e demais legislação do GRANDE
ORIENTE DE SANTA CATARINA. (Alterado pela Lei nº 118/GOSC/2014-2017, de
24 de setembro de 2016)
Art. 38 O Regimento Interno e as suas alterações, para terem vigência, deverão
obter aprovação prévia do GRANDE ORIENTE DE SANTA CATARINA.
```
```
Parágrafo Único (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de
```

```
Regulamento Geral
setembro de 2016)
```
```
Art. 39 O Regimento Interno deverá se aprovado pelo Grão-Mestre. (Alterado
pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
Parágrafo Único O Regimento Interno conterá, obrigatoriamente, cláusulas
irreformáveis e irrevogáveis para que jamais perca seu caráter essencialmente maçônico.
(Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
Seção IV
Das Luzes, Dignidades e Oficiais
```
```
Art. 40 Salvo exceção, respeitando-se especificidades e singularidades de cada
Rito, a administração de uma Loja é a seguinte:
```
```
I – Luzes: venerável, primeiro e segundo vigilantes e equivalentes; (Alterado pela
Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
II – Dignidades: O Orador, o Secretário e o Tesoureiro.
III – Oficiais: são regulados pelos Ritos reconhecidos pelo GRANDE ORIENTE
DE SANTA CATARINA.
```
```
Parágrafo Único Se o Rito adotado for omisso, com exceção das Luzes, os
demais cargos poderão ter adjuntos.
```
**Art. 41** As atribuições das Luzes, Dignidades e Oficiais serão tratadas em
Legislação específica, respeitadas as tradições de cada Rito.

```
Seção V
Das Comissões das Lojas
```
```
Art. 42 Nos Regimentos Internos poderão constar tantas Comissões
Permanentes ou Especiais quanto suas respectivas Lojas acharem necessárias para o
bom desempenho da Oficina, além das seguintes Comissões Permanentes obrigatórias:
I – Comissão de Finanças;
II – Comissão de Ensino e Formação;
III – Comissão de Sindicância e Iniciação;
IV – Comissão de Planejamento. (Alterado pela Lei nº 128/GOSC/2017- 2020 ,
de 30 de novembro de 2018)
```
```
§ 1º A oficinas poderão instituir outras comissões para atingir seu objetivo e,
em casos especiais, determinar a reunião de duas ou mais comissões para, em conjunto,
estudarem e proporem solução sobre temas singulares.
```
```
§ 2º Não havendo número suficiente de obreiros em Loja para o
preenchimento das comissões:
```
```
I – poderão ser preenchidas, à exceção da Comissão de Sindicância e Iniciação,
as de maior interesse da Loja, de acordo com a prioridade de seus trabalhos.
```

**Regulamento Geral**

II – o obreiro integrante de uma Comissão poderá, cumulativamente, fazer parte
de outra, obedecido o número máximo de três.

```
Seção VI
Do Conselho das Lojas
```
```
Art. 43 O conselho das lojas é o órgão especial de assessoramento ao venerável
mestre que o presidirá, compondo-se exclusivamente daqueles que já ocuparam o cargo
de venerável, ou o equivalente, conforme o rito praticado pela loja. (Alterado pela Lei
nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
Seção VII
Dos Direitos das Lojas e Triângulos
```
```
Art. 44 São direitos das lojas e triângulos:
```
```
I – elaborar, modificar e cumprir seu Regimento Interno.
```
II – admitir obreiros em seu quadro por iniciação, filiação, regularização ou
transferência.

III – Tomar sob sua proteção, pela Cerimônia de Adoção de Lowtons,
descendentes, enteados ou tutelados de maçons, bem como patrocinar capítulos da Ordem
DeMolay e os Bethéis da Ordem Internacional das Filhas de Jó. **(Alterado pela Lei nº
118/GOSC/2014-2017, de 24 de setembro de 2016)**
IV – mudar de Rito, mediante prévia autorização do Grão- Mestrado.

V – corresponder-se com outras lojas regulares; **(alterado pela Lei nº
118/GOSC/2014-2017, de 24 de setembro de 2016)**
VI – fundir-se com outras lojas, mediante autorização do Grão-Mestrado.

VII – conferir graus, somente após exame de aptidão, observando-se o
interstício legal previsto na legislação, após expedição do respectivo placet; **(alterado
pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)**
VIII – fixar contribuições extraordinárias para fins determinados, bem como as
ordinárias.

IX – dispensar das taxas, até o total da quota que lhe cabe, as relativas à iniciação,
elevação, exaltação, filiação ou regularização
.
X – conceder distinções honoríficas aos seus membros e aos de outras lojas ou
potências regulares, de acordo com seu Regimento Interno; **(alterado pela Lei nº
118/GOSC/2014-2017, de 24 de setembro de 2016)**
XI – outorgar benefícios em favor de irmãos necessitados ou em apoio a obras
de finalidade maçônica.


**Regulamento Geral**

XII – excluir membros de seu Quadro, e consequentemente da Ordem, através
de deliberação da Loja, por maioria absoluta dos seus membros Mestres Maçons, em
sessão especialmente convocada, onde serão apreciados os fatos e poderá o acusado
prestar as informações e esclarecimentos que entender convenientes, no exercício do
contraditório. Sendo unânime a decisão, dela não caberá recurso ao Colegiado. (Redação
dada pela Lei n. 81/2005, art. 1°).

XIII – formar Conselho de Família para dirimir desarmonia surgida entre dois
ou mais membros do seu quadro de obreiros.

XIV – Requerer ao GOSC o registro de quite-placet concedido aos obreiros do
seu quadro; **(alterado pela Lei nº 155/GOSC/2020- 2023 , de 29 de março de 2008;
Vigência a partir de 24/12/2022)**

XV – expedir Quite-Placet ex-offício a obreiros de seu quadro na forma deste
Regulamento Geral, do Código de Procedimentos e do Regimento Interno da Loja.

XVI – propor, justificando ao Grão-Mestrado, a concessão de recompensas
maçônicas do GOSC para membros de seu quadro.

XVII – Solicitar ao GOSC a Expedição da Declaração de Irregularidade a
obreiros por falta de frequência e/ou por inadimplência. **(Alterado pela Lei nº
118/GOSC/2014-2017, de 24 de setembro de 2016)**
XVIII – fixar em seu Regimento Interno o período de recesso da Loja.

XIX - Propor emendas à Constituição, alterações e inclusões ao Regulamento
Geral e Código de Procedimentos, por intermédio do venerável de sua loja, junto ao
COLEGIADO.

Parágrafo Único As lojas poderão fundar organizações complementares
paramaçônicas, com personalidade jurídica própria.

```
Seção VIII
Dos Deveres das Lojas e Triângulos
```
```
Art. 45 São deveres da Loja e do Triângulo:
```
```
I – eleger anualmente a sua administração.
```
```
II – observar cuidadosamente tudo quanto for concernente ao espírito e forma
da Instituição e as leis e decisões do GRANDE ORIENTE DE SANTA CATARINA.
```
```
III – realizar Sessões de Instrução Maçônica sobre história, legislação,
simbologia e filosofia da Ordem, nos três graus simbólicos.
```
```
IV – Especializar-se na concretização dos objetivos maçônicos, na forma da
Constituição e demais Legislação do GOSC. (Alterado pela Lei nº 118/GOSC/2014-
2017, de 24 de setembro de 2016)
V – esforçar-se pela manutenção da harmonia no seio da Ordem, promovendo o
```

```
Regulamento Geral
maior entrelaçamento das famílias dos irmãos.
```
```
VI – diligenciar para que a Loja realize Cerimônia de Adoção de Lowtons, de
Consagração e de Exaltação Matrimonial nos Templos Maçônicos.
```
```
VII – prestar assistência material e moral aos seus obreiros, às viúvas, às irmãs
solteiras e aos ascendentes e descendentes de obreiros falecidos.
```
VIII – não admitir ou regularizar qualquer candidato sem permissão do Grão-
Mestrado.

```
IX – seguir e obedecer aos preceitos litúrgicos do Rito em que trabalha.
```
```
Seção IX
Das Proibições das Lojas e Triângulos
```
```
Art. 46 É proibido às lojas e triângulos:
```
```
I – admitir aos trabalhos maçons irregulares.
```
```
II – manter relações com lojas irregulares.
```
III – Efetivar em seu quadro maçom que não apresente quite-placet válido,
emitido pelo Grande Oriente de Santa Catarina, ou outro documento comprobatório de
sua regularidade e inatividade; **(alterado pela Lei nº 165, de 27 de outubro de 2025)**

```
IV – iniciar pessoas, elevar, exaltar, filiar e regularizar maçons antes de
recebidos os respectivos placets do GRANDE ORIENTE DE SANTA CATARINA.
```
```
V – iniciar ou colar grau sem observância das formalidades litúrgicas prescritas
nos rituais e antes de vencidos os interstícios, salvo sob autorização do Grão-Mestre.
```
```
VI – (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de
2016)
```
```
VII – ocupar-se de trabalhos litúrgicos alheios aos graus simbólicos.
```
VIII – realizar atos dentro do Templo em presença de pessoas não pertencentes à
Maçonaria, ressalvados os eventos que, por sua natureza, admitam tal comparecimento.

```
IX – tomar deliberações que atentem contra os Landmarks, a Constituição e
demais Legislação do GOSC. (Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de
setembro de 2016)
```
```
X - imprimir, publicar ou veicular, por qualquer meio de comunicação não
maçônico, assuntos que envolvam o Nome do Grande Oriente de Santa Catarina, sem a
expressa autorização do Grão Mestrado. (Redação dada pela Lei n. 81/2008, art. 1°).
```
```
XI – dirigir-se sobre assuntos maçônicos às autoridades não-maçônicas,
```

**Regulamento Geral**
ressalvados os casos de natureza administrativa e fiscal;

XII – Regularizar em seu quadro maçom que não apresente quite-placet inválido,
emitido pelo Grande Oriente de Santa Catarina, ou quite-placet, válido ou inválido,
emitido por potência regular; **(acrescentado pela Lei nº 165, de 27 de outubro de
2025)**

XIII – Filiar em seu quadro maçom que não comprove sua condição de membro
regular e ativo de uma loja simbólica jurisdicionada ao Grande Oriente de Santa
Catarina ou de uma loja simbólica jurisdicionada a potência maçônica regular não
sediada no Brasil, com a qual o GOSC mantenha Tratado de Reconhecimento e
Amizade. **(Acrescentado pela Lei nº 165, de 27 de outubro de 2025)**

```
Seção X
Do Patrimônio das Lojas e Triângulos
```
**Art. 47** O patrimônio das lojas e triângulos, registrado em seus próprios nomes,
é independente e desvinculado do patrimônio do GRANDE ORIENTE DE SANTA
CATARINA.

**Art. 48** As lojas e triângulos disporão do seu patrimônio, cuja aplicação é decidida
pelos membros de seu quadro, conforme seu Regimento Interno, a Constituição e demais
Legislações do GOSC. **(Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de
setembro de 2016)**

**Art. 49** Nenhuma loja poderá alienar bens imóveis sem expressa e prévia
autorização de 2/3 de seus membros, reunidos em Sessão Especial, especificamente
convocada para esse fim. **(Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de
setembro de 2016)**

```
Seção XI
Das Sessões das Lojas e Triângulos
```
**Art. 50** As sessões ritualísticas das lojas podem ser magnas, econômicas, ou
especiais.

```
I – Sessões Magnas:
```
```
a) iniciação, regularização, filiação e colação de graus;
b) posse;
c) inauguração ou sagração de Templo;
d) festividades e conferências maçônicas;
e) adoção de Lowtons;
f) pompa fúnebre;
g) caráter cívico-cultural;
h) confirmação, casamento civil e de bodas.
```

**Regulamento Geral**

```
II – Sessões Econômicas:
```
```
a) aquelas que tratem dos interesses da Ordem em geral e da Loja em particular;
b) finanças;
```
```
III – Sessões Especiais:
a) conselho de Família;
```
```
b) (Revogado pela Lei nº 81/ 2008 , art. 2°, de 29 de março de 2008)
```
```
c) pública e outras de interesse da loja. (Alterado pela Lei nº 118/GOSC/2014-
2017, de 24 de setembro de 2016)
```
```
d) de necessidade ou interesse da Loja.
```
```
§ 1º As Lojas cujos rituais possuem formas especificas quanto a nomenclatura e
de realização de suas sessões, desenvolverão por estes seus trabalhos, desde que não
infrinjam os princípios maçônicos. (Alterado pela Lei nº 93/2009, art. 1°, de 05 de
dezembro de 2009)
```
```
§ 2º Estando a Loja reunida em Sessão Econômica, poderá esta, promover
paralelamente Câmaras de Estudos. (Acrescentado pela Lei nº 93/20 0 9, art. 1°, de 05
de dezembro de 2009)
```
```
Art. 51 As sessões serão realizadas em Templo Maçônico, devidamente sagrados.
(Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
§ 1o Em sessão econômica do grau de aprendiz tratar-se-á apenas de admissão de
candidatos à iniciação, das instruções de grau e das questões a bem da Ordem em geral,
do quadro em particular. (Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de
setembro de 2016)
```
```
§ 2o Em sessão econômica do grau de companheiro tratar-se-á apenas do aumento
```
de salário dos aprendizes, das instruções de grau e das questões a bem da Ordem em geral,

do quadro em particular. **(Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de**

**setembro de 2016)**

```
§ 3 º Quando a magnitude da Sessão exigir poderá esta ser realizada em outro
```
local, desde que resguardado o sigilo maçônico.

§ 4º Aplica-se a este artigo o disposto nos parágrafos do artigo anterior. **(Alterado
pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)**

```
Art. 52 A realização de sessões públicas e de reuniões por videoconferência será
```
regulamentada no Código de Procedimentos. **(Alterado pela Lei nº 141/GOSC/2020-**


**Regulamento Geral**

**2023 , de 30 de novembro de 2020)**

```
Seção XII
Da Regularidade das Lojas e Triângulos
```
```
Art. 53 A regularidade de uma loja ou triângulo consiste na observância da
Constituição e demais Legislações do GOSC. (Alterado pela Lei nº 118/GOSC/2014-
2017, de 24 de setembro de 2016)
```
**Art. 54** São lojas irregulares:
I – aquelas que pertencerem a instituições maçônicas não reconhecidas.
II – as que, fazendo parte do GRANDE ORIENTE DE SANTA CATARINA, se
filiarem a qualquer outra potência maçônica.
III – aquelas que forem declaradas insubmissas à Constituição e às leis maçônicas
do GRANDE ORIENTE DE SANTA CATARINA.

**Art. 55** As oficinas que, fazendo parte do GRANDE ORIENTE DE SANTA
CATARINA, tiverem se filiado a outra potência maçônica e desejarem retornar, o farão
segundo preceitua a Constituição e demais Legislação do GOSC. **(Alterado pela Lei nº
118/GOSC/2014-2017, de 24 de setembro de 2016)**

```
Parágrafo Único As oficinas declaradas insubmissas pelo GRANDE ORIENTE
DE SANTA CATARINA poderão ser readmitidas caso sanada a falha que motivou sua
exclusão.
```
```
Seção XIII
```
```
Do Desligamento, Realinhamento e Justaposição
```
```
Das Lojas e Triângulos
```
```
Art. 56 É lícito a uma loja e a um triângulo desligarem-se do GRANDE ORIENTE
DE SANTA CATARINA, desde que obedecido a Constituição e demais Legislação do
GOSC. (Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
Parágrafo Único O desligamento de que trata este artigo diz respeito unicamente
à Loja ou Triângulo enquanto entidade civil, reservada ao Grande Oriente de Santa
Catarina a preservação, sob sua jurisdição, da Loja enquanto entidade estritamente
maçônica, visando sempre sua reestruturação sob nova administração. (Acrescentado
pela Lei nº 128/GOSC/2017- 2020 , de 30 de novembro de 2018)
```
```
Art. 57 O requerimento de desligamento de Loja ou Triângulo do Grande
Oriente de Santa Catarina, de que trata o artigo anterior, deverá ser acompanhado dos
```

```
Regulamento Geral
originais ou cópia de toda a sua documentação histórica, compreendendo os balaústres
e outros documentos de interesse do Grande Oriente de Santa Catarina, além dos rituais,
insígnias, Carta Constitutiva e Estandarte, sob pena de indeferimento. (Alterado pela
Lei nº 128/GOSC/2017- 2020 , de 30 de novembro de 2018)
```
```
Art. 58 Duas ou mais lojas do mesmo Rito, ou ritos diferentes, com prévia
autorização do Grão-Mestrado, poderão fundir-se em uma só.
```
**Art. 59 (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de
2016)**

```
Seção XIV
Da Suspensão e Restabelecimento de Lojas e Triângulos
```
```
Art. 60 Quando uma loja deixar de funcionar durante seis meses ou concluir pela
suspensão dos trabalhos, deverão proceder segundo a Constituição e demais Legislação
do GOSC. (Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
§ 1º O patrimônio, bens, recursos financeiros aplicados ou disponíveis da loja,
durante o tempo da suspensão, ficarão sob custódia do GRANDE ORIENTE DE
SANTA CATARINA. (Acrescentado pela Lei nº 118/GOSC/2014-2017, de 24 de
setembro de 2016)
```
```
§ 2º São nulos quaisquer atos praticados por lojas suspensas de seus direitos.
(Acrescentado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
Art. 61 A loja que suspender seus trabalhos por mais de 2 (dois) anos, sem ter
preenchido as obrigações impostas pelo Constituição e demais Legislação do GOSC,
será eliminada do quadro geral da Potência, sendo sua Carta Constitutiva cassada e seus
obreiros considerados inativos. (Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de
setembro de 2016)
```
```
Art. 62 Concedido o restabelecimento de uma loja, ser-lhe-á restituída os bens, e
os valores a ela pertencentes, que se acharem sob custódia do GOSC. (Alterado pela
Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
Parágrafo Único Findo o prazo de dois anos e não voltando a loja a se restabelecer,
os bens, e os valores serão automaticamente incorporado ao do GOSC, respeitando o
Estatuto Social da Associação. (Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de
setembro de 2016)
```
```
Seção XV
Das Funções Judiciais em Lojas e Triângulos
```
```
Art. 63 (Revogado pela Lei nº 81/ 2008 , art. 3°, de 29 de março de 2008)
```

**Regulamento Geral**

**Art. 64** No caso de contrariedade de ato do Grão-Mestre, cabe a loja pedido de
reconsideração, em sendo negada, poderá ser interposto recurso ao COLEGIADO.
**(Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)**

**Art. 65** Em caso de recurso contra ato do Grão-Mestre, este proferirá despacho de
sustentação ou reforma no prazo de 10 (dez) dias. **(Alterado pela Lei nº
118/GOSC/2014-2017, de 24 de setembro de 2016)**

**Art. 66 (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de
2016)**

```
Subseção I
Do Conselho De Família
```
**Art. 67** O Conselho de Família é uma junta de conciliação maçônica, para dirimir
desarmonia surgida entre dois ou mais membros do quadro da uma loja, conforme
previsto no Título Art. 67 – A do Código de Procedimentos. **(Alterado pela Lei nº
118/GOSC/2014-2017, de 24 de setembro de 2016)**

§ 1º Não havendo harmonização, a loja pela maioria absoluta, de seus membros,
expedirá o placet ex-ofício a quem o merecer. **(redação dada pela Lei nº
118/GOSC/2014-2017)**

§ 2º Compõem o conselho de família as luzes da loja e seus Mestres Instalados e
compete-lhes o conhecimento, o estudo e a solução dos casos levantados. **(Alterado pela
Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)**

§ 3º O Venerável da Loja designará os obreiros que julgar necessário à
realização das investigações.

**Art. 68 (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de
2016)**

**Art. 68 - A (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de
2016)**

**Art. 69** Nas controvérsias de natureza não-maçônica entre irmãos, lojas ou
qualquer Órgão da estrutura organizacional do GRANDE ORIENTE DE SANTA
CATARINA, as partes deverão solicitar a intermediação estritamente conciliatória da
Ordem, que se dará pelo Juízo Informal de Conciliação.

```
Subseção II
```
```
Do Tribunal do Júri
```

**Regulamento Geral**

```
Art. 70 (Revogado pela Lei nº 81 /2008, art. 2°, de 29 de março de 2008)
```
```
Capítulo V
Dos Maçons
```
```
Seção I
Dos Requisitos Para a Admissão
```
```
Art. 71 A iniciação de qualquer candidato na maçonaria, somente poderá ser
efetivada por deliberação de uma loja obedecida a Constituição e demais legislação do
GOSC. (Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
Art. 72 A admissão do candidato subordina-se aos seguintes requisitos:
```
```
I – ser do sexo masculino, estar em pleno gozo da capacidade civil, em
condições de executar a ritualística e ter idade mínima de vinte e um (21) anos. Sendo
possível ao Lowton e ao Demolay ser iniciado ao completar 18 anos. (Alterado pela Lei
nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
II – ter bons costumes e reputação ilibada, apurados em rigorosa investigação
que abranja o passado e o presente.
```
III – possuir no mínimo, nível de instrução que o torne capaz de compreender,
aplicar e difundir os ideais da instituição.

```
IV – ter profissão ou meio de vida lícito, cuja renda o capacite a suportar os
encargos pecuniários maçônicos, sem prejuízo de suas outras responsabilidades,
inclusive familiares.
```
```
V – não professar ideologia que se oponha aos princípios da Ordem.
```
```
VI – residir de forma habitual, contínua e comprovada, ou manter domicílio
```
profissional efetivo há pelo menos 1 (um) ano no município sede ou em município

limítrofe, sendo vedada a utilização de endereços ocasionais ou temporários, de imóveis

destinados exclusivamente a lazer ou temporada, ou a fins não residenciais, bem como de

qualquer outro artifício que não caracterize efetiva moradia permanente ou vínculo

profissional real. **(Alterado pela Lei nº 173, de 03 de abril de 2026; Regulamentado**

**pelo Dec**  **096/GOSC/2017- 2020 de 22 de novembro de 2017 da E**  **V**  **)**

```
1 - No caso de Loja e Triângulo fundado e instalado até 11/09/2010:
```
```
a) Prioritariamente no município sede da Loja e/ou Triângulo;
```
```
b) Em município limítrofe ao da sede da Loja e/ou Triângulo;
```

**Regulamento Geral**

c) Na microrregião onde está localizado o município sede da Loja, em^ sendo^
esta responsável por projeto oficial de expansão da Potência, visando instalação de
Triângulo ou de uma nova Loja.

d) quando o candidato residir em município diverso e a Loja interessada for de
município limítrofe, será exigida a anuência das Lojas situadas no município de residência
do profano, nos termos do parágrafo único.
Parágrafo único. Aplicam-se as seguintes regras ao pedido de anuência referido
na alínea "d" do § 2º:

I - o pedido será formulado obrigatoriamente por meio do Canal de
Comunicação Online do GOSC e, facultativamente, por outras vias;

II - de posse das pranchas de anuência, a Loja comunicará ao GOSC para dar
início ao pedido de publicação;

III - as Lojas consultadas terão o prazo de 30 (trinta) dias para manifestar sua
decisão, indicando se possuem ou não interesse em iniciar o profano;

```
IV - decorrido o prazo sem manifestação, o silêncio importará anuência.
(Acrescentado pela Lei nº 172, de 03 de abril de 2026)
```
```
2 - No caso de Loja e Triângulo fundado e instalado a partir de 12/09/2010:
```
```
a) No município sede da Loja e/ou Triângulo;
```
b) Em município limítrofe ao da sede da Loja e/ou Triângulo, desde que^ não^
haja neste município, Loja e/ou Triângulo do Grande Oriente de Santa Catarina;
c) Na microrregião onde está localizado o município sede da Loja, em sendo
esta responsável por projeto oficial de expansão da Potência, visando instalação de
Triângulo ou de uma nova Loja. **(Alterado pela Lei nº 102/2010, art. 1°, de 04 de
dezembro de 2010; Regulamentado pelo Decreto nº 39 de 15 de março de 2011)**

```
VII – aceitar a existência de Princípio Criador;
```
VIII – Comprometer-se, por escrito, a observar os princípios, costumes,
Constituição e demais legislação do GOSC. **(Alterado pela Lei nº 118/GOSC/2014-
2017, de 24 de setembro de 2016)**

§ 1º Além das informações gerais, as sindicâncias ou investigações, dirá
sobre a inserção familiar, econômica, financeira, política, ideológica, cultural e
profissional do candidato.

§ 2º O não enquadramento em qualquer dos requisitos anteriores ou sua
insuficiência, impede a admissão. **(Alterado pela Lei nº 118/GOSC/2014-2017, de 24
de setembro de 2016)**

§ 3º A admissão ao quadro de uma loja se dará por: **(alterado pela Lei nº 165,
de 27 de outubro de 2025)**


**Regulamento Geral**

```
I – Iniciação; (alterado pela Lei nº 165, de 27 de outubro de 2025)
```
```
II – Transferência; (alterado pela Lei nº 165, de 27 de outubro de 2025)
```
III – Efetivação: quando se tratar de maçom portador de quite-placet no prazo
de validade, emitido pelo Grande Oriente de Santa Catarina, ou outro documento
comprobatório de sua regularidade e inatividade; **(alterado pela Lei nº 165, de 27 de
outubro de 2025)**

IV – Regularização: quando se tratar de maçom que apresente quite-placet fora
do prazo de validade emitido pelo Grande Oriente de Santa Catarina, ou quite-placet
emitido por outra potência regular; **(acrescentado pela Lei nº 165, de 27 de outubro de
2025)**

V – Filiação: quando se tratar de maçom que comprove sua condição de
membro efetivo, regular e ativo de uma loja simbólica jurisdicionada ao Grande Oriente
de Santa Catarina ou de uma loja simbólica jurisdicionada a potência maçônica regular
não sediada no Brasil, com a qual o GOSC mantenha Tratado de Reconhecimento e
Amizade. **(Acrescentado pela Lei nº 165, de 27 de outubro de 2025)**

```
Art. 73 Não podem ser propostos à iniciação:
```
```
I – os estrangeiros residentes no Brasil há menos de dois anos e os que não
tiverem permanência definitiva no País.
```
```
II – as pessoas que, por qualquer motivo, estejam impedidas de manifestar a
própria vontade.
```
```
Seção II
Do Processo de Sindicância
```
**Art. 74** Os maçons ou lojas, que se opuserem à Iniciação de um candidato,
comunicarão, por escrito e por intermédio de suas lojas, suas razões ao GRANDE
ORIENTE DE SANTA CATARINA, o qual dará o conhecimento à Loja.

§ 1º A publicação de candidato no Boletim Oficial terá a validade de 12 (doze)
meses, contados da data da publicação. Ultrapassado o prazo sem o efetivo ingresso no
quadro de obreiros, e permanecendo o interesse da loja, realizar-se-á, a pedido desta, nova
publicação. No caso de inexistência de oposição, será realizada nova sindicância.
**(Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)**

§ 2º Não é permitido ao Maçom escusar-se de sindicar candidatos à Iniciação,
salvo declarando suspeição, nos seguintes casos.

```
I – parentesco;
II – amizade;
III – inimizade.
```

**Regulamento Geral**
§ 3º As sindicâncias serão conclusivas pelo acolhimento ou não do pedido de
Iniciação e têm por finalidade evitar que candidatos com ideais, conduta e valores morais
incompatíveis com a doutrina maçônica venham a ingressar na Maçonaria.

I – Os proponentes e os sindicantes são responsáveis, perante a loja e a Ordem,
pelas informações prestadas, sendo permitida aos proponentes a retirada do processo
antes da leitura das sindicâncias. **(Alterado pela Lei nº 118/GOSC/2014-2017)**

II - Caso sejam comprovadas desídias ou falsas declarações a respeito de
candidato em abono ou em prejuízo deste, caberá ao Orador ou cargo equivalente
representar contra os que assim procederem.

§ 4º Têm acesso sigiloso ao processo de sindicância: **(alterado pela Lei nº
118/GOSC/2014-2017, de 24 de setembro de 2016)**

I – O GOSC através do Grão-Mestre, do Grão-Mestre Adjunto e de seus
secretários inseridos no processo. **(Alterado pela Lei nº 118/GOSC/2014-2017, de 24
de setembro de 2016)**

II – o Venerável Mestre;
III – o Secretário;
IV – o Orador ou cargo equivalente;
V – o Mestre sindicante;
VI – a Comissão de Sindicância.
VII – O proponente. **(Acrescentado pela Lei nº 118/GOSC/2014-2017, de 24 de
setembro de 2016)**

```
§ 5º (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)^
```
§ 6º A oposição formal ao candidato deverá ocorrer no prazo máximo de trinta
dias a contar da data da publicação no Boletim do Grande Oriente de Santa Catarina e:
**(alterado pela Lei nº 128/GOSC/2017- 2020 , de 30 de novembro de 2018)**

```
I – a identificação maçônica do opositor deverá ser revelada;
```
II – o opositor deverá narrar detalhadamente os fatos que fundamentam a
oposição por escrito ou oralmente na loja em que o candidato foi proposto, em sessão de
aprendiz; **(alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)**

III - É vedado ao Maçom deixar de comunicar fundamentadamente qualquer ato
ou fato que desabone o candidato.

IV - É vedado ao Maçom comunicar qualquer ato ou fato inverídico que desabone
o candidato.

V – os opositores serão previamente comunicados pelo venerável mestre, por
escrito, informando o local, data e horário da sessão em que a matéria será apreciada;


**Regulamento Geral
(alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)**

VI - O Maçom opositor poderá comparecer pessoalmente à sessão em que a
matéria for apreciada.

VII - Se o opositor for de outra Loja jurisdicionada ao GOSC, este deverá
efetuá-la mediante prancha expedida por sua Oficina, comunicando a apreciação e
deliberação desta, e endereçada ao Grande Oriente de Santa Catarina e a Loja de origem
do candidato.

VIII - Se a oposição tiver origem em Lojas filiadas a Potencias de relacionamento
com o Grande Oriente, esta deverá vir chancelada pela Potencia de origem diretamente
ao Grande Oriente de Santa Catarina que encaminhará à Loja proponente.

IX – a falta da comunicação ao opositor implicará anulação do processo de
sindicância ou da iniciação, se ocorrida, imputará responsabilidade ao venerável mestre
nos termos da Constituição e demais legislação do GOSC; **(alterado pela Lei nº
118/GOSC/2014-2017, de 24 de setembro de 2016)**

X – A oposição será anexada à proposta de sindicância e lida ou apresentada por
ocasião da sua apreciação antes do escrutínio secreto. **(Alterado pela Lei nº
118/GOSC/2014-2017, de 24 de setembro de 2016)**

§ 7º Na data e hora marcada para a apreciação da oposição na Ordem do Dia, o
venerável mestre apresentará na íntegra a oposição; ou concederá a palavra ao opositor
ou ao representante da loja opositora para que apresentem suas razões. **(Alterado pela
Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)**

§ 8º Terminada a exposição o Venerável Mestre solicitará a todos os visitantes,
inclusive ao opositor, se for o caso, que cubra o Templo, temporariamente, para
que a Loja delibere sobre a procedência ou não dos motivos da oposição.

I - Estando presentes somente os membros do Quadro da Loja a palavra será
franqueada para que os Irmãos se manifestem sobre a oposição ou busquem
esclarecimentos necessários para formação de juízo sobre a matéria. Em seguida,
reinando silêncio, ocorrerá o processo de votação nominal sobre a procedência ou não
da oposição. A critério da Loja poderá ser utilizado o escrutínio secreto como forma de
votação.

§ 9º transcorridos 30 (trinta dias) da publicação do candidato no boletim do
Grande Oriente de Santa Catarina, não havendo oposição, o escrutínio secreto poderá ser
realizado. **(Redação dada pela Lei nº 124/GOSC/2017- 2020 , de 24 de junho de 2017)**

§ 10 Concluído o processo de admissão do candidato, o Venerável Mestre
providenciará a realização do escrutínio secreto, cuja votação, tomará parte
exclusivamente os membros do Quadro, inclusive Aprendizes e Companheiros.

§ 11 Lido o expediente na íntegra pelo Venerável Mestre, sem mencionar os
nomes dos apoiadores e dos sindicantes, será aberta discussão sobre a admissão do
candidato. Uma vez iniciada a leitura do expediente, o escrutínio não poderá ser


**Regulamento Geral**
interrompido, suspenso ou adiado, devendo ser concluído na mesma sessão.

§ 12 Terminada a discussão, o escrutínio secreto será executado de conformidade
com a orientação do ritual adotado pela Loja.

I - Distribuídas as esferas, o Venerável Mestre determinará que os oficiais façam
o giro em Loja, colhendo, em sigilo, o voto e a sobra de cada obreiro.

II - Será conferido o número de obreiros com o número de esferas recolhidas.
Havendo divergência repete-se a votação.

§ 13 Caso o escrutínio não produza nenhuma esfera preta, o candidato está
aprovado, sendo declarado limpo e puro pelo Venerável Mestre que poderá revelar os
nomes dos proponentes e sindicantes.

§ 14 Caso o escrutínio produza até duas esferas pretas a votação será repetida
para verificar se houve engano. Confirmado o resultado será solicitado que os
opositores esclareçam, por escrito, até a próxima sessão ordinária, as suas razões.

I - Nesta sessão ordinária, os Irmãos que expressaram seus votos pela esfera preta
deverão encaminhar, em pranchas, os motivos da oposição. O Venerável Mestre as lerá
em Loja, omitindo os nomes dos opositores. Em seguida, abrirá a discussão sobre o
assunto e o fará decidir por votação secreta, somente entre os Irmãos do Quadro, sendo
necessária a decisão favorável de dois terços dos Irmãos presentes, para que o pedido de
iniciação seja aceito.

II - Caso o candidato seja aprovado, as oposições serão devolvidas aos seus
autores, preservando o sigilo da identidade dos opositores.

§ 1 Caso o opositor não apresente o motivo da oposição, considerar-se-á aprovado
o candidato.

§ 16 Caso o escrutínio produza três esferas pretas, o Venerável Mestre, na mesma
sessão, colherá nova votação, para verificar possível engano. Mantido o resultado, o
candidato estará reprovado.

§ 17 Caso o escrutínio produza quatro ou mais esferas pretas, o candidato estará
reprovado.

§ 18 O nome do candidato reprovado será lançado no Livro Negro, quando as
restrições forem de ordem moral e ou ética, ou no Livro Amarelo quando por outro
motivo, ou não explicitadas.

§ 19 A reprovação será comunicada ao Grande Oriente de Santa Catarina, por
prancha firmada pelo Venerável Mestre e Secretário, para que o nome do candidato seja
lançado no Livro próprio. Sendo que o processo será remetido ao Grande Oriente de
Santa Catarina para arquivo.

§ 20 Aprovado o candidato, o processo será arquivado na Secretaria da Loja, e os
nomes dos proponentes e sindicantes serão transcritos em ata.


**Regulamento Geral**

§ 21 O candidato reprovado só poderá ser proposto na mesma Loja, ou em
outra, depois de decorridos doze meses da decisão, desde que a reprovação não tenha
sido inscrita no Livro Negro.

I - A Loja somente poderá iniciar o processo de iniciação de um candidato
reprovado em outra após o pronunciamento desta, a qual terá o prazo de sessenta dias
para declarar as razões da recusa.

II - No caso da Loja notificada não cumprir o prazo estabelecido no parágrafo
anterior o processo terá prosseguimento.

§ 22 Será nula a iniciação de candidato reprovado em qualquer Loja, desde que
não tenha sido notificada a Loja que, originalmente o recusou ou que esteja inscrito em
Livro Negro. **(Alterado pela Lei nº 98/2010, art.3, de 13 de setembro de 2010)**

**Art. 75** Constará do prontuário do candidato, além da petição, as sindicâncias,
cópia da página do Boletim Oficial onde consta a publicação do nome do não-maçom à
iniciação, e todos os demais documentos que a ele se referirem, incluindo o(s) nome(s)
do(s) proponente(s).

```
Seção III
```
```
Da Iniciação
```
```
Art. 76 É vedada a iniciação de mais de sete candidatos em uma mesma sessão,
salvo com autorização prévia do Grão-Mestre. (Alterado pela Lei nº 128/GOSC/2017-
2020 , de 30 de novembro de 2018)
```
```
§ 1º Os candidatos aprovados deverão ser iniciados na data prevista no placet de
iniciação, findos os quais o expediente perderá seus efeitos, sendo necessária nova
expedição do placet. (Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro
de 2016)
```
```
§ 2o Nenhum candidato será iniciado sem que a loja tenha o placet expedido pelo
```
GRANDE ORIENTE DE SANTA CATARINA. **(Alterado pela Lei nº**

**118/GOSC/2014-2017, de 24 de setembro de 2016)**

```
§ 3o Nenhum candidato pode, simultaneamente, ser alvo de indicação em mais de
```
uma loja ou triângulo e nem a loja poderá iniciar um candidato sindicado por outra.

**(Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)**

```
§ 4º O candidato indicado e publicado por uma loja ou triângulo só poderá ser
iniciado por outra loja ou triângulo caso autorizada formalmente pela loja da última
publicação, mediante nova publicação. (Alterado pela Lei nº 118/GOSC/2014-2017,
de 24 de setembro de 2016)
```
```
Art. 77 A iniciação deve ser realizada com todas as formalidades ritualísticas e
```

```
Regulamento Geral
litúrgicas.
```
```
Art. 78 São Maçons todos os que houverem sido comprovadamente iniciados
em lojas simbólicas de Potência Maçônica regular.
```
```
Parágrafo Único É terminantemente proibido qualquer ato que venha a molestar
o candidato ou expô-lo ao ridículo, antes ou durante o processo de iniciação.
```
```
Seção IV
Da Filiação
```
```
Art. 79 Os membros ativos de uma Loja declarada irregular não podem ser
filiados em outra Loja sem a expressa autorização do Grão-Mestre.
```
```
Art. 80 O Maçom portador de quite-placet com menos de um ano de vigência,
poderá filiar-se a qualquer Loja da jurisdição.
```
```
Art. 80 - A (Revogado pela Lei nº 165, 27 de outubro de 2025)
```
```
Parágrafo Único (Revogado pela Lei nº 165, 27 de outubro de 2025)
```
```
Art. 81 (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de
2016)
```
```
Art. 82 (Revogado pela Lei nº 165, 27 de outubro de 2025)
```
```
Seção V
```
```
Da Regularização
```
```
Art. 83 O maçom poderá:
I – Transferir-se de uma loja a outra, sendo ambas jurisdicionadas ao Grande
```
Oriente de Santa Catarina, mediante:

```
a) Aprovação de seu pedido de transferência pela loja de destino, mediante
```
escrutínio secreto;

```
b) Solicitação da transferência pela loja de destino;
c) Autorização da transferência pela loja de origem;
d) Expedição do Placet de Transferência pelo Grande Oriente de Santa Catarina.
```

**Regulamento Geral**

```
II – Efetivar-se em uma loja jurisdicionada, se portador de quite-placet no prazo
```
de vigência, emitido pelo Grande Oriente de Santa Catarina, mediante:

```
a) Aprovação de seu pedido pela loja que desejar integrar como membro efetivo,
```
regular e ativo, mediante escrutínio secreto;

```
b) Expedição do Placet de Efetivação pelo Grande Oriente de Santa Catarina.
```
```
III – Regularizar-se em uma loja jurisdicionada, se portador de quite-placet
```
emitido por outra potência regular, ou quite-placet fora do prazo de validade emitido pelo

Grande Oriente de Santa Catarina, mediante:

```
a) Declaração, por escrito, de que após a expedição do quite-placet apresentado
```
para sua regularização, não se efetivou, filiou ou, por qualquer outro meio, frequentou ou

tornou-se membro de qualquer instituição maçônica, regular ou irregular;

```
b) Aprovação de seu pedido pela loja que desejar integrar como membro efetivo,
```
regular e ativo, mediante escrutínio secreto;

```
c) Publicação do pedido de regularização no Boletim Oficial, pelo prazo de 30
```
(trinta) dias;

```
d) Expedição do Placet de Regularização pelo Grande Oriente de Santa Catarina;
IV – Regularizar-se na loja que expediu contra si placet ex-officio, mediante:
a) Aprovação de seu pedido pela loja que expediu contra si placet ex-officio,
```
mediante escrutínio secreto;

```
b) Publicação do pedido de regularização no Boletim Oficial, pelo prazo de 30
```
(trinta) dias;

```
c) Expedição do Placet de Regularização pelo Grande Oriente de Santa Catarina.
(Alterado pela Lei nº 165, de 27 de outubro de 2025)
V – Filiar-se em mais de uma loja, se membro efetivo de uma loja jurisdicionada,
```
desde que sua filiação seja aprovada e solicitada ao Grande Oriente de Santa Catarina

pela loja de destino. **(Acrescentado pela Lei nº 165, de 27 de outubro de 2025)**

```
Seção V – A
Da Transferência
```
```
Art. 83-A O maçom poderá transferir-se quando for membro regular e ativo de
uma loja jurisdicionada ao GOSC. (Alterado pela Lei nº 118/GOSC/2014-2017, de 24
de setembro de 2016)
```

**Regulamento Geral**

```
I – estar em dia com as obrigações que contraiu com a Loja de Origem;
```
```
II – apresente pedido expresso a Loja cujo quadro deseja integrar;
```
III - obtenha das Lojas de origem e destino comunicação formal, que deve ser
encaminhada ao GOSC;

IV- A transferência será efetivada com a expedição do placet, após o ato ter sido
publicado no Boletim Oficial do GOSC. **(Alterado pela Lei nº 86/2008, art. 2°, de
27 de setembro de 2008)**

Parágrafo Único A Transferência do Maçom só será efetivada após a expedição
do respectivo placet, seguida de sua aprovação pela Loja que o receberá, e da publicação
em Boletim Oficial. **(Acrescentado pela Lei nº 86/20 0 8, art. 2°, de 27 de setembro de
2008 )**

```
Seção VI
Dos Graus
```
```
Art. 84 Ao Maçom são atribuídos três graus:
I – 1º Grau: Aprendiz Maçom.
II – 2º Grau: CompanheiroMaçom.
III – 3º Grau: Mestre Maçom.
```
**Art. 85** Tem direito à ascensão ao grau de companheiro maçom e deste ao de
mestre maçom, o aprendiz maçom que demonstrou perfeito conhecimento da liturgia,
ritualística, simbologia e legislação maçônicas, bem como das instruções e seus
complementos, verificados em apresentação de trabalhos escritos, exames práticos e
orais. **(Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)**

**Art. 86** O aprendiz, para ser elevado ao grau de companheiro, deverá ser proposto
pela administração da loja depois de cumprir os seguintes critérios: **(alterado pela Lei
nº 118/GOSC/2014-2017, de 24 de setembro de 2016)**

§ 1º Ter completado o período mínimo de dezoito meses de atividades maçônicas.
**(Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)**

§ 2º Ter participado de no mínimo 40 (quarenta) sessões e/ou câmaras de estudos
do grau de aprendiz. **(Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro
de 2016)**

§ 3º Ter no mínimo 75% (setenta e cinco por cento) de frequência nas sessões de
sua loja, ou de visitas programadas pela administração de sua Loja. **(Alterado pela Lei
nº 118/GOSC/2014-2017, de 24 de setembro de 2016)**


**Regulamento Geral**

```
Art. 87 O companheiro, para ser exaltado ao grau de mestre, deverá ser proposto
pela administração da loja depois de cumprir os seguintes critérios: (alterado pela Lei
nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
§ 1º Ter completado o período mínimo de dezoito meses de atividades maçônicas
no grau de companheiro. (Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de
setembro de 2016)
```
```
§ 2º Ter participado de no mínimo 20 (vinte) sessões e/ou câmaras de estudos do
grau de companheiro. (Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro
de 2016)
```
```
§ 3º Ter no mínimo 75% (setenta e cinco por cento) de frequência nas sessões de
sua loja, nos últimos 18 (dezoito) meses. (Alterado pela Lei nº 118/GOSC/2014-2017,
de 24 de setembro de 2016)
```
```
§ 4º Conta-se para o percentual de frequência exigido no parágrafo terceiro as
sessões dos graus de aprendiz e companheiro. (Alterado pela Lei nº 118/GOSC/2014-
2017, de 24 de setembro de 2016)
```
```
Art.87-A (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de
2016)
```
```
Art. 87-B (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de
2016)
```
```
Art. 88 Para as elevações e exaltações, previstas nos artigos anteriores, é
necessário que seja cumprida a formação maçônica estipulada pelo GOSC. (Alterado
pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
Art. 89 Aceito por maioria o pedido do vigilante correspondente, será o
candidato examinado quanto aos sinais, toques, palavras e doutrinas do grau, não
podendo ser elevado ou exaltado na mesma Sessão que o aprovou.
```
```
Parágrafo Único Sendo rejeitado o pedido, poderá o mesmo ser renovado quando
os respectivos vigilantes assim o entenderem.
```
```
Art. 90 Aprovado, o candidato será elevado ou exaltado, atendidas as
formalidades estabelecidas nos rituais.
```
Parágrafo Único Considera-se investido, nos graus previstos neste Regulamento
Geral, o Maçom que estiver de posse do título, o que significa terem sido preenchidas
todas as formalidades essenciais, que são: a iniciação, a elevação e a exaltação, com os
juramentos ritualísticos e o pagamento das taxas e emolumentos pertinentes ao GRANDE
ORIENTE DE SANTA CATARINA.

```
Seção VII
```

```
Regulamento Geral
Da Situação Individual Do Maçom
```
```
Subseção I
Dos Direitos Do Maçom
```
```
Art. 91 São direitos do Maçom:
```
I – a igualdade perante a Lei.
II – a livre manifestação do pensamento nos meios maçônicos, sem dependência
de autorização, respondendo cada um, nos casos e na forma da lei, pelos excessos e
abusos.
III – a inviolabilidade da liberdade de consciência e de crença.
IV – a justa proteção moral e material para si e sua família.
V – propor, discutir e votar, nos termos estabelecidos nas leis maçônicas.
VI – de acordo com o Código Eleitoral votar e ser votado, para todos os cargos
eletivos em loja e do GRANDE ORIENTE DE SANTA CATARINA; **(alterado pela Lei
nº 118/GOSC/2014-2017, de 24 de setembro de 2016)**
VII – transferir-se de uma para outra loja da instituição, observadas as
disposições legais ou regulamentares. **(Alterado pela Lei nº 118/GOSC/2014-2017, de
24 de setembro de 2016)**
VIII – filiar-se a mais de uma Loja da jurisdição desde que preserve a frequência
e recolha, através da Loja da qual é Membro Efetivo, a captação mensal e os demais
encargos devidos ao GRANDE ORIENTE DE SANTA CATARINA. **(Alterado pela Lei
nº 128/GOSC/2017- 2020 , de 30 de novembro de 2018)**

§ 1º O Maçom filiado (Art. 80-A) exercerá os seus direitos, inclusive o previsto
no inciso VI deste artigo, unicamente e exclusivamente na Loja da qual for membro
efetivo. **(Acrescentado pela Lei nº 128/GOSC/2017- 2020 , de 30 de novembro de 2018)**

§ 2º É admissível a filiação a Lojas jurisdicionadas ao Grande Oriente de Santa
Catarina, de Maçons membros efetivos de Lojas jurisdicionadas a Potências Maçônicas
regulares não sediadas no Brasil, com as quais o GOSC mantenha Tratado de
Reconhecimento e Amizade. **(Acrescentado pela Lei nº 128/GOSC/2017- 2020 , de 30
de novembro de 2018)**

§ 3º Os Obreiros que se enquadram na condição prevista no parágrafo anterior
não poderão votar, nem ser votados, e serão isentos de frequência e de contribuição
financeira ao GOSC. **(Acrescentado pela Lei nº 128/GOSC/2017- 2020 , de 30 de
novembro de 2018)**

```
Art. 92 É assegurado ao Maçom:
```
```
I - a expedição de certidões requeridas para a defesa dos direitos próprios,
através da Loja, bem como para esclarecimento de negócios administrativos.
```
```
II – o direito de representar oral ou por escrito; (Alterado pela Lei nº
118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
III – ser parte legítima para pleitear, através da sua loja, a anulação ou declaração
de nulidade de atos lesivos ao patrimônio do GOSC; (Alterado pela Lei nº
```

```
Regulamento Geral
118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
IV - solicitar apoio de seus irmãos quando candidato ao desempenho do mandato
de representação popular, no mundo político partidário.
```
```
V - pertencer como membro correspondente ou filiado a lojas de pesquisas e
estudos, mesmo situadas em outro Oriente.
```
VI – Solicitar licença das atividades da Loja por até um ano, prorrogável por
igual período mediante pedido expresso. **(Alterado pela Lei nº 134/GOSC/2017- 2020 ,
de 28 de junho de 2019)**

§ 1º Ao deferir o pedido de licença, a Loja poderá eximir o Maçom das
contribuições de sua competência, exceto as devidas ao Grande Oriente de Santa Catarina.
**(Acrescentado pela Lei nº 134/GOSC/2017- 2020 , de 28 de junho de 2019)**

§ 2º O tempo de licença não será contado para efeito de irregularidade; entretanto
o será, para fins de votar e ser votado, ascender graus ou receber títulos e condecorações.
**(Acrescentado pela Lei nº 134/GOSC/2017- 2020 , de 28 de junho de 2019)**

§ 3º A licença poderá, a pedido do Obreiro, ser interrompida, devendo a Loja
solicitar ao GOSC o retorno do Obreiro à atividade. **(Acrescentado pela Lei nº
134/GOSC/2017- 2020 , de 28 de junho de 2019)**

§ 4º Vencido o prazo, sem pedido de prorrogação pelo Obreiro, ou após o
término do prazo de prorrogação, a Loja deverá solicitar ao GOSC o retorno do Obreiro
às atividades. **(Acrescentado pela Lei nº 134/GOSC/2017- 2020 , de 28 de junho de
2019 )**

§ 5º A licença alcança o Obreiro na Loja da qual é membro efetivo e na Loja da
qual é membro filiado, se for o caso, e será formalizada pelo GOSC mediante mera
solicitação feita pela Loja. **(Acrescentado pela Lei nº 134/GOSC/2017- 2020 , de 28 de
junho de 2019)**

```
Art. 93 O Maçom terá a garantia de que:
```
```
I – que a individualização das sanções serão disciplinadas por Lei e somente
retroagirá para beneficiá-lo.
II – que a Lei maçônica não prejudicará o direito adquirido, a coisa julgada e o
ato jurídico perfeito e acabado.
III – que os casos omissos, no que tange aos direitos individuais maçônicos,
serão resolvidos solidária, harmônica e fraternalmente dentro do GRANDE ORIENTE
DE SANTA CATARINA.
IV – da liberdade de visitação das lojas e triângulos da jurisdição.
V – de obter licença, por tempo determinado, para tratar assuntos de natureza
particular.
```
```
Subseção II
Dos Deveres Do Maçom
```

**Regulamento Geral**

```
Art. 94 São deveres do Maçom:
```
I – cumprir e fazer cumprir leis e resoluções emanadas das autoridades
competentes.
II – freqüentar assiduamente os trabalhos das lojas e órgãos a que pertencer,
aceitando e desempenhando, com probidade e zelo, as funções e encargos maçônicos que
lhe forem confiados
III – efetuar, com pontualidade, o pagamento das contribuições pecuniárias que,
ordinária ou extraordinariamente, lhe forem legalmente atribuídas.
IV – reconhecer como irmãos todos os maçons regulares e dar-lhes ajuda e
proteção que puder oferecer, quando legais e justas; **(Alterado pela Lei nº
118/GOSC/2014-2017, de 24 de setembro de 2016)**
V – prestar às viúvas, irmãs solteiras, ascendentes e descendentes necessitados, de
seus irmãos, todo o auxílio que puder oferecer.
VI – nada imprimir, nem publicar na imprensa, sobre assuntos que envolvam o
nome do GRANDE ORIENTE DE SANTA CATARINA, sem a expressa autorização
do Grão-Mestre.
VII – não falar, a estranhos ou a maçons irregulares, assuntos maçônicos de
natureza privada, bem como os que forem tratados na Loja, não os revelando a quem
quer que seja, mesmo a irmãos que deles não tenham tomando conhecimento
regularmente, a não ser com pleno consentimento e expressa autorização de sua
respectiva Loja.
VIII – manter conduta digna e honesta, praticando o bem, a tolerância e a
solidariedade humana, subordinando-se às leis, aos costumes e aos poderes constituídos
do País.
IX – comunicar ao Venerável de sua Loja deslizes graves de conduta moral
praticados por maçons em qualquer âmbito maçônico ou não.
X – se investido no mandato de representação não-maçônica, deve preservar os
princípios e fundamentos da Instituição, ressaltando a posição da Maçonaria ante os
problemas sociais, econômicos e políticos, para a conquista do bem-estar do homem e
o aprimoramento da sociedade.
XI – Contribuir com a manutenção da Fundação Hermon conforme disposto na
Lei n° 116/GOSC/2014-2017 de 18 de junho de 2016, sendo o valor estipulado corrigido
anualmente pelo INPC ou outro índice que o venha substituir. **(Alterado pela Lei nº
128/GOSC/2017- 2020 , de 30 de novembro de 2018)**

```
§ 1º A contribuição prevista no inciso XI deste artigo passará a ser facultativa a
partir de 1º de janeiro de 2021, cabendo a opção às Lojas, de conformidade com seu
Regimento Interno. (Acrescentado pela Lei nº 131/GOSC/2017- 2020 , de 28 de junho
de 2019)
```
```
§ 2º As Lojas que optarem por deixar de fazer a contribuição deverão comunicar
sua decisão ao GOSC até o dia 31 de agosto de cada ano, a partir de 2020, e passarão a
deixar de contribuir a partir do dia 1º de janeiro do ano seguinte. (Acrescentado pela
Lei nº 131/GOSC/2017- 2020 , de 28 de junho de 2019)
```
```
§ 3º São dispensados da frequência regular e mínima estabelecida na legislação
maçônica, os Mestres Maçons que estiverem efetivamente no exercício das funções, em
```

```
Regulamento Geral
instituições públicas ou privadas, ocupantes de cargos, de relevância social notória.
(Acrescentado pela Lei nº 132/GOSC/2017- 2020 , de 28 de junho de 2019)
```
```
§ 4º A dispensa de frequência prevista no parágrafo anterior será solicitada pela
Loja, perdurará durante o efetivo exercício do cargo ou função e não assegurará o direito
de votar e ser votado sem o preenchimento dos requisitos exigidos para tanto.
(Acrescentado pela Lei nº 132/GOSC/2017- 2020 , de 28 de junho de 2019)
```
```
Subseção III
Da Regularidade e Irregularidade Do Maçom
```
```
Art. 95 O maçom é considerado:
```
I – Regular:
a) O maçom ativo, membro do quadro de uma loja ou triângulo jurisdicionado a
uma potência regular e que ali exerça os seus direitos e cumpra suas obrigações;
b) O maçom licenciado, membro do quadro de uma Loja ou triângulo
jurisdicionado ao Grande Oriente de Santa Catarina;
c) O maçom inativo, portador de quite-placet no prazo de validade.
II – Irregular:
a) O maçom inativo, portador de quite-placet fora do prazo de validade;
b) O maçom que tiver frequência inferior a 1/3 nos últimos 12 meses ou for
inadimplente e tiver sua irregularidade declarada pela loja da qual é membro efetivo;
c) O maçom expulso;
d) O maçom que se filiar ou frequentar lojas independentes ou jurisdicionadas a
potências maçônicas irregulares ou não reconhecidas;
e) O maçom contra o qual haja sido expedido placet ex-officio;
f) O maçom que tenha seus direitos maçônicos suspensos, enquanto durar o
período da suspensão;
g) O maçom que, sendo membro regular de loja jurisdicionada ao Grande Oriente
de Santa Catarina, prestar obediência a outra potência maçônica.
Parágrafo único. É vedado ao maçom irregular frequentar qualquer atividade
maçônica reservada a maçons regulares realizada por loja ou corpo maçônico regular e,
por não ter nenhum direito maçônico, são nulos quaisquer atos maçônicos por ele
praticados.
**(Alterado pela Lei nº 165, de 27 de outubro de 2025)**
h) **(Revogado pela Lei nº 165, de 27 de outubro de 2025)**

```
Subseção IV
O Maçom e Sua Designação
```
```
Art. 96 Os Maçons podem ser: eméritos, beneméritos, honorários, remidos ou
fundadores.
I – são EMÉRITOS:
a) Os que completarem 25 (vinte e cinco) anos de atividade maçônica, sendo
pelo menos dez anos vinculado a loja jurisdicionada ao GRANDE ORIENTE DE
```

```
Regulamento Geral
SANTA CATARINA, descontados eventuais períodos de inatividade por licença, quite-
placet, irregularidade ou placet ex-officio. (Alterado pela Lei nº 145/GOSC/2020- 2023 ,
de 27 de março de 2021)
```
b) Os que completarem 20 (vinte) anos de atividade maçônica, sendo pelo menos
dez anos vinculado a loja jurisdicionada ao GRANDE ORIENTE DE SANTA
CATARINA, descontados eventuais períodos de inatividade por licença, quite-placet,
irregularidade ou placet _ex-officio_ , desde que tenham, no mínimo, 60 (sessenta) anos de
idade. **(Alterado pela Lei nº 145/GOSC/2020- 2023 , de 27 de março de 2021)**

```
c) os Ex-Grão-Mestre e Ex-Grão-Mestre Adjuntos do GRANDE ORIENTE DE
SANTA CATARINA; (renumerado pela Lei nº 1 45 /GOSC/ 2020 - 2023 , de 27 de
março de 2021)
```
```
§ 1º Os EMÉRITOS, a critério de suas respectivas lojas ou triângulos poderão ser
dispensados da frequência aos trabalhos maçônicos e ficar isentos das contribuições da
loja, sujeitos, todavia, as devidas ao GOSC. (Alterado pela Lei nº 118/GOSC/2014-
2017, de 24 de setembro de 2016)
```
```
§ 2º Terão direito a votar desde que recolham as contribuições devidas e tenham
frequência mínima de 1/3 (um terço) nas Sessões realizadas pela loja à qual pertencem
no período de 1º de maio do ano anterior às eleições a 30 de abril, inclusive, do ano em
que ocorrerá o pleito eleitoral e no período de 1º de janeiro do ano anterior às eleições a
31 de janeiro do ano do pleito eleitoral, quando das eleições para Grão-Mestre e Grão-
Mestre Adjunto. (Alterado pela Lei nº 133/GOSC/2017- 2020 , de 28 de junho de
2019 )
```
```
§ 3º Terão direito a ser votados desde que recolham as contribuições devidas e
tenham frequência mínima de 2/3 (dois terços) nas Sessões realizadas pela loja à qual
pertencem no período de 1º de maio do ano anterior às eleições a 30 de abril, inclusive,
do ano em que ocorrerá o pleito eleitoral e no período de 1º de janeiro do ano anterior às
eleições a 31 de janeiro do ano do pleito eleitoral, quando das eleições para Grão-Mestre
e Grão-Mestre Adjunto. (Acrescentado pela Lei nº 133/GOSC/2017- 2020 , de 28 de
junho de 2019)
```
```
II – são BENEMÉRITOS, os que, mesmo pertencendo a outras jurisdições ou
obediências, tenham prestado excepcionais serviços à Loja ou Triângulo e por ela
tenham sido agraciados.
```
§ 3o Os BENEMÉRITOS, pertencentes ao quadro da loja, não estão isentos das
contribuições devidas, bem como à frequência regulamentar, podendo votar e ser votado;
**(Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)**

III – são HONORÁRIOS, os maçons não pertencentes ao Quadro de uma Loja
ou Triângulo, e que dela receberam esse título.

```
IV – são REMIDOS, os maçons que forem declarados por sua loja ou triângulo,
ficando dispensados de todas as contribuições e frequência para com a loja, excetuando-
se as contribuições devidas ao GOSC; (Alterado pela Lei nº 118/GOSC/2014-2017, de
24 de setembro de 2016)
```

**Regulamento Geral**

```
V – são FUNDADORES, os maçons do Quadro que tenham assinado a Ata de
Fundação da Loja, observado o que dispõe este Regulamento Geral, e FUNDADORES
HONORÁRIOS, aqueles que reconhecidamente, tenham participado das
atividades preparatórias de fundação da Loja ou Triângulo.
```
```
§ 4º (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
§ 5º (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
§ (^) 6º O título honorário só poderá ser concedido a Maçom de outra Loja ou de
outra Potência regular reconhecida.
§ 7º **(Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
Seção VIII
Do Quite-Placet e Placet Ex-Offício
Art. 97** O maçom que desejar desligar-se do quadro da loja da qual for membro
efetivo, solicitará a expedição de quite-placet. **(Alterado pela Lei nº 155/GOSC/2020-
2023 , de 27 de junho de 2022; Vigência a partir de 24/12/2022)**
§ 1º O quite-placet é concedido pela loja, emitido, expedido e registrado pelo
Grande Oriente de Santa Catarina, exceto nos casos de intervenção do Grão-Mestrado
em lojas e triângulos, casos em que será concedido, emitido, expedido e registrado pelo
Grande Oriente de Santa Catarina. **(Alterado pela Lei nº 165, de 27 de outubro de
2025)**
§ 2º Para que seja expedido o quite-placet, o obreiro não poderá estar inadimplente
para com a loja ou para com o Grande Oriente de Santa Catarina e não poderá ter
formalmente instaurado contra si, processo no âmbito da justiça maçônica; **(alterado
pela Lei nº 155/GOSC/2020- 2023 , de 27 de junho de 2022; Vigência a partir de
24/12/2022)**
§ 3º Atendidas as condições do parágrafo anterior, a loja não poderá deixar de
conceder o quite-placet. **(Alterado pela Lei nº 165, de 27 de outubro de 2025)**
§ 4º O quite-placet tem validade de seis meses, a contar da data de sua emissão,
expedição e registro no Grande Oriente de Santa Catarina. **(Alterado pela Lei nº 165,
de 27 de outubro de 2025)**
§ 5º Decorrido o prazo previsto no parágrafo anterior, o quite-placet perderá sua
validade e o seu portador passará à condição de maçom irregular, ficando impedido de
frequentar qualquer atividade maçônica reservada a maçons regulares realizada por loja
ou corpo maçônico regular. **(Alterado pela Lei nº 165, de 27 de outubro de 2025)**
§ 6º **(Revogado pela Lei nº 165, de 27 de outubro de 2025)
Art. 98** O Placet ex-ofício é um documento de caráter restritivo, solicitado pela
Loja e entregue ao obreiro cujo comportamento seja considerado, pela maioria dos
membros, incompatível com a paz, a harmonia e a concórdia, ao obreiro que seja
inadimplente ou infrequente. **(Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de
setembro de 2016)**


**Regulamento Geral**

```
I – (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
II – a partir da data em que tomar conhecimento da denúncia, a Loja terá o prazo
de trinta dias para se pronunciar a respeito.
```
```
III – ocorrendo razões de ordem moral que geraram a expedição do placet ex-
offício, obriga-se a Loja a formalizar denúncia do Obreiro faltoso no prazo de trinta
dias.
```
```
IV – da decisão da Loja caberá recurso ao Grão-Mestrado; (alterado pela Lei nº
118/GOSC/2014-2017, de 24 de setembro de 2016)
V – a denúncia da loja encaminhada ao GOSC deverá estar acompanhada das
devidas provas. O obreiro denunciado ficará impedido de frequentar as sessões, até
decisão de seu caso. (Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro
de 2016)
```
```
VI – (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
§ 1º O Obreiro afastado poderá requerer seu retorno somente à Loja emitente do
placet ex-officio.
```
```
§ 2º O retorno será aceito quando, em votação secreta e por maioria absoluta dos
presentes, a Loja considerar sanado ou findo o motivo determinante da expedição do
documento referido no caput.
```
```
Art. 99 (Revogado pela Lei nº 81/ 2008 , art. 2°, de 29 de março de 2008)
```
```
Seção IX
```
```
Da Suspensão e Perda Dos Direitos Maçônicos
```
```
Art. 100 Suspendem-se os direitos maçônicos:
```
```
I – do Obreiro que deixar de recolher as contribuições pecuniárias que lhe
forem legalmente atribuídas, desde que previamente notificado.
```
```
II – em virtude de decisão, transitada em julgado, que condene o Obreiro à pena
de suspensão de direitos.
```
```
III – preventivamente, a partir do oferecimento da denúncia ao GOSC,
acompanhada das devidas provas, pelo venerável mestre ou do orador, nos casos de
infração às leis maçônicas. (Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de
setembro de 2016)
```
IV – por Ato estabelecido em Lei, de conformidade com o disposto neste
Regulamento Geral e no Código de Procedimentos.


**Regulamento Geral
Art. 101** O maçom incurso na pena de suspensão, de acordo com o artigo
anterior, poderá readquirir seus direitos, mediante processo de regularização, estabelecido
na lei.

```
Art. 102 (Revogado pela Lei nº 165, 27 de outubro de 2025)
```
```
Art. 103 O processo de suspensão ou eliminação de obreiro é da competência da
loja a cujo quadro pertença o infrator, cabendo recurso ao Grão-Mestre, ou ainda, ao
COLEGIADO. (Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de
2016)
```
```
Art. 104 Em qualquer dos casos, de suspensão ou eliminação, facultar-se-á ao
acusado o mais amplo direito de defesa na forma prevista em Lei.
```
```
Art. 105 As lojas e triângulos fixarão em seus regimentos internos, as condições
de freqüência e pagamento de seus obreiros.
```
```
Seção X
Do Direito De Intervisitação
```
```
Art. 106 Todo Maçom regular tem o direito de visitar as lojas e triângulos da
jurisdição, apresentando a Cédula de Identidade Maçônica, como comprovação de sua
condição e qualidade de Maçom e a Palavra Semestral, quando integrante de
Obediência da COMAB. (Alterado pela Lei nº 81/2008, art. 1°, de 29 de março de
2008 )
```
```
Parágrafo Único (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de
setembro de 2016)
```
```
Art. 107 Todo Maçom visitante está sujeito à disciplina interna da Loja que o
admitir aos seus trabalhos.
```
```
Art. 108 Os visitantes, para terem ingresso a uma Loja em funcionamento,
devem ter a sua regularidade verificada.
```
§ 1º Será dispensada a formalidade de reconhecimento e apresentação do título,
aos maçons que já tenham visitado a loja, e forem notoriamente conhecidos.

```
§ 2º O Maçom que visitar outra Loja, terá justificada a falta em sua Loja, desde
que a visita seja realizada na mesma semana da falta, computando-se a visita como
presença em sua loja, a critério do Venerável Mestre.
```
```
I – A inserção da justificativa, com o cômputo da presença, deverá se dar até 15
(quinze) dias após a falta;
```
```
II – O obreiro somente poderá ter até duas faltas justificadas, com cômputo de
presença, por semestre. (Alterado pela Lei nº 140/GOSC/2020- 2023 , de 30 de
novembro de 2020)
```

**Regulamento Geral**

```
Art. 109 (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de
2016)
```
```
Art. 110 O Irmão visitante quando desconhecido dos demais Irmãos terá que
apresentar ao Irmão Guarda do Templo suas credenciais maçônicas, sendo em seguida
telhado de acordo com o Rito da Loja.
```
```
Parágrafo Único Caso o Irmão visitante seja apresentado por um Obreiro regular
da Loja, bastará apenas apresentar suas credenciais, ficando dispensado do
telhamento.
```
```
Capítulo VI
Das Ações Singulares
```
```
Seção I
Das Eleições
```
```
Art. 111 As eleições no GOSC serão disciplinadas pelo Código Eleitoral e
tratando-se das Comissões Internas do Colegiado no seu Regimento Interno. (Alterado
pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
I – (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
II – (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
III - (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
Parágrafo Único (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de
setembro de 2016)
```
```
Art. 112 (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de
2016)
```
```
Seção II
Das Incompatibilidades
```
```
Art. 113 São incompatíveis:
```
```
I – os cargos de Tesoureiro e Hospitaleiro com os da Comissão de Finanças.
```
II – os cargos de Luzes com qualquer outro cargo ou participação em Comissão
de Finanças. **(Alterado pela Lei nº 128/GOSC/2017- 2020 , de 30 de novembro de
2018 )**

```
III – o cargo de Orador com qualquer Comissão Permanente.
```
```
Parágrafo Único É vedado o exercício simultâneo de dois cargos eletivos em
```

**Regulamento Geral**
administração de Lojas.

```
Seção III
Do Livro Negro e Amarelo
```
**Art. 114** O Grão-Mestrado e a Loja manterão o Livro Negro e o Livro
Amarelo para registro dos candidatos rejeitados.

```
Seção IV
Da Instalação De Venerável Mestre
```
```
Art. 115 O Mestre Maçom, eleito e diplomado, após participar do cerimonial de
instalação, denominar-se-á MESTRE INSTALADO.
```
```
§ 1º Para ser consagrado Mestre Instalado é necessário que o candidato seja^
```
eleito Venerável de Loja, em processo eleitoral estabelecido pelo Código de

Procedimentos.

```
§ 2o O venerável mestre, eleito pela loja, será diplomado, instalado e empossado
oportunamente, em cerimônias especiais e de acordo com a ritualística. (Alterado pela
Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
§ 3º A cerimônia de instalação será realizada sob a presidência do Grão-
Mestre ou de um Conselho de mestres instalados devidamente designados.

```
Seção V
Da Sagração Do Templo
```
```
Art. 116 O templo maçônico é o local onde os maçons se reúnem para trabalhar
ritualisticamente, as sessões de iniciação, elevação e exaltação só ocorrerão em templo
sagrado. (Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
Parágrafo Único A sagração do Templo obedecerá ao ritual adotado pelo
GRANDE ORIENTE DE SANTA CATARINA.

```
Seção VI
Palavra semestral
```
```
Art. 117 Nos meses de junho e dezembro, o Grão-Mestre enviará a Palavra
Semestral, expedida pela Confederação Maçônica do Brasil – COMAB aos Grandes
Orientes filiados, para ser transmitida a todas as Lojas e Triângulos filiados, só podendo
```

```
Regulamento Geral
recebê-la o obreiro regular. (Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de
setembro de 2016)
```
```
§ 1º A Palavra Semestral será fornecida somente aos membros da loja, não
podendo fazer parte da cadeia de união os irmãos visitantes de outras obediências.
(Acrescentado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
§ 2º Quando for o caso de maçom da jurisdição, regular e fora de seu oriente,
poderá este solicitar a Palavra Semestral a mais alta autoridade maçônica do oriente onde
estiver e deva permanecer, o qual lhe fará a transmissão auricular. (Acrescentado pela
Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
Art. 118 A PALAVRA SEMESTRAL será transmitida aos obreiros do Quadro,
pelo Venerável Mestre, em Cadeia de União, respeitadas as especificações dos Ritos.
Caso o Irmão esteja ausente da Sessão deverá o Venerável transmiti-la isoladamente.
```
**Art. 119** O ingresso de maçons em lojas da jurisdição se dará através da
PALAVRA SEMESTRAL.

```
Seção VII
Datas Comemorativas
```
**Art. 120** São eventos maçônicos em toda a jurisdição e serão comemorados nas
seguintes datas: **(alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de
2016)**

- 12 (doze) de abril – aniversário de fundação do GRANDE ORIENTE DE
SANTA CATARINA;
- 24 (vinte e quatro) de junho – Dia de São João – Padroeiro da Maçonaria.
- 25 (vinte e cinco) de julho - Dia Estadual da Cultura e da Paz
**(Acrescentado pela lei nº 81/2008, art. 1°, de 29 de março de 2008)**
- 04 (quatro) de agosto – Dia de Fundação da Confederação Maçônica do
Brasil COMAB – sucessora do Colégio de Grão-Mestres da Maçonaria Brasileira.
- 20 (vinte) de agosto - Dia do Maçom. **(Acrescentado pela Lei nº 81/2008,
art. 1°, de 29 de março de 2008)**
- 07 (sete) de setembro – Dia da Independência do Brasil.
- 15 (quinze) de novembro – Proclamação da República.

```
§ 1º Se houver impedimento na data específica, a solenidade poderá ser
transferida para data próxima.
```
```
§ 2º Duas ou mais lojas poderão reunir-se para a celebração de data
```

```
Regulamento Geral
comemorativa.
```
```
Seção VIII
Das Condecorações
```
```
Art. 121 Os títulos e condecorações honoríficas a serem conferidos pelas lojas
e GRANDE ORIENTE DE SANTA CATARINA à maçons ou não-maçons, por
relevantes serviços prestados, dependem de comprovado exame na apreciação do
mérito.
```
```
§ 1º No âmbito das lojas, estas poderão decidir a concessão a maçons,
dependendo da aprovação do GRANDE ORIENTE DE SANTA CATARINA quando
se tratar de não-maçons.
```
```
§ 2º - (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
Art. 122 A Ordem do Mérito Maçônico constitui uma distinção de ordem
honorífica concedida pelo GRANDE ORIENTE DE SANTA CATARINA, com a
finalidade principal de laurear e homenagear pessoas físicas (maçons e não maçons) e
jurídicas, órgãos e entidades, de qualquer nacionalidade, dignas de reconhecimento da
Maçonaria ou que se destacaram por serviços à Ordem Maçônica ou na defesa dos
valores, princípios e ideais comuns à Maçonaria Universal. (Acrescentado pela Lei nº
89/2009, art. 1°, de 09 de fevereiro de 2009)
```
```
Art. 123 A Ordem do Mérito Maçônico outorgará as seguintes distinções de
ordem honorífica:
```
```
I - Grã-Cruz destinada a homenagear pessoas físicas (não maçônicas) e
jurídicas, órgãos e entidades, de qualquer nacionalidade e maçons de outras obediências
da Maçonaria Universal;
```
II – Grande Oficial destinada a homenagear maçons filiados ao GRANDE
ORIENTE DE SANTA CATARINA;

```
III – Comendador destinado a homenagear maçons filiados ao GRANDE
ORIENTE DE SANTA CATARINA que tenham completado 50 anos como maçom
regular.
```
```
IV – Cavaleiro, destinada a homenagear maçons filiados ao GRANDE
ORIENTE DE SANTA CATARINA que tenham completado 25 anos como maçom
regular.
```
```
Parágrafo Único A cada honraria será concedido um diploma ao agraciado
assinado pelo Sereníssimo Grão-Mestre. (Acrescentado pela Lei nº 89/2009, art.
1°, de 09 de fevereiro de 2009)
```
```
Art. 124 A Ordem do Mérito Maçônico instituirá as seguintes medalhas em
```

```
Regulamento Geral
ordem decrescente de importância aos obreiros do GOSC, mediante requerimento das
Lojas:
```
```
I – Brasões:
```
```
a) GRANDE ORIENTE DE SANTA CATARINA, destinado ao Irmão que
completar 4 0 (quarenta) anos de vida maçônica.
```
II – Comemorativas de 60, 70, 80, 90 e 100 anos e história do GRANDE
ORIENTE DE SANTA CATARINA, destinado aos maçons que tenham no mínimo 25
(vinte e cinco) anos de vida maçônica e que contribuíram efetivamente para:

a) Consolidação da fundação do Grande Oriente;
b) Consolidação do Grande Oriente integrado, independente e autônomo no
processo histórico de 1973;
c) Consolidação do Grande Oriente de Santa Catarina em seu processo de
crescimento institucional, pós 1973;
d) Consolidação do processo de integração com as obediências co-irmãs: GOB –
Grande Oriente do Brasil e MRGL - Muito Respeitável Grande Loja;
e) Consolidação das reformas pós Constituinte de 1999. **(Acrescentado pela Lei
nº 92 , de 05 de dezembro de 2009)**

```
Art. 125 A concessão da honraria é de competência exclusiva do Colegiado, que
as aprovará, em votação, por maioria dos seus membros, após análise e parecer da sua
comissão de administração. Somente o Grão-Mestrado e os veneráveis (mediante
aprovação em loja) poderão apresentar indicações de candidatos ao recebimento das
honrarias. (Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
Parágrafo Único As proposições deverão vir acompanhadas do curriculum vitae
do candidato e/ou de justificativa escrita com a apresentação das razões para a
concessão da honraria. (Acrescentado pela Lei nº 89/2 0 09, art. 1°, de 09 de fevereiro
de 2009)
```
```
Art. 126 A honraria poderá ser suspensa ou cancelada pelo Colegiado por
comportamento ou prática de atos contrários aos princípios, valores ou ideais da
Maçonaria Universal.
```
```
Parágrafo Único A suspensão ou o cancelamento da honraria se nortearão pelo
mesmo procedimento adotado para a sua concessão. (Acrescentado pela Lei nº
89/2009, art. 1°, de 09 de fevereiro de 2009)
```
```
Art. 127 A Ordem do Mérito Maçônico será preferencialmente concedida e
entregue por ocasião das comemorações do aniversário do Grande Oriente de
Santa Catarina. (Acrescentado pela Lei nº 89/2009, art. 1 °, de 09 de fevereiro de
2009 )
Art. 128 As características das insígnias, medalhas e diplomas serão definidas
em ato do Grão-Mestrado. (Acrescentado pela Lei nº 89/ 2 009, art. 1°, de 09 de
fevereiro de 2009)
```
```
Art. 129 No caso de falecimento do agraciado ou de condecoração post mortem
```

```
Regulamento Geral
as insígnias e diplomas serão entregues aos seus sucessores. (Acrescentado pela Lei nº
89/2009, art. 1°, de 09 de fevereiro de 2009)
```
```
Art. 130 As cerimônias de entrega das honrarias poderão realizar-se em sessão
pública em Templos Maçônicos ou em outros locais, fechados ou públicos, estes
últimos, obrigatoriamente, revestidos da dignidade condizente.
```
```
Parágrafo Único A entrega fora do território nacional dependerá de deliberação
do Colegiado, desde que não contrarie a legislação maçônica nem a brasileira. (Alterado
pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)
```
```
Art. 131 As dúvidas e/ou omissões quanto à matéria serão solucionadas
pelo Colegiado, através da Comissão de Constituição e Legislação. (Acrescentado pela
Lei nº 89/2009, art. 1°, de 09 de fevereiro de 2009)
```
```
Seção IX
Do Luto Maçônico
```
```
Art. 132 Pelo passamento ao Oriente Eterno das autoridades e titulares, abaixo
relacionados, o Luto Maçônico a ser observado é o seguinte:
```
```
I – Grão-Mestre: luto por vinte e um dias e suspensão dos trabalhos por sete dias
nas lojas da jurisdição.
II - Presidente da Confederação Maçônica do Brasil “COMAB”: luto por vinte
e um dias e suspensão dos trabalhos por três dias na jurisdição.
III – Grão-Mestre Adjunto: luto por onze dias nas lojas da jurisdição e suspensão
dos trabalhos por cinco dias.
IV – Soberano Grande Comendador, chefes de rito ou nome assemelhado de
presidentes de potências filosóficas em Santa Catarina: luto por nove dias com
suspensão dos trabalhos nas lojas da jurisdição por três dias.
V – Grão-Mestre e Grão-Mestre Adjunto, de Honra e Honorários: luto por sete
dias e suspensão dos trabalhos por três dias nas lojas da jurisdição.
VI – Venerável de Loja: luto por cinco dias, e na Loja que presidia, suspensão
dos trabalhos na sessão seguinte.
VII – Obreiro da Loja: Luto por três dias, e suspensão da Sessão, se ocorrer, no
dia do falecimento.
VIII – Maçons portadores de condecoração oficial e Garantes de Amizades do
GRANDE ORIENTE DE SANTA CATARINA: luto por três dias.
```
```
Parágrafo Único No período de luto não poderá ser realizada nenhuma
solenidade festiva.
```
```
Seção X
```
```
Protocolo De recepção e Tratamento Às Autoridades
```
**Art. 133** As autoridades maçônicas ou portadores de títulos honoríficos serão
recebidos com formalidades conforme determinar o Código de Procedimentos.


```
Regulamento Geral
Seção X-A
(Acrescentado pela Lei nº 149/GOSC/2020-2023, de 26 de junho de 2021)
```
```
Entidades Paramaçônicas e Entidades de Interesse Maçônico
(Acrescentado pela Lei nº 149/GOSC/2020-2023, de 26 de junho de 2021)
```
**Art. 133-A** São entidades paramaçônicas aquelas instituições de caráter iniciático e
ritualístico, cujas finalidades sejam compatíveis com os princípios da maçonaria,
devidamente reconhecidas pelo Grande Oriente de Santa Catarina na forma da Lei.
**(Acrescentado pela Lei nº 149/GOSC/2020-2023, de 26 de junho de 2021)**

**Art. 133-B** São entidades de interesse maçônico aquelas instituições de caráter não-
iniciático e não-ritualístico cujas finalidades sejam compatíveis com os princípios da
maçonaria, devidamente reconhecidas pelo Grande Oriente de Santa Catarina na forma
da Lei. **(Acrescentado pela Lei nº 149/GOSC/2020-2023, de 26 de junho de 2021)**

**Art. 133-C** O processo de reconhecimento e de celebração de tratados de amizade e
cooperação com as instituições identificadas nos artigos anteriores será regulado pelo
Código de Procedimentos. **(Acrescentado pela Lei nº 149/GOSC/2020-2023, de 26 de
junho de 2021)**

```
Capítulo VII
Das Disposições Gerais e Transitórias
```
```
Art. 134 A Loja jurisdicionada que, em razão do Ritual, não nominar o
Venerável Mestre como a Autoridade maior da Loja, considerará toda a referência feita
por este Regulamento Geral ao respectivo cargo ao seu equivalente.
```
```
Parágrafo Único Aplica-se a equivalência mencionada neste artigo a outros
cargos e funções existentes, conforme disciplina de cada Loja jurisdicionada.
```
```
Art. 135 (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de
2016)
```
```
Art. 136 (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de
2016)
```
```
Art. 137 (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de
2016)
```
```
Art. 138 (Revogado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de
2016)
```
```
Art. 138 - A A lei ordinária definirá os crimes maçônicos de responsabilidade e
estabelecerá o seu processo. (Acrescentado pela Lei nº 118/GOSC/2014-2017, de 24
```

**Regulamento Geral
de setembro de 2016)**

**Art. 139** Nenhuma loja poderá demandar judicialmente, no mundo não maçônico,
contra um irmão, e este contra sua loja, ou qualquer órgão da estrutura organizacional
do GOSC, ou um irmão contra outro irmão, contra a loja ou o GOSC, sem antes esgotar
a via da conciliação junto à Ordem, sob pena de expulsão da Instituição pelo Grão-
Mestre. **(Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)**

**Art. 140** A Constituição ou a Legislação Brasileira serão subsidiárias para a
aplicação nos casos omissos neste regulamento e na demais legislação do GOSC.
**(Alterado pela Lei nº 118/GOSC/2014-2017, de 24 de setembro de 2016)**

```
Art. 141 Este Regulamento Geral entrará em vigor, na data de sua publicação.
```
Dado e traçado no Oriente de Joinville, Santa Catarina, aos 29 dias do mês de
junho do ano de 2003 da E V.


