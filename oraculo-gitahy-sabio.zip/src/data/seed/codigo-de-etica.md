CÓDIGO DE ÉTICA - GOSC

## Lei nº 99 de 04 de dezembro de 2010

Rua dos Ilhéus, 38 – Ed. APLUB – 1º andar – gosc@gosc.org.br CEP 88.010- 560 – Fone/Fax: (048) 3952- 3300 -
Florianópolis – Santa Catarina - BRASIL

# CÓDIGO DE ÉTICA

### Atualizado até a Lei nº 167, de 27 de outubro de 2025


## CÓDIGO DE ÉTICA

## Lei nº 99 de 04 de dezembro de 2010

```
Rua dos Ilhéus, 38 – Ed. APLUB – 1º andar – gosc@gosc.org.br CEP 88.010- 560 – Fone/Fax: (048) 3952- 3300 -
Florianópolis – Santa Catarina - BRASIL
```
```
Título I
Disposições Preliminares
Art. 1º O presente Código tem por finalidade regular as penas disciplinares a que estão sujeitos os
maçons, lojas e triângulos filiados e jurisdicionados ao Grande Oriente de Santa Catarina.
```
```
Título II
Das Responsabilidades
```
**Art. 2º** O maçom, na vida maçônica e profana, bem como as lojas e triângulos, devem agir pautando-se
pelos princípios éticos e morais defendidos pela maçonaria, bem como observar os deveres e proibições
que lhes são impostos pela legislação do Grande Oriente e Santa Catarina.

**Art. 3º** Estão sujeitos a penalidades pela infração ao presente Código, os maçons regulares e ativos,
membros de lojas e triângulos jurisdicionados à potência, bem como as próprias lojas e triângulos
jurisdicionados.

Parágrafo Único Caso seja apresentada denúncia ou representação contra obreiro portador de quite-placet,
o fato será registrado em seu cadastro e, sobrevindo pedido de sua efetivação ou regularização, será
instaurado processo e o obreiro notificado para responder aos seus termos.
**(Alterado pela Lei nº 167, de 27 de outubro de 2025)**

**Art. 4º** A infração somente será imputável a quem lhe der causa, considerando-se causa, para tal fim, a
ação ou omissão sem a qual ela não se verificaria.

Parágrafo Único A infração que resulte de deliberação de loja ou triângulo caracterizará infração coletiva
e acarretará a responsabilidade de todos os seus obreiros, exceto os que comprovadamente tiverem votado
contra o ato ou não tenham estado presentes à sessão deliberativa.

```
Título III
Da Classificação dos Delitos
```
**Art. 5º** As infrações maçônicas podem ser pessoais ou coletivas.

§1º Infrações pessoais são as praticadas por um ou mais maçons individualizados.

§2º Infrações coletivas são as praticadas por lojas ou triângulos em consequência de deliberação de seus
obreiros.

**Art. 6º** As infrações pessoais e coletivas dividem-se em leves, médias ou graves, segundo sua natureza,
circunstâncias em que foram cometidas e danos que provocarem.

**Art. 7º** Constitui infração ética leve a ação ou omissão que importe em violação dos princípios éticos e
morais defendidos pela maçonaria, ou à norma estatutária, regulamentar ou legal, que não atinja diretamente
profano, maçom, loja, triângulo ou o GOSC e que traga repercussões exclusivamente na esfera individual
do acusado.

**Art. 8º** Constitui infração média a ação ou omissão que importe em violação aos princípios éticos e morais
defendidos pela maçonaria, ou à norma estatutária, regulamentar ou legal, e que atinja ou repercuta
diretamente na esfera pessoal de profano, maçom, loja, triângulo, ou ao GOSC.

**Art. 9º** Constitui infração grave a ação ou omissão que importe em violação aos princípios éticos e morais
defendidos pela maçonaria, ou à norma estatutária, regulamentar ou legal, de considerável reprovação
segundo o senso comum, e que tenha sido praticada visando causar prejuízos ou danos de ordem pessoal,
moral, à imagem ou patrimonial a profano, outro maçom, loja, triângulo, GOSC ou a coletividade e
sociedade em geral.


## CÓDIGO DE ÉTICA

## Lei nº 99 de 04 de dezembro de 2010

```
Rua dos Ilhéus, 38 – Ed. APLUB – 1º andar – gosc@gosc.org.br CEP 88.010- 560 – Fone/Fax: (048) 3952- 3300 -
Florianópolis – Santa Catarina - BRASIL
```
**Art. 10** Constituem, ainda, infrações graves inclusive:

I – Prestar falso testemunho ou falsa declaração nos procedimentos de apuração de infração ao presente
Código de Ética;

II – Iniciar profano rejeitado;

III - Negligenciar nas sindicâncias concernentes à admissão de profano, prestando informações inverídicas
ou ocultando fato ou circunstância de que tenha ciência, visando possibilitar a admissão de quem não possua
condições para ingressar na Ordem;

```
Título IV
Das Penalidades
```
**Art. 11** As penalidades aplicáveis nos casos de infração leve são:

I - Advertência;

II - Suspensão dos direitos maçônicos, individuais ou da oficina, de um a seis meses.

**Art. 12** As penalidades aplicáveis nos casos de infração média são:

I - Suspensão dos direitos maçônicos, individuais ou da oficina, por prazo não inferior a seis meses e não
superior a um ano;

II - Inabilitação para o exercício de cargos maçônicos ou funções, por prazo não inferior a um ano e não
superior a dois anos.

**Art. 13** As penalidades aplicáveis nos casos de infração grave são:

I - Suspensão dos direitos maçônicos, individuais ou da oficina, por prazo não inferior a um ano e não
superior a três anos;

II - Exclusão dos quadros do GOSC a bem da maçonaria;

**Art. 14** Nas infrações leves e médias, a representação deverá ser oferecida no prazo de até seis meses
contados da data do fato, sob pena de decadência.

**Art. 15** Nas infrações graves, a representação deverá ser oferecida no prazo de até cinco anos contados da
prática do fato ou, no caso do art. 59º, do trânsito em julgado da sentença condenatória.

```
Título V
Da Competência para Julgamento
```
**Art. 16** São competentes para apreciar e julgar o processo disciplinar por infração ética definida neste
Código:

I – O Colegiado como instância recursal ou, em competência originária, quando:

a) o acusado estiver entre a apresentação da representação e o início do julgamento pela Comissão de
Conciliação e Justiça, exercendo as funções de Grão-Mestre, Grão-Mestre Adjunto ou venerável mestre
membro do Colegiado;
b) ainda que o acusado não ostente mais a condição de Grão-Mestre, Grão-Mestre Adjunto ou venerável
mestre, o fato tiver sido praticado no exercício e em razão das referidas funções;
c) tratar-se de infração coletiva.


## CÓDIGO DE ÉTICA

## Lei nº 99 de 04 de dezembro de 2010

```
Rua dos Ilhéus, 38 – Ed. APLUB – 1º andar – gosc@gosc.org.br CEP 88.010- 560 – Fone/Fax: (048) 3952- 3300 -
Florianópolis – Santa Catarina - BRASIL
```
II – A Comissão de Conciliação e Justiça do Colegiado nos demais casos.

§1º A competência originária do Colegiado será regulada, ainda, pelas seguintes regras:

a) se o acusado deixar de exercer a função de Grão-Mestre ou de Grão-Mestre Adjunto, processo será
remetido à Comissão de Conciliação e Justiça salvo se o fato tiver sido praticado no exercício e em razão
das referidas funções ou se o julgamento pelo Colegiado já tiver tido início;
b) apenas os demais acusados que tenham praticado a conduta em co-autoria com o Grão-Mestre, Grão-
Mestre Adjunto ou venerável mestre membro do Colegiado terão seus julgamentos atraídos para o
Colegiado pelo foro especial.

§2º Em competência originária, o procedimento observará o disposto nos processos de competência da
Comissão de Conciliação e Justiça, ressaltando-se que a fase conciliatória será realizada por esta Comissão
e as fases instrutória e decisória pelo Colegiado.

§3º Das decisões proferidas em processos de competência originária do Colegiado caberá recurso de
reconsideração ao próprio órgão no prazo de dez dias, observado, no que couber, o disposto no capítulo X
do presente Código.

```
Título VI
Da Comissão de Conciliação e Justiça
```
**Art. 17** A Comissão de Conciliação e Justiça será constituída na forma do regimento interno do Colegiado,
e será presidida pelo venerável mestre escolhido dentre e pelos seus integrantes.

**Art. 18** Substituirá o presidente, em suas faltas ou impedimentos, o julgador com maior tempo na
maçonaria.

**Art. 19** Os julgadores estão sujeitos às causas de impedimento e suspeição aplicáveis, segundo o Código
de Processo Civil Brasileiro, aos Juízes de Direito.

§1º Quando não auto-declarado, qualquer das partes poderá, por escrito, em até dez dias antes do
julgamento, em petição protocolada no Grande Oriente de Santa Catarina, arguir o impedimento ou
suspeição do julgador.

§2º Em três dias o julgador deverá declarar-se impedido ou suspeito ou, por escrito, recusar a suspeição,
caso em que remeterá a arguição e as suas razões ao Grão-Mestre, que decidirá.

§3º Contra a decisão do julgador que, de ofício ou por provocação das partes se declarar suspeito ou
impedido, ou da decisão do Grão-Mestre que acatar a arguição, não caberá recurso.

§4º O julgador declarado suspeito ou impedido ficará afastado do caso e será substituído pelo suplente. Se
for o relator, a outro será redistribuído o processo.

§5º Na impossibilidade de formação de quórum para julgamento em razão do impedimento ou suspeição
de julgadores, serão chamados para compor a comissão os membros do Colegiado com maior tempo na
maçonaria.

**Art. 20** A relatoria dos processos será sempre atribuída por sorteio entre todos os julgadores, excluídos os
últimos contemplados, que só voltarão a concorrer quando se completar o rodízio.

Parágrafo Único Ao fim dos mandatos os membros da Comissão devolverão os processos, os quais serão
redistribuídos aos seus novos integrantes, sem prejuízo dos atos já praticados.


## CÓDIGO DE ÉTICA

## Lei nº 99 de 04 de dezembro de 2010

```
Rua dos Ilhéus, 38 – Ed. APLUB – 1º andar – gosc@gosc.org.br CEP 88.010- 560 – Fone/Fax: (048) 3952- 3300 -
Florianópolis – Santa Catarina - BRASIL
```
```
Título VII
Das Providencias para Instauração do Processo
```
**Art. 21** Qualquer maçom, por si ou na qualidade de representante de outro maçom ou, se for o caso, de
profano, poderá oferecer representação, desde que o faça por escrito.

§1º A representação, elaborada em duas (2) vias, deverá conter:

I - Os nomes das partes, e, quando possível, suas qualificações.

II - A descrição do fato, com as suas principais circunstâncias (quem fez o que, quando, como, e onde).

III - Os motivos pelos quais o fato caracteriza infração ao Código de Ética do GOSC, e sua classificação.

§2º A representação deverá estar acompanhada dos documentos que tenham relevância para a apuração do
fato, inclusive, se for o caso, com declarações de testemunhas, maçons ou não, devidamente qualificadas.

**Art. 22** A representação será endereçada ao Grão-Mestre e protocolada na secretaria do GOSC, onde com
uma das vias será formado o expediente.

Parágrafo Único Se o acusado for o próprio Grão-Mestre, a representação deverá ser apresentada
diretamente ao órgão competente para julgá-lo em reunião do Colegiado.

**Art. 23** Recebida a documentação, o Grão-Mestre em até sete (07) dias:

§1º Rejeitará e arquivará a representação liminarmente se apresentada de forma anônima ou apócrifa;

§2º Encaminhará o expediente:

I – À loja a que pertencer o representado quando, dada a natureza da infração, a violação tiver acarretado
prejuízos exclusivamente às partes envolvidas, sem outros reflexos para a Ordem, sendo, portanto, cabível
a conciliação.

II – À Comissão de Conciliação e Justiça quando a apuração do fato for de interesse do GOSC ou, no caso
do inciso anterior, quando inexitosa a conciliação;

§3º Em relação ao inciso I do parágrafo anterior, observar-se-á o seguinte:

a) se o representado for membro de mais de uma loja, e o representante pertencer a alguma delas, para esta
deverá ser remetido o expediente. Caso contrário, a acusação poderá ser encaminhada a qualquer delas.
b) se o acusado não for membro de nenhuma loja, a conciliação será realizada diretamente pela Comissão
de Conciliação e Justiça em sessão especial marcada pelo seu presidente.

**Art. 24** A loja e a Comissão de Conciliação e Justiça manterão o GOSC informado da tramitação do
processo.

**Art. 25** Nas infrações médias e graves, se assim o reclamar o interesse da Ordem em geral ou do GOSC
em particular, poderá o Grão-Mestre, em decisão fundamentada, suspender preventivamente os direitos
maçônicos do acusado, loja, ou triângulo, pelo prazo máximo de seis meses, prorrogável por mais um
período também por decisão fundamentada.

§1º Nos casos de competência originária do Colegiado, a decisão será tomada por maioria absoluta dos seus
membros por provocação de qualquer um destes.


## CÓDIGO DE ÉTICA

## Lei nº 99 de 04 de dezembro de 2010

```
Rua dos Ilhéus, 38 – Ed. APLUB – 1º andar – gosc@gosc.org.br CEP 88.010- 560 – Fone/Fax: (048) 3952- 3300 -
Florianópolis – Santa Catarina - BRASIL
```
§2º O tempo de suspensão efetivo será abatido de eventual pena imposta quando for o caso.

```
Título VIII
Do Procedimento Conciliatório em Loja
```
**Art. 26** Recebido o expediente, o venerável mestre, para data não superior a vinte e um dias, designará
sessão do Conselho de Família para tentativa de conciliação das partes.

Parágrafo Único Todos os atos processuais atribuídos ao venerável mestre serão assumidos pelo seu
substituto legal caso ele seja parte interessada no feito.

**Art. 27** Para a reunião do Conselho de Família as partes serão notificadas por prancha ou pessoalmente,
recebendo o acusado, cópia da representação.

§1º Se for o caso, também será convidado para participarem da reunião os membros do Conselho de Família
da loja à qual pertence o representante.

§2º Também poderão participar do Conselho de Família os procuradores das partes.

§3º Caso não sejam as partes notificadas, o Conselho de Família será convocado para nova sessão em prazo
não superior a dez dias, sendo que, se novamente não for possível sua realização, dar-se-á por superada a
fase conciliatória.

**Art. 28** Em até dez dias após a realização do Conselho de Família, ou na hipótese de restar superada a fase
conciliatória pelo não comparecimento das partes, o venerável mestre devolverá ao Grão-Mestre o
expediente, no qual deverão estar juntadas:

I – Cópia da ata da reunião do Conselho de Família, lavrada e assinada pelos presentes no ato da reunião e
na qual deverá constar o registro dos fatos relevantes ocorridos na sessão.

II – Comprovante da entrega da cópia da representação ao réu, se realizada;

III – Considerações que entenda pertinentes sobre o fato.

**Art. 29** Recebida a documentação, o Grão-Mestre em até dez dias:

I – Arquivará o procedimento se:

a) obtida a conciliação;
b) se o representante requerer a desistência.

II – Remeterá o procedimento à Comissão de Conciliação e Justiça se não for o caso de arquivamento
definido no inciso anterior.

```
Título IX
Do Procedimento na Comissão de Conciliação e Justiça
```
**Art. 30** Conclusos os autos ao relator, este, em até dez dias, notificará o acusado para que apresente defesa
por escrito no prazo de dez dias, contados da data do recebimento da notificação.

§1º Se o acusado ainda não tiver recebido cópia da representação, esta deverá acompanhar a notificação.

§2º A defesa deverá ser apresentada por escrito e, se for o caso, estar acompanhada dos documentos e
declarações de testemunhas que deseje apresentar.


## CÓDIGO DE ÉTICA

## Lei nº 99 de 04 de dezembro de 2010

```
Rua dos Ilhéus, 38 – Ed. APLUB – 1º andar – gosc@gosc.org.br CEP 88.010- 560 – Fone/Fax: (048) 3952- 3300 -
Florianópolis – Santa Catarina - BRASIL
```
**Art. 31** Recebida a defesa ou decorrido o prazo para sua apresentação, o relator mandará distribuir cópia
integral do procedimento aos demais julgadores, os quais, no prazo de dez dias, poderão:

I – Solicitar que o representante, o representado ou terceiro sejam convocados para prestar depoimento.

II – Requisitar a apresentação de documentos às partes, lojas ou triângulos ou ao GOSC.

§1º Apresentado o documento, será dada vista dos autos ao julgador que requereu a providência, para que
dê a diligência como cumprida ou requeira sua complementação.

§2º A responsabilidade pela apresentação do documento ou comparecimento da testemunha será como
regra, da parte que o arrolou.

**Art. 32** Encerradas as providências do art.31º o relator solicitará ao presidente a convocação de sessão de
instrução e julgamento, a qual será designada no prazo máximo de trinta dias.

§1º As partes serão notificadas com antecedência de pelo menos sete dias para comparecerem à sessão.

§2º Os profanos e os maçons, cuja oitiva for determinada, serão comunicadas para comparecer ao ato pela
parte que as arrolou, importando em desistência da prova o não comparecimento.

**Art. 33** No dia e hora designados para a sessão de instrução e julgamento, que será realizada
preferencialmente na sede do GOSC ou em qualquer outro indicado pelo presidente, este verificará o
quórum e declarará aberta a sessão, ordenando em seguida o comparecimento das partes.

§1º O quórum mínimo para a instalação da sessão será de três (3) julgadores.

§2º Sendo quatro os julgadores presentes, a presidência da sessão não poderá ser exercida pelo relator, mas
por qualquer um deles, escolhido para o ato de acordo com a regra do art.18º

§3º Não estando presente o número mínimo de julgadores, o julgamento será remarcado para um dos quinze
dias seguintes, ficando notificados os presentes.

§4º O acusado que tiver sido notificado e não comparecer será julgado à revelia, mas, se tiver constituído
defensor, este atuará no julgamento.

§5º Se o acusado, notificado, não comparecer por motivo justificado até a abertura da sessão, o julgamento
será adiado para um dos quinze dias seguintes, não sendo admitido, em nenhuma hipótese, segundo
adiamento, salvo por motivo de saúde.

§6º A ausência de testemunha não acarretará o adiamento do julgamento.

**Art. 34** Iniciada a sessão, se for o caso, será ouvido, preferencialmente nesta ordem, as testemunhas
indicadas pelos julgadores, as testemunhas trazidas pelo representante, as testemunhas trazidas pelo
representado, o representante e o acusado.

§1º As partes poderão ouvir na sessão até três testemunhas cada, podendo este número ser excedido por
decisão majoritária dos julgadores.

§2º A inquirição de profanos deverá ser autorizada pela unanimidade dos julgadores.

**Art. 35** As inquirições serão conduzidas pelo relator, sendo permitida a formulação de perguntas pelos
demais julgadores, pela acusação, e pela defesa.


## CÓDIGO DE ÉTICA

## Lei nº 99 de 04 de dezembro de 2010

```
Rua dos Ilhéus, 38 – Ed. APLUB – 1º andar – gosc@gosc.org.br CEP 88.010- 560 – Fone/Fax: (048) 3952- 3300 -
Florianópolis – Santa Catarina - BRASIL
```
**Art. 36** Os depoimentos das testemunhas não serão reduzidos a termo, mas os nomes dos depoentes deverão
constar da ata de instrução, indicando-se, resumidamente, o que declararam.

**Art. 37** Encerrada a instrução com a tomada dos depoimentos será dada a oportunidade para o acusado
formular alegações finais orais pelo prazo improrrogável de quinze minutos.

§1º Havendo mais de um acusado, o prazo será de trinta minutos distribuídos por acordo ou
proporcionalmente entre eles.

§2º Encerrada a alegação final as partes se retirarão da sala, permanecendo apenas os julgadores para debate
e julgamento.

§3º Concluídos os debates o relator apresentará o seu voto, colhendo-se em seguida os votos dos demais
conselheiros, prevalecendo a decisão majoritária.

§4º Em sendo confirmada a infração pela decisão, passar-se-á à votação da sanção a ser imposta, iniciando-
se pelo relator.

§5º Prevalecerá à decisão majoritária ou, caso optem os três julgadores por sanções diferentes, a
intermediária entre aquelas escolhidas. Finalmente, caso necessário, os julgadores decidirão a duração da
sanção imposta, iniciando-se pelo relator e prevalecendo o termo médio.

§6º Não haverá necessidade de votos por escrito.

§7º A ata de julgamento conterá apenas o resultado detalhado das votações, podendo os julgadores,
querendo, manter registro escrito dos respectivos motivos que os levaram a votar de determinada forma.

§8º Os julgadores utilizarão como critérios de decisão, os princípios da proporcionalidade e razoabilidade
para decidir e aplicar as sanções de acordo com a gravidade da infração, circunstâncias em que foi cometida
e possibilidade de exigir-se conduta diversa do acusado no fato.

§9º A decisão será publicada no Boletim Oficial e na página do GOSC na internet, e informada por prancha
às partes envolvidas.

**Art. 38** Sendo quatro os julgadores presentes, o que presidir a sessão só votará em caso de empate.

**Art. 39** Uma vez iniciada a instrução ou a votação, o julgamento só será interrompido e transferido por
deliberação unânime dos julgadores presentes.

```
Título X
Dos Recursos
```
**Art. 40** A decisão da Comissão de Conciliação e Justiça será passível de recurso ao Colegiado.

§1º O recurso deverá ser interposto pelo acusado ou pelo representante, por escrito e já com as respectivas
razões, e protocolado na secretaria do GOSC no prazo de dez dias contados da intimação da decisão.

§2º Não haverá contra razões ao recurso interposto, salvo quando interposto pelo representante, hipótese
na qual o acusado será notificado por prancha com prazo igual ao do recurso.

§3º O recurso terá efeito suspensivo, ressalvado o disposto no art. 25º.

§4º Não será admitida a apresentação de documentos novos ou inquirição de testemunhas na fase recursal.


## CÓDIGO DE ÉTICA

## Lei nº 99 de 04 de dezembro de 2010

```
Rua dos Ilhéus, 38 – Ed. APLUB – 1º andar – gosc@gosc.org.br CEP 88.010- 560 – Fone/Fax: (048) 3952- 3300 -
Florianópolis – Santa Catarina - BRASIL
```
**Art. 41** No Colegiado, o recurso será distribuído por sorteio a um de seus membros, excluídos os integrantes
da Comissão de Conciliação e Justiça, que o submeterá à apreciação na primeira sessão que se seguir à
distribuição, desde que esta tenha ocorrido com antecedência mínima de sete dias antes da sessão.

**Art. 42** A apreciação do recurso será realizada na seguinte ordem:

I - O relator fará, oralmente, breve relato dos fatos e, se for o caso, abordará eventual intempestividade do
recurso.

II – Será oportunizado ao recorrente fazer uso da palavra por quinze minutos.

III – Os demais membros do Colegiado poderão solicitar esclarecimentos ao relator ou aos membros da
Comissão de Conciliação e Justiça.

IV – Em seguida será feita a votação, iniciando-se pelo relator e seguindo-se dos demais segundo a ordem
de antiguidade da loja representada, observando-se, se for o caso, o disposto nos parágrafos 3º e seguintes
do art. 37º.

Parágrafo Único O Grão-Mestre proferirá voto apenas no caso de empate.

**Art. 43** A decisão proferida em primeira instância poderá ser modificada por maioria dos presentes no
Colegiado.

**Art. 44** Os membros da Comissão de Conciliação e Justiça não votarão na competência recursal.

```
Título XI
Dos Prazos
```
**Art. 45** Em relação aos prazos, salvo disposição em contrário, observar-se-á o seguinte:

a) os prazos são contínuos, não se interrompendo ou suspendendo nos feriados;
b) no cômputo, exclui-se o dia do começo e inclui-se o do vencimento;
c) considera-se prorrogado o prazo até o primeiro dia útil se o vencimento cair em sábado, domingo, ou
feriado;
d) os prazos somente começam a correr do primeiro dia útil após a intimação ou notificação;
e) os prazos ficarão suspensos durante o recesso maçônico oficial do GOSC, recomeçando a contagem no
primeiro dia útil seguinte ao reinício do expediente.

```
Título XII
Notificações e Intimações
```
**Art. 46** Todas as notificações e intimações deverão ser realizadas por e-mail e por carta com aviso de
recebimento conjuntamente.

§1º Serão consideradas válidas as notificações e intimações enviadas ao endereço constante do cadastro
mantido junto ao Grande Oriente de Santa Catarina, podendo ser invalidadas somente quando o interessado
demonstrar, inequivocamente, alteração de seu endereço de correspondência e o de e-mail.

§2º A utilização de outras formas de intimação não será considerada irregular se exitosa.

**Art. 47** O acusado que der causa que impossibilite ou dificulte sua notificação terá os seus direitos
maçônicos suspensos pelo Grão-Mestre até que a mesma possa ser efetivada, suspendendo-se o curso do
processo.


## CÓDIGO DE ÉTICA

## Lei nº 99 de 04 de dezembro de 2010

```
Rua dos Ilhéus, 38 – Ed. APLUB – 1º andar – gosc@gosc.org.br CEP 88.010- 560 – Fone/Fax: (048) 3952- 3300 -
Florianópolis – Santa Catarina - BRASIL
```
Parágrafo Único Nos casos deste artigo a suspensão dos direitos maçônicos não será abatida de eventual
sanção imposta e perdurará até o julgamento se absolvido o representado ou se lhe for aplicada sanção
menos grave.

**Art. 48** É obrigação do maçom e das lojas manterem atualizados junto ao GOSC seus dados pessoais, entre
eles endereços, telefones e endereço de e-mail.

**Art. 49** Considerar-se-á realizada a intimação para fins da contagem de prazos:

I – Se pessoalmente, no primeiro dia em que realizada;

II – Se por correio com aviso de recebimento, no dia em que entregue a correspondência,
independentemente de quem a tenha recebido;

III – Se por meio do boletim oficial, no dia da disponibilização do boletim na página do GOSC na internet;

IV – Se por correio eletrônico (e-mail), no primeiro dia útil seguinte ao seu envio.

Parágrafo Único Na hipótese da notificação ou intimação serem enviadas por e-mail e correio com aviso
de recebimento conjuntamente, o prazo iniciar-se-á no termo fixado no inciso II deste dispositivo. Sendo
inexitosa a notificação ou intimação pelo correio, será utilizado na contagem do prazo o termo fixado no
inciso IV deste dispositivo.

```
Título XIII
Das Disposições Finais
```
**Art. 50** O direito de defesa, bem como o de representação, poderá ser exercido pessoalmente ou através de
procurador.

Parágrafo Único O procurador deverá ser, obrigatoriamente, maçom colado no grau de mestre.

**Art. 51** Sobre as provas, observar-se-á o seguinte:

§1º As partes deverão apresentar todas as provas que tiverem no momento do oferecimento da representação
e na defesa.

§2º As declarações de testemunhas deverão ser apresentadas por escrito, assinadas e com firma reconhecida,
e serão apresentadas junto com a representação ou defesa.

§3º Excepcionalmente, poderão os julgadores admitir, na sessão de julgamento, a oitiva de testemunhas
trazidas pelas partes no ato.

§4º Os documentos probatórios deverão ser juntados em seus originais ou em cópia autenticada, salvo
quando se tratar de documento emanado do GOSC ou de domínio público.

§5º A juntada de documentos novos, assim considerados como aqueles tendentes a demonstrar a falsidade
de prova apresentada pela parte contrária ou aqueles que só estiveram disponíveis em momento posterior,
poderão ser juntados até cinco dias antes da sessão de julgamento. Caso em que será desnecessária a
intimação da parte contrária, que poderá contraditá-los no início da sessão, antes de iniciada eventual
instrução por indicação do relator.

**Art. 52** Em se tratando de procedimento que apure fato que acarrete prejuízos exclusivamente às partes
envolvidas, sem outros reflexos para a maçonaria, lojas ou Grande Oriente de Santa Catarina, o denunciante
poderá desistir da representação até o início do voto do conselheiro relator na sessão de julgamento.


## CÓDIGO DE ÉTICA

## Lei nº 99 de 04 de dezembro de 2010

```
Rua dos Ilhéus, 38 – Ed. APLUB – 1º andar – gosc@gosc.org.br CEP 88.010- 560 – Fone/Fax: (048) 3952- 3300 -
Florianópolis – Santa Catarina - BRASIL
```
Parágrafo Único Nos demais casos, o procedimento prosseguirá independentemente da vontade do
denunciante.

**Art. 53** Somente membros regulares do Grande Oriente de Santa Catarina e em dia com o mesmo poderão
ter acesso a processos que apurem infração ao Código de Ética.

Parágrafo Único Durante a tramitação do procedimento, salvo autorização do Grão-Mestre, apenas as partes
terão acesso aos autos, vedada a sua retirada em carga, mas permitida a obtenção de cópia.

**Art. 54** Verificado o atraso injustificável no cumprimento, pelos veneráveis mestres ou membros da
Comissão de Conciliação e Justiça, dos prazos estabelecidos neste Código, o Grão-Mestre, de ofício ou por
provocação de qualquer interessado:

I – Adotará as providências necessárias para realização do ato.

II – Remeterá representação à Comissão de Conciliação e Justiça para apuração da infração, observando-
se o procedimento da Seção V e seguintes.

**Art. 55** Se o atraso injustificável for verificado em relação aos prazos dos artigos 23 e 29, caberá ao
presidente da Comissão de Conciliação e Justiça avocar aos autos e remetê-los ao membro do Colegiado
com maior idade maçônica ou o mais idoso no caso de empate naquele requisito, a quem caberá a prática
do ato.

**Art. 56** Concluída a sessão de instrução e julgamento, a Comissão de Conciliação e Justiça remeterá o
procedimento à Secretaria do GOSC, a qual:

I - Aguardará o prazo para o trânsito em julgado;

II – Publicará o extrato da decisão e da sanção no Boletim Oficial;

III – Tomará as demais providências legais no caso de trânsito em julgado ou de oferecimento de recurso;

IV – Comunicará as demais potências maçônicas com as quais o GOSC mantenha tratado de
reconhecimento sobre as penalidades aplicadas, salvo a de advertência.

**Art. 57** Aplicam-se, no que couber, as disposições previstas no artigo anterior aos casos de suspensão dos
direitos maçônicos previstos neste Código.

**Art. 58** Nas infrações coletivas:

I – A notificação será feita preferencialmente na pessoa do venerável mestre ou do presidente, a quem
também caberá representar a loja ou o triângulo;

II – Na eventualidade de o venerável mestre ou presidente não poderem representar a loja ou o triângulo
perante a Comissão de Conciliação e Justiça ou ao Colegiado, a representação competirá aos seus
substitutos legais;

III – Os crimes coletivos serão julgados em conjunto com os individuais a eles conexos;

**Art. 59** A condenação judicial por ato doloso de improbidade administrativa ou qualquer delito, também
doloso, definido pelas leis penais profanas, e que se mostre incompatível com os princípios da maçonaria,
acarretará a instauração de ofício de processo ético.


## CÓDIGO DE ÉTICA

## Lei nº 99 de 04 de dezembro de 2010

```
Rua dos Ilhéus, 38 – Ed. APLUB – 1º andar – gosc@gosc.org.br CEP 88.010- 560 – Fone/Fax: (048) 3952- 3300 -
Florianópolis – Santa Catarina - BRASIL
```
Parágrafo Único A sanção, entretanto, será obrigatoriamente a de expulsão se a condenação for por delito
definido como hediondo, ou equiparado a hediondo, entre eles o terrorismo, a tortura e o tráfico de drogas;
por delitos sexuais e nos crimes de corrupção passiva ou ativa.

**Art. 60** Nas hipóteses previstas no artigo anterior, em se tratando de decisão transitada em julgado, a notícia
da condenação será encaminhada ao órgão competente para julgamento, que determinará a intimação do
condenado para, no prazo de dez (10) dias, demonstrar a inexistência da condenação, sendo vedada a
discussão relativa à prática ou não do fato ou sobre o acerto ou não da condenação.

**Art. 61** Este Código entrará em vigor na data da sua publicação, aplicando-se inclusive aos fatos ocorridos
anteriormente à sua vigência, respeitados os atos processuais e procedimentais já praticados, decisões já
tomadas e os prazos previstos nos artigos 14 e 15.

**Art. 62** Ficam revogadas as leis nº. 39 e 40 de 20 de dezembro de 2004, e as demais disposições em
contrário.


