 PRINCÍPIOS GERAIS - MAÇONARIA

# LANDMARKS

# CONSTITUIÇÃO - GOSC

# OS ANTIGOS DEVERES

# 2010


4 • GOSC - Grande Oriente de Santa Catarina


```
GOSC - Grande Oriente de Santa Catarina • 5
```
### APRESENTAÇÃO

# DOS PRINCÍPIOS GERAIS DA MAÇONARIA

A Maçonaria é uma ESCOLA DO CONHECIMENTO e de
APERFEIÇOAMENTO que o homem, em seu percurso histó-
rico, produziu. É, complementar e subsidiariamente, uma
instituição essencialmente iniciática, filosófica, filantrópi-
ca, educativa e progressista, adogmática e apartidária, que
tem por finalidade oferecer instrumentos para formar ho-
mens que propugnem por uma sociedade alicerçada na
tríade da liberdade, igualdade e fraternidade.
I - Proclama a prevalência do espírito sobre a matéria;
que os homens são livres e iguais em direitos; que a
tolerância constitui o princípio cardeal nas relações
humanas, para que sejam respeitadas as convicções
e a dignidade de cada um.
II - Prega o aperfeiçoamento moral, intelectual e social
da humanidade, por meio do cumprimento inflexível
do dever, da investigação constante da verdade e da
prática desinteressada da beneficência.
III - Enaltece o mérito da inteligência e da virtude e o valor
demonstrado na prestação de serviços à Ordem, à
Pátria e à Humanidade.
IV - Repudia todas as formas de exploração da pessoa
humana, os privilégios e as regalias, combate a igno-
rância, a superstição e a tirania.
V - Afirma que o sectarismo político e o fanatismo, quer


6 • GOSC - Grande Oriente de Santa Catarina

religioso ou racial, são incompatíveis com a universa-
lidade do espírito maçônico.
VI - Defende a plena liberdade de expressão do pensa-
mento, como direito fundamental do ser humano, ad-
mitida a correlata responsabilidade.
VII -Reconhece o trabalho como um dever social; julga-o
dignificante e nobre sob qualquer forma: manual, inte-
lectual, artística e técnica.
VIII -Considera irmãos todos os maçons, quaisquer que
sejam suas raças, nacionalidades ou crenças.
IX - Sustenta que os maçons têm os seguintes deveres
essenciais: amor à família, fidelidade, devotamento à
Pátria e obediência à Lei.
X - Sustenta que os maçons estendam e liberalizem os
laços fraternais que os unem a todos os homens
esparsos pela superfície da Terra.
XI - Recomenda a divulgação de seus ideais pelo exemplo e
por todos os meios de comunicação do pensamento e
proscreve, terminantemente, o recurso à força ou à vio-
lência, na solução dos litígios de qualquer ordem, com-
batendo a ignorância em todas as suas modalidades.
XII -Adota sinais e emblemas de elevada significação sim-
bólica, os quais, utilizados nos trabalhos maçônicos,
servem, também, para os maçons se reconhecerem e
se auxiliarem, onde quer que se encontrem.

Calcado e alicerçado nos princípios maçônicos, o
GRANDE ORIENTE DE SANTA CATARINA, constitui-se em
uma POTÊNCIA SIMBÓLICA para as lojas, triângulos e


```
GOSC - Grande Oriente de Santa Catarina • 7
```
maçons que a ele se filiem, agindo de maneira própria e
independente, mantendo relações de reconhecimento e
amizade com as demais potências maçônicas regulares e
reconhecidas, respeitadas sua Constituição e leis comple-
mentares, bem como os seguintes postulados e princípios
normativos da Ordem Maçônica Universal: da crença na
existência de um Princípio Criador, a quem invoca sob a
denominação de Grande Arquiteto do Universo; do simbo-
lismo da Maçonaria Operativa; das lendas como instrumen-
to didático; do sigilo absoluto e inviolável; do juramento,
em presença do Grande Arquiteto do Universo, sobre o
Livro da Lei, obedecido o que consagra o Rito específico;
da presença nas lojas e triângulos das Três Grandes Lu-
zes da Maçonaria - Livro da Lei, Esquadro e Compasso -
durante os trabalhos ritualísticos; da consagração da vir-
tude, benevolência, educação, tolerância e da livre e cons-
ciente investigação da verdade; da proibição, em Loja, de
toda e qualquer discussão em torno de sectarismo, discri-
minação, de assuntos religiosos singulares ou de política
partidária; do culto e glorificação da verdade, da justiça e
do direito; do respeito às autoridades legalmente constitu-
ídas, às leis do país, à família e às religiões; do aprofunda-
mento continuado da doutrina, filosofia e os mistérios que
a simbologia maçônica encerram; da obrigatória aceitação
dos antigos Landmarks, tradições, usos e costumes da
Antiga Maçonaria, conforme prescrevem as leis de 1723 e
outras universalmente aceitas pela Maçonaria simbólica
regular e universal.


8 • GOSC - Grande Oriente de Santa Catarina

# LANDMARKS

```
Considerados como as mais antigas leis que regem a
Maçonaria universal, os Landmarks estabelecem precei-
tos fundamentais, eternos e imutáveis.
Albert Mackey, em sua Encyclopaedia, relaciona os
vinte e cinco Landmarks abaixo:
```
1. Os meios de reconhecimento.
2. A divisão da Maçonaria Simbólica em três graus: Apren-
    diz, Companheiro e Mestre.
3. A lenda do terceiro grau.
4. O governo da Fraternidade por um Grão-Mestre, eleito
    por todos os maçons.
5. A prerrogativa do Grão-Mestre de presidir toda reunião
    de maçons no território da respectiva jurisdição, ca-
    bendo-lhe ocupar o trono em todas as sessões de
    qualquer Loja subordinada.
6. A faculdade do Grão-Mestre de conceder licença para
    conferir graus antes do tempo regulamentar.
7. A prerrogativa do Grão-Mestre de autorizar a instala-
    ção e o funcionamento das Lojas.
8. A prerrogativa do Grão-Mestre de iniciar e exaltar
    maçons.
9. A necessidade dos maçons se congregarem em Lo-
    jas.
10. O governo de cada Loja por um Venerável e dois Vigi-
    lantes.
11. A necessidade de que toda Loja trabalhe a coberto.
12. O direito de todo mestre maçom de ser representado


```
GOSC - Grande Oriente de Santa Catarina • 9
```
```
nas assembléias gerais da Ordem e de dar instruções
aos seus representantes.
```
13. O direito de todo maçom de recorrer à assembléia ge-
    ral dos irmãos, contra as decisões de sua Loja.
14. O direito de todo maçom de visitar e ter assento em
    qualquer Loja.
15. Nenhum visitante desconhecido aos irmãos de uma
    Loja pode ser admitido sem que seja submetido a ri-
    goroso trolhamento.
16. Nenhuma Loja pode intrometer-se nos assuntos de
    outra.
17. Todo maçom está sujeito às leis e regulamentos ma-
    çônicos em vigor na respectiva jurisdição.
18. Todo candidato à iniciação deve ser homem livre e de
    maioridade.
19. Todo maçom há de crer na existência de Deus como o
    Grande Arquiteto do Universo.
20. A crença na ressurreição em uma vida futura.
21. A existência, no altar, do Livro da Lei, parte indispen-
    sável do equipamento de uma Loja.
22. Todos os homens são iguais perante Deus e, na Loja,
    se situam num mesmo nível.
23. Os conhecimentos havidos por iniciação, além dos
    métodos de trabalho, lendas e tradições, devem ser
    mantidos em absoluto segredo.
24. A Maçonaria consiste em uma ciência especulativa,
    fundada numa arte operativa, com propósito de
    ensinamento moral.
25. Os Landmarks da Maçonaria não podem ser alterados.


10 • GOSC - Grande Oriente de Santa Catarina

# ASSEMBLÉIA CONSTITUINTE

# ATO DE PROMULGAÇÃO DA CONSTITUIÇÃO

Nós, representantes do Povo Maçônico do GRANDE ORI-
ENTE DE SANTA CATARINA - GOSC, reunidos sob a proteção do
Grande Arquiteto do Universo em Assembléia Constituin-
te, tendo presente as Leis Fundamentais e Universais, os
Antigos e Aceitos Princípios da Fraternidade e os
Landmarks, promulgamos a presente Constituição.

PUBLIQUE-SE E CUMPRA-SE.

Dado e traçado no Plenário da Assembléia Constituinte
Maçônica, Oriente de Florianópolis, Capital do Estado de
Santa Catarina, aos onze dias do mês de dezembro do
ano de um mil novecentos e noventa e nove da E∴ V∴
Francisco Vady Nozar Mello
Presidente da Mesa Diretora
Joaquim José Rodrigues
1º Vigilante
Reginaldo Boppré
2º^ Vigilante
Sérgio Luiz Ribeiro
Orador
Zinaldo José Ghisi
Secretário


## CONSTITUIÇÃO DO GOSC

      - GOSC - Grande Oriente de Santa Catarina •
- TÍTULO I - da Instituição........................................
- Capítulo I - da Denominação, Sede e Objetivos.......
- Capítulo II - da Duração, Patrimônio e Rendas........
- TÍTULO II - do Poder e das Funções.......................
- Capítulo I - da Legislação Maçônica.......................
- Capítulo II - do Executivo Maçônico........................
- Capítulo III - da Justiça Maçônica...........................
- TÍTULO III - da Divisão de Competência.................
- Capítulo I - do Colegiado........................................
- Capítulo II - Administração Central.........................
- Capítulo III - das Lojas e Triângulos........................
- Capítulo IV - das Relações Exteriores.....................
   - Código de Procedimentos.................... TÍTULO IV -do Regulamento Geral e
- Capítulo I - do Regulamento Geral..........................
- Capítulo II - do Código de Procedimentos...............
- TÍTULO V - Disposições Gerais e Transitórias.........
- Capítulo I - Disposições Gerais..............................
- Capítulo II - Disposições Transitórias.....................


12 • GOSC - Grande Oriente de Santa Catarina

### PREÂMBULO

```
O Povo Maçônico do Grande Oriente de Santa
Catarina, através de seus representantes, reu-
nido em Assembléia Constituinte, tendo presen-
te as Leis Fundamentais e Universais, os Anti-
gos e Aceitos Princípios da Fraternidade e os
Landmarks, promulga a presente Constituição.
```
# DECLARAÇÃO DE PRINCÍPIOS

O Grande Oriente de Santa Catarina - GOSC - adota,
com fundamento na tradição maçônica universal, os se-
guintes princípios:

1. Jurisdição soberana sobre as lojas da Obediência,
exercendo autoridade sobre os graus simbólicos nelas exis-
tentes;
2. Ninguém será levado a iniciação, em qualquer Loja
jurisdicionada, sem possuir as qualidades de probidade,
independência e prática dos bons costumes;
3. O Maçom tem assegurado plena liberdade de cren-
ça, mas deverá abster-se de manifestar preconceitos e de
provocar polêmicas de natureza política partidária ou reli-
giosa;
4. O Grande Oriente de Santa Catarina, para a conse-
cução de seus fins, se organiza como Estado simbólico,
sem prejuízo de sua devoção à Pátria comum.


```
GOSC - Grande Oriente de Santa Catarina • 13
```
### TÍTULO I

### DA INSTITUIÇÃO

Capítulo I
DA DENOMINAÇÃO, SEDE E OBJETIVOS
Art. 1º O Grande Oriente de Santa Catarina – GOSC –
pessoa jurídica de direito privado, é uma instituição civil
sem fins lucrativos, com sede em Florianópolis, Capital do
Estado e com jurisdição em todo o Estado de Santa
Catarina, República Federativa do Brasil, fundada em doze
de abril de mil novecentos e cinquenta, integrante da Con-
federação Maçônica do Brasil - COMAB -, constituindo-se
como unidade,
soberana, autônoma e independente, regida por esta
Constituição, pela legislação dela decorrente, e pelos prin-
cípios e fundamentos da Maçonaria Universal.
Art. 2º O Grande Oriente de Santa Catarina tem por
objetivos o progresso e o desenvolvimento da Maçonaria,
a busca da verdade, a prática da união, da fraternidade e
da tolerância, bem como o aperfeiçoamento moral e inte-
lectual da Humanidade.

Capítulo II
DA DURAÇÃO, PATRIMÔNIO E RENDAS
Art. 3º 0 tempo de duração do Grande Oriente de San-
ta Catarina é indeterminado e ilimitado o número de Lojas
Simbólicas, bem como dos membros que o constituem.
Art. 4º 0 patrimônio e os fundos para sua manutenção


14 • GOSC - Grande Oriente de Santa Catarina

e desenvolvimento são formados por:

1. Bens móveis e imóveis que possui e venha a possuir;
2. Taxas, emolumentos, produto da comercialização
de materiais, publicações, serviços diversos, captações e
rendas decorrentes;
3. Participações societárias em empresas e as ren-
das delas decorrentes;
4. Doações e donativos.

TÍTULO II
DO PODER E DAS FUNÇÕES
Art. 5º Todo o poder emana do Povo Maçônico. As fun-
ções do Estado Maçônico são exercidas por normas
estabelecidas nesta Constituição, no Regulamento Geral,
no Código de Procedimentos, na Legislação Ordinária e nos
Regimentos Internos das Lojas, pelos seguintes órgãos:

1. Colegiado;
2. Grão-Mestrado;
3. Delegacias Regionais;
4. Lojas e Triângulos.

Capítulo I
DA LEGISLAÇÃO MAÇÔNICA
Art. 6º A Legislação Maçônica Constitucional e Ordiná-
ria é da competência exclusiva do Colegiado.
§1º O Colegiado é o guardião da Constituição, a qual
só poderá ser alterada por maioria de, no mínimo, dois
terços de seus membros;
§2º A legislação ordinária será aprovada, modificada


```
GOSC - Grande Oriente de Santa Catarina • 15
```
ou revogada pela maioria simples dos membros do
Colegiado;
§3º O Regulamento Geral e o Código de Procedimen-
tos disciplinarão o processo legislativo.

Capítulo II
DO EXECUTIVO MAÇÔNICO
Art. 7º O Grão-Mestrado, composto pelo Grão-Mestre e
Grão-Mestre Adjunto, é o órgão Executivo do Grande Oriente
de Santa Catarina, com poderes regulamentares, adminis-
trativos e operacionais, sendo responsável pela execução e
operacionalização das decisões emanadas do Colegiado.
Parágrafo único. O Grão-Mestre constitui a mais ele-
vada dignidade maçônica na jurisdição do Grande Oriente
de Santa Catarina e ocupa o primeiro posto dentro do pro-
tocolo maçônico em qualquer solenidade na Obediência.

Capítulo III
DA JUSTIÇA MAÇÔNICA
Art. 8º A Justiça Maçônica será exercida pelas Lojas e
pelo Colegiado, na forma da Lei.

```
TÍTULO III
DA DIVISÃO DE COMPETÊNCIA
```
Capítulo I
DO COLEGIADO
Art. 9º O Colegiado é o Órgão Deliberativo do GRANDE
ORIENTE DE SANTA CATARINA com poderes constitucio-


16 • GOSC - Grande Oriente de Santa Catarina

```
nais, legislativos, judiciários, eleitorais e reunir-se-á:
```
1. Ordinariamente, quatro vezes ao ano, em março,
junho, setembro e dezembro, para:
a) receber a mensagem do Grão-Mestre e votar a Presta-
ção de Contas do ano anterior;
b) discutir e votar alterações na Constituição e na Legis-
lação Ordinária, quando necessário;
c) discutir e julgar os recursos de Lojas, Triângulos e
Obreiros;
d) discutir, instruir e julgar os processos que envolvem
Autoridades Maçônicas;
e) discutir e votar a Proposta Orçamentária para o ano
seguinte;
f) apreciar e votar os tratados e convênios com outras
Potências e Corporações;
g) dar posse ao Grão-Mestre e Grão-Mestre Adjunto.
2. Extraordinariamente, quando convocado pelo Grão-
Mestre ou a requerimento de um terço, no mínimo, do
Colegiado.
Art. 10. O Colegiado tem a seguinte composição:
1. Grão-Mestre e Grão-Mestre Adjunto;
2. Veneráveis Mestres das Lojas filiadas ou seus subs-
titutos legais, definidos no Regulamento Geral;
§1º O Colegiado funcionará com a maioria simples em
primeira convocação, ou trinta minutos após, com qual-
quer número;
§2º O Colegiado pode realizar reuniões fora de sua
sede, conforme calendário previamente aprovado;


```
GOSC - Grande Oriente de Santa Catarina • 17
```
§3º O Colegiado é presidido pelo Grão-Mestre;
Art. 11. O Colegiado é constituído de quatro Comis-
sões Permanentes: Administração; Finanças; Constituição
e Legislação; Conciliação e Justiça.
Parágrafo único. Poderão ser criadas outras Comissões.
Art. 12. O Regulamento Geral e o Código de Procedi-
mentos disciplinarão o funcionamento do Colegiado.

Capítulo II
ADMINISTRAÇÃO CENTRAL
Art. 13. O Grande Oriente de Santa Catarina é admi-
nistrado pelos seus membros e dirigido pelo Grão-Mestre,
a quem cabe a representação ativa e passiva, judicial e
extrajudicial.
Parágrafo único. Substitui o Grão-Mestre em sua au-
sência, impedimentos ou vacância o Grão-Mestre Adjunto,
na forma do Regulamento Geral.
Art. 14. A Administração Central compor-se-á dos se-
guintes membros:

1. Grão-Mestre e Grão-Mestre Adjunto;
2. Secretários, Secretários Adjuntos, Assessores e Di-
rigentes de órgãos instituídos por legislação ordinária.
§1º À exceção do cargo de Grão-Mestre e do Grão-
Mestre Adjunto, os demais serão providos por nomeação
do primeiro, até trinta dias de sua posse;
§2º O mandato de Grão-Mestre e Grão-Mestre Adjunto
é de três anos, iniciando e findando dentro da segunda
quinzena de junho, vedada a imediata reeleição para o
mesmo cargo;


18 • GOSC - Grande Oriente de Santa Catarina

```
§3º O ano fiscal e financeiro de cada administração
encerrar-se-á a trinta e um de dezembro.
§4º O Regulamento Geral e o Código de Procedimen-
tos disporão sobre a estrutura da Administração Central e
das atribuições de seus membros.
```
```
Capítulo III
DAS LOJAS E TRIÂNGULOS
Art. 15. Os maçons, reconhecidos por meio de inicia-
ção, filiação ou regularização, filiados ao GRANDE ORIEN-
TE DE SANTA CATARINA, organizam-se em Lojas Simbóli-
cas e Triângulos;
§1º O número mínimo para a fundação de uma Loja
ou Triângulo é de sete a três Mestres Maçons regulares,
respectivamente;
§2º As normas regulamentares e de procedimentos
aplicáveis às Unidades Simbólicas serão definidas pelo
Regulamento Geral, pelo Código de Procedimentos, pelos
Regimentos Internos e pelos Rituais.
```
```
Capítulo IV
DAS RELAÇÕES EXTERIORES
Art. 16. O Grande Oriente de Santa Catarina mantém
com as demais Potências e Obediências Maçônicas regu-
lares e universais, relações de reconhecimento e amiza-
de, inspiradas na fraternidade e no direito internacional
maçônico e consuetudinário, nomeando e aceitando Ga-
rante de Amizade ou Representante.
```

```
GOSC - Grande Oriente de Santa Catarina • 19
```
### TÍTULO IV

```
Do Regulamento Geral e Código de Procedimentos
```
Capítulo I
DO REGULAMENTO GERAL
Art. 17. O Regulamento Geral do Grande Oriente de
Santa Catarina definirá, entre outros assuntos, as compe-
tências e atribuições dos órgãos e de seus titulares; as
formas de encaminhamento, discussão e votação das
matérias administrativas, operacionais, legislativas, judi-
ciais e eleitorais; os fluxos de decisão; os procedimentos
de sindicâncias e inquéritos; a vacância, a substituição,
direitos e deveres dos maçons.

Capítulo II
DO CÓDIGO DE PROCEDIMENTOS
Art. 18. O Código de Procedimentos definirá o fluxo e
a organização das reuniões do Colegiado, da Administra-
ção Central e Regional, das Lojas e Triângulos e disporá
sobre questões processuais e de direito material em geral
e os atos operacionais previstos pela Constituição e pelo
Regulamento Geral.

```
TÍTULO V
Disposições Gerais e Transitórias
```
```
Capítulo I
Disposições Gerais
Art. 19. Fica o Estado de Santa Catarina dividido em
```

20 • GOSC - Grande Oriente de Santa Catarina

```
Regiões Maçônicas, cada uma delas com um Delegado
Regional, auxiliado por um Delegado Regional Adjunto, no-
meados pelo Grão-Mestre.
§1º O Regulamento Geral e o Código de Procedimen-
tos disporão sobre o período de gestão, a forma de provi-
mento, a divisão regional e demais atribuições desses.
§2º Todos os membros da administração do GRANDE
ORIENTE DE SANTA CATARINA deverão ser Mestres
Maçons, ativos e regulares.
Art. 20. Serão remunerados exclusivamente os car-
gos previstos no Quadro de Empregados necessários para
administração central e de seus entes, vedada a
contratação de cônjuges ou parentes de Maçons que ocu-
pem cargos, eleitos ou nomeados, até terceiro grau.
Art. 21. O GRANDE ORIENTE DE SANTA CATARINA so-
mente poderá ser dissolvido ou extinto, quando não hou-
ver, sob sua jurisdição, no mínimo, três Lojas regulares.
Art. 22. Os casos não previstos nesta Constituição,
Regulamento Geral, Código de Procedimentos, e na Legis-
lação Ordinária, serão resolvidos com fundamento nos prin-
cípios e fundamentos da Maçonaria Universal.
Art. 23. No término de seu mandato, na segunda quin-
zena do mês de junho, o Grão-Mestre encaminhará ao
Colegiado o relatório de sua gestão e a prestação de con-
tas do último semestre.
```
```
(Pela lei deve ser revogado as disposições transitórias)
```

```
GOSC - Grande Oriente de Santa Catarina • 21
```
Capítulo II
DISPOSIÇÕES TRANSITÓRIAS
Art. 24. O período eletivo do atual Grão-Mestre e Grão-
Mestre Adjunto findará na última quinzena do mês de ju-
nho do ano dois mil e dois.
Art. 25. O atual Regulamento Geral do Grande Oriente
de Santa Catarina e a legislação decorrente permanece-
rão em vigor, naquilo que não contrariarem esta
Constituição, até a aprovação do Regulamento Geral
e do Código de Procedimentos, pelo Colegiado.
Art. 26. Esta Constituição entra em vigor imediatamente
após sua promulgação pelos representantes do Povo Ma-
çônico, reunidos em Assembléia Constituinte.


22 • GOSC - Grande Oriente de Santa Catarina

# OS ANTIGOS DEVERES

THE OLD CHARGES - OS ANTIGOS DEVERES - fazem
parte integrante da CONSTITUIÇÃO DO GRANDE ORIENTE DE
SANTA CATARINA e como tal, não pode deixar de inteirar um
dos documentos subsidiários à Carta Magna da Potência,
motivo pelos quais são justapostos ao presente Código de
Procedimento. Quando o constituinte de 1999 incorporou
OS ANTIGOS DEVERES, naturalmente não quis transformá-
los nos atuais procedimentos, mas intercolocá-los como
guias, princípios e fundamentos que devem ser consulta-
dos e seguidos de forma analógica, comparativa e
orientativa.
Desnecessário, mas considerações tornam-se perti-
nentes e necessárias:

1. Por Loja entendia-se, na fase operativa, o lugar onde
os pedreiros (free-masons) exerciam sua atividade
laborativa - projetos e ensino aos companheiros;
2. Por Deputado entendia-se, no mesmo período, o
cargo de substituto ou a função imediatamente inferior,
desde que obedecida a mesma qualificação funcional, como
por exemplo, adjunto:
Mas para a compreensão integral desse momento e
dessa conjuntura, faz-se prudente um pouco de história,
mesmo que sintética.
Uma data, mais simbólica do que real, pois em histó-
ria não há cortes métricos, separa a Maçonaria Operativa
da Especulativa. Até a data de 24 de junho de 1717, a


```
GOSC - Grande Oriente de Santa Catarina • 23
```
Maçonaria era designada como Operativa e a partir de en-
tão passou a ser chamada de Maçonaria Aristocrática, cujo
limite se estende ao ano de 1789, quando, desenvolven-
do um período de aproximadamente 80 anos, passou a
chamar-se Maçonaria Democrática - a democracia, como
instituto político passou a ser discutido em profusão -, e
no segundo quartel do Século XIX fixa-se com a denomina-
ção de Maçonaria Especulativa.
Na fase operativa, as lojas, ou sejam, as organiza-
ções de pedreiros (freema-sons) mantinham, escritos so-
bre pergaminhos, algumas leis, conhecidas como OLD
CHARGES - ANTIGOS DEVERES -, que eram, o que chama-
mos atualmente, de regulamentos gerais e procedimen-
tos, pois faziam referências às lojas, aos deveres, segre-
dos e usos daquela fraternidade. Entre os deveres, os mais
antigos são: o Poema Regius e o Manuscrito Cooke, os
dois, documentos de alta importância e dignidade. O Poe-
ma Regius é composto de 294 versos duplos, onde é en-
contrada a lendária história da Maçonaria e de uma orde-
nação concernente às assembléias, hoje conhecidas como
sessões, do Ars Quartuor Coronatorum, uma série de len-
das sobre a Torre de Babel, Nabucodonosor, Euclides e
seu ensinamento, e complementarmente, de regras
comportamentais na Igreja como nas sessões. Estes do-
cumentos eram usados em reuniões maçônicas como com-
pêndio da história tradicional e das leis da fraternidade.
0 Manuscrito Cooke é composto em prosa e contém
citações de célebres autores, narra as origens da
fraternidade, tendo como locais o Egito e a Judéia. Nele


24 • GOSC - Grande Oriente de Santa Catarina

```
são encontradas citações sobre as reuniões, procedimen-
tos e instruções para novas admissões; referenciavam à
jurisdição e uma declaração de que a Assembléia foi fun-
dada, a fim de que humilde e elevado, sejam bem servidos
nesta arte, por toda a Inglaterra.
George Payne, primeiro Grão-Mestre da Grande Loja,
sonhava com uma Maçonaria moderna e procurou dotar o
novo organismo de leis que pudessem orientar suas ações.
Com estes documentos, em 1720, compilou um Re-
gulamento Geral, dando à Ordem a estrutura de um gover-
no próprio, ou seja, de um Governo Maçônico, regulamen-
to este entregue ao Reverendo James Anderson para estu-
dar as comparações e propor uma Constituição, na qual,
deveria incluir um capítulo destinado às Ordenações em
Geral, atualmente chamadas de iniciação, elevação,
exaltação e instalação. Este documento, conhecido como
Constituições de Anderson, representa a carta fundamen-
tal e a única base legal autêntica da Maçonaria.
Na primeira parte das Constituições de Anderson, fo-
ram publicados os The Old Charges contendo seis artigos
e seis parágrafos. (tradução literal com vernáculo adaptado)
```
```
I - Concernente a Deus e à Religião
Um Maçom é obrigado, por sua dependência à Ordem,
a obedecer à Lei moral e se entender corretamente o ofi-
cio, jamais será um estúpido ateu nem um libertino
irreligioso. Como a Maçonaria é universal, congregando
homens de todas as sociedades, jamais poderá estar cir-
cunscrita ao Deus Cristão. Ela aceita islâmicos, budistas,
```

```
GOSC - Grande Oriente de Santa Catarina • 25
```
bramanistas, enfim, todos aqueles que concebem, de sua
singular maneira, a tese de que o homem não é só um
amontoado atômico. Por essa razão, os Maçons chamam
o princípio criador de Grande Arquiteto do Universo, infere-
se por religião a formação de homens bons e sinceros,
justos e perfeitos e verdadeiros Irmãos. A Ordem deve ser
o centro de união e o meio conciliador para a liberdade,
igualdade e fraternidade.

II - Concernente à autoridade superior e inferior
Um Maçom é sobretudo um cidadão. Respeitada as
leis, o poder civil e glorifica o trabalho digno e honesto. O
Maçom não deve se imiscuir em conspirações ou conluios
que firam a paz, a liberdade, a felicidade da nação e as-
suntos referentes à religião, seitas e igrejas singulares.
Deve procurar evitar as guerras, revoluções, os conflitos
em geral e resolver as contradições e os antagonismos
por meios pacíficos e inteligentes. O Maçom é um forte e
deve ser o poder de intervenção em tudo o que conspira
contra a cidadania e a liberdade.

III - Concernente às Lojas
Uma Loja é um lugar onde os maçons se reúnem e
trabalham. Cada Maçom deve pertencer a uma Loja e se
submeter ao seu Regulamento ou Regimento particular,
mas também, e principalmente, à Constituição e aos regu-
lamentos gerais da Ordem. Nenhum Maçom pode abster-
se de comparecer à Loja, nos dias de trabalho e nas reuni-
ões magnas e festivas. As pessoas admitidas a fazer par-


26 • GOSC - Grande Oriente de Santa Catarina

```
te de uma Loja, devem ser homens bons e sinceros, nasci-
dos livres, de idade madura e ponderados. O Maçom não
aceita a escravidão e a submissão.
```
```
IV - Concernente aos Mestres, Vigilantes, Companhei-
ros e Aprendizes
Toda promoção de maçons deve ser baseada sobre o
valor e o merecimento pessoal. Um Maçom deve ser pro-
movido, isto é, elevado e exaltado, não por antiguidade,
mas sim por merecimento, fruto de sua produção e de seu
trabalho. Nenhum Mestre ou Vigilante deverá ser eleito
em virtude de sua antiguidade, mas unicamente por seus
méritos. Cada Irmão deve estar presente em seu lugar e
aprender segundo os métodos particulares do Rito regular
adotado pela Loja. O Grão-Mestre é o governador supremo
em suas respectivas funções e deve ser obedecido por
todos os Irmãos, de acordo com os Antigos Deveres, com
humildade, respeito, afeto e prontidão.
```
```
V - Concernente à conduta dos Maçons no trabalho
Cada Maçom trabalhará, honestamente, nos dias úteis,
a fim de poder viver honradamente nos dias festivos. O
tempo prescrito em cada Potência ou confirmado pelo uso
será respeitado para que o Aprendiz seja elevado a Com-
panheiro e este exaltado a Mestre. O Maçom deve evitar o
discurso inconveniente e de interpelar por nomes e meios
indelicados. O Venerável-Mestre, consciente de sua habili-
dade, deve encarregar-se e conduzir seus obreiros ao tra-
balho nas condições mais razoáveis e usar os materiais
```

```
GOSC - Grande Oriente de Santa Catarina • 27
```
como se fossem seus próprios bens. Nenhum Maçom deve
sentir ciúmes da prosperidade de outro Irmão, nem procu-
rar suplantá-lo por vaidades pessoais, como não terminar
um trabalho começado por outro, mas sim auxiliá-lo.

VI - Concernente à Conduta
1 o - Na Loja, quando estiver constituída:
Não deve o Maçom formar grupos particulares nem
manter conversas paralelas sem a permissão do Venerá-
vel-Mestre. O Maçom não pode falar de coisas inconveni-
entes ou dizer palavras impertinentes; interromper qual-
quer Irmão que estiver falando nem se comportar, grace-
jando de maneira ridícula quando a Loja estiver empenha-
da em assunto sério e solene; usar, sob qualquer pretex-
to, de linguagem indecorosa. Como Maçom, deve teste-
munhar ao Venerável-Mestre, vigilantes e irmãos, o respei-
to que lhes é devido e manifestá-lo. Não é recomendável
e nem aceito que assuntos maçônicos sejam levados aos
tribunais de justiça comum, ou sejam, os não-maçônicos.
A postura do Maçom dentro do Templo é: de terno preto
ou escuro, gravata e sapatos pretos ou escuros. Nas ses-
sões econômicas, poderá ser tolerado o uso do balandrau.
Não podem as pernas ficar cruzadas uma em cima da ou-
tra ou estendidas. As mãos devem ser colocadas sobre as
coxas ou cruzadas, mas nunca sustentando a cabeça. En-
fim, postura digna de Maçom.
2 o - Depois que a Loja estiver fechada, mas enquanto
os irmãos não tenham ainda se retirado:
Podeis divertir-vos com inocente alegria e mutuamen-


28 • GOSC - Grande Oriente de Santa Catarina

```
te convidar-vos a beber e comer de acordo com os vossos
meios. Todo Maçom deve evitar os excessos e de nenhum
modo obrigar o outro a beber ou comer além de sua vonta-
de, nem o impedir de retirar-se quando desejar. Deve abs-
ter-vos de dizer ou fazer algo que possa ferir ou impedir
uma conversa pacífica e livre, visto pois isto quebra o bom
entendimento e destrói o nosso objetivo. As animosidades
pessoais e as querelas privadas não podem transpor a
porta da Loja e, com mais forte razão ainda, as discus-
sões religiosas ou político-partidárias.
3 o - Quando os irmãos se encontram, sem que um
profano esteja presente, mas fora da Loja:
Deveis cumprimentar-vos cortesmente, como vos en-
sinaram, chamando-vos, mutuamente, de Irmão; comuni-
cando, com sinceridade, as informações que vos parece-
rem úteis, contanto que não estejais sendo observados e
não possam ser entendidos, sem sobrepor-vos a alguém,
nem faltar ao respeito ao outro Irmão. Embora todos se-
jam irmãos sobre o mesmo nível, a Maçonaria não retira
do homem não maçom as honras que goza, antes ao con-
trário, procura aumentar estas honrarias, principalmente,
desde que este não conflite com os princípios da Ordem.
4 o - Em presença de profanos:
Sereis circunspetos em vossas palavras e atitudes,
de modo que o estranho mais observador não possa des-
cobrir ou adivinhar o que não seja oportuno saber; e por
vezes tereis de desviar o rumo da conversa e dirigi-la, com
prudência, em elogio da nossa respeitável fraternidade.
```

```
GOSC - Grande Oriente de Santa Catarina • 29
```
5 o - Em vossa casa e na vizinhança:
Deveis conduzir-vos como convém a um homem escla-
recido e de moral ilibada e, principalmente, não conversar
com vossa família, amigos e vizinhos de assuntos da Loja,
mas, sabiamente, não perder de vista vossa honra e a da
nossa Confraria. O Maçom não descuida de seu compro-
misso com a família, não permanecendo ausente desta,
física e materialmente, de modo que o lar não se sinta
ferido e nem negligenciado.
6 o - Para comum Irmão estrangeiro:
Deveis interrogá-lo com circunspeção e do modo que
vos será ditado pela prudência, para que não vos deixeis
iludir por um ignorante, falso pretendente, que tereis de
repelir com desprezo e escárnio. Todo Maçom deve tomar
cuidado para não proporcionar qualquer informação a quem
não pertença à Ordem. Mas se tiver a certeza de que se
trata de um Irmão verdadeiro e regular, deve tratá-lo com
urbanidade e, se estiver necessitado, proporcionar-lhe au-
xílio e socorro.
Na segunda parte, encontramos os Regulamentos
Gerais, compostos de 39 regras: das tradições, hábitos,
usos e costumes: (tradução literal com vernáculo e termi-
nologia adaptados para o entendimento maçónico hodierno.
Exclusão de regras que se perdem em especificidades
operacionais maçônicas do século XVIII).
I - O Grão-Mestre, ou seu Adjunto, tem autoridade e
direito, não somente de estar presente em todas as lojas
regulares da jurisdição, mas também de presidi-las, tendo
o Venerável Mestre da Loja à sua esquerda. Constituem


30 • GOSC - Grande Oriente de Santa Catarina

```
as maiores dignidades da Potência.
II - O Venerável Mestre de uma Loja particular tem o
direito e a autoridade de reunir os membros de sua Loja
em sessões específicas quando isso lhe aprouver, em
qualquer conjuntura ou ocorrência, como designar a hora
e local habitual de sua reunião.
III - O venerável-Mestre de cada Loja particular deve
ter a Constituição, o Regulamento Geral e outros docu-
mentos da Potência, bem como o Estatuto ou o Regimento
da Loja e a relação dos obreiros.
IV - Nenhuma Loja iniciará mais de cinco novos irmãos
por vez, nem pessoa menor de idade ou emancipado, sal-
vo por dispensa do Grão-Mestre ou de seu Adjunto.
V - Nenhuma pessoa pode ser iniciada ou admitida
como membro de uma Loja particular, sem que a referida
Loja tenha recebido a indicação e procedido a sindicância,
salvo por dispensa do Grão-Mestre ou de seu Adjunto.
VI - Nenhuma pessoa pode ser registrada como Irmão
em uma Loja particular, ou ser admitido como membro,
sem o consentimento unânime de todos os membros des-
sa Loja presentes quando o candidato for escrutinado e
após ter recebido o Placet da Potência.
VII - Cada novo Irmão, ao ser iniciado, deve ser em
Loja ritualisticamente decorada e com todos os irmãos
presentes. O neófito deve depositar algum valor, segundo
suas posses, aos necessitados e indigentes, além da con-
tribuição fixada pelo Regulamento Interno da Loja e das
leis da Potência. O candidato prometerá, solenemente, de
se submeter à Constituição, obrigações e regulamentos, e
```

```
GOSC - Grande Oriente de Santa Catarina • 31
```
a todos os outros usos que lhe serão comunicados no tem-
po e lugar devidos.
VIII - Nenhum grupo ou número de irmãos se retirara
ou se separará da Loja em que foram iniciados como ir-
mãos, ou foram posteriormente admitidos como membros,
a menos que a Loja se tome muito numerosa, mas sempre
com a concordância do Grão-Mestre ou de seu Adjunto. E
quando estiverem separados, deverão imediatamente filiar-
se à outra Loja que mais lhes agradar, com o consenti-
mento unânime dessa outra Loja para onde irão, mas sem-
pre com autorização do Grão-Mestre. Se algum grupo ou
número de maçons resolverem formar uma Loja sem auto-
rização do Grão-Mestre, as lojas regulares não deverão
apoiá-los, nem reconhecê-los como irmãos leais e devida-
mente constituídos, nem aprovar seus atos.
IX - Se um Irmão se conduzir mal a ponto de inquietar
sua Loja, será devidamente admoestado por duas vezes
pelo Mestre ou pelos vigilantes em Loja constituída e, se
não reconhecer sua imprudência e se submeter aos con-
selhos dos seus irmãos, e não corrigir o que os ofendeu,
será tratado segundo o Regulamento Interno dessa Loja
particular e pelas leis da Potência
X - Toda discussão de matéria maçônica em Loja obe-
decerá ao critério de graus, isto é, assuntos privativos de
mestres não podem ser feitos na presença de aprendizes.
Na Ordem do Dia das sessões econômicas, estas são per-
tinentes a todos os obreiros bem como nas reuniões mai-
ores promovidas pela Potência, também conhecidas como
assembléias ou congressos. Presente o Grão-Mestre, este


32 • GOSC - Grande Oriente de Santa Catarina

```
tem sempre a última palavra nas reuniões da Potência e
das Lojas da circunscrição.
XI - Todas as lojas da jurisdição devem observar a
mesma liturgia e os respectivos ritos. Para entendimento
maçônico integral, é recomendável que os irmãos visitem
Lojas, preferencialmente de outros ritos..
XII - Um Grande Oriente é formado pelo Grão-Mestrado,
por auxiliares diretos e auxiliares descentralizados, que
cobrem toda a jurisdição. Deverá ter comunicação periódi-
ca e regular, principalmente nos dias significativos para a
Maçonaria Universal.
XIII - Na referida comunicação regular e periódica, to-
dos os assuntos que concernem à fraternidade em geral
ou às Lojas em particular, ou ainda aos irmãos, individual-
mente, serão calma, pausada e de forma madura discuti-
dos e tratados.
XIV - Se em qualquer reunião, ordinária ou extraordi-
nária, trimestral ou anual, o Grão-Mestre e seu Adjunto
estiverem ausentes, então o Mestre de uma Loja presen-
te, que for o Maçom mais antigo, presidirá como Grão-
Mestre pro tempore e estará investido de todos os pode-
res e honras durante esse período.
XV - Uma Potência Maçônica é composta pelo Grão-
Mestre e seu Adjunto, bem como assessores que rece-
bem designações específicas, segundo a função que exer-
cerem
XVI - Uma Loja é composta por um Venerável-Mestre e
dois vigilantes, que são as Luzes; secretário, tesoureiro e
orador, designados dignidades e outras múltiplas funções,
```

```
GOSC - Grande Oriente de Santa Catarina • 33
```
estes chamados de oficiais.
XVII - O Grão-Mestre, Adjunto, ministros ou secretári-
os, conselheiros, delegados, vigilantes e outras dignida-
des, poderá ser, ao mesmo tempo, Venerável-Mestre ou
Vigilante de uma loja particular.
XVIII - Se houver impedimento do Grão-Mestre Adjun-
to, o Grão-Mestre poderá escolher um Mestre Maçom que
reúna os requisitos para o cargo e que lhe prouver, para
ser seu Adjunto pro tempore.
XIX - Se o Grão-Mestre for considerado indigno de obe-
diência será substituído por eleição entre os mestres da
jurisdição.
XX - O Grão-Mestre e seu Adjunto visitarão, dentro das
possibilidades temporais e financeiras, as lojas da jurisdi-
ção durante seu Mestrado.
XXI - Se o Grão-Mestre falecer durante seu mestrado,
o Grão-Mestre Adjunto assume as funções até a data da
nova eleição.
XXII - (Este item do “The Old Charges”, fala especifica-
mente das Lojas de Londres e Westminster)
(Omite-se os itens XXII a XXVII, porquanto irrelevantes
para o presente Código de Procedimentos, conforme deci-
são do COLEGIADO na Reunião Ordinária do dia 06.12.03)





