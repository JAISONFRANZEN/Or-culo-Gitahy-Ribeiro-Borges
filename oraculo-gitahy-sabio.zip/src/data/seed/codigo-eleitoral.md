CÓDIGO ELEITORAL

## Lei nº 32/200 4

# CÓDIGO ELEITORAL

# Atualizado até a Lei nº 154/GOSC/2020- 2023


## CÓDIGO ELEITORAL

## Lei nº 32/200 4

```
Título I
```
```
Dados Iniciais
```
**Art. 1°** O presente CÓDIGO ELEITORAL contém normas destinadas a assegurar a organização e o
exercício dos direitos de votar e ser votado para os cargos eletivos maçônicos do GOSC - GRANDE
ORIENTE DE SANTA CATARINA.

**Art. 2°** Todo poder emana do povo maçônico e em seu nome será exercido por mandatários escolhidos nos
níveis expressos neste Código Eleitoral, no Regulamento Geral e no Código de Procedimentos.

**Art. 3°** Qualquer mestre maçom regular e filiado a uma loja do GOSC poderá investir-se em cargo eletivo,
respeitadas as condições constitucionais e regulamentares de elegibilidade e compatibilidade.

**Art. 4°** Para as eleições de Grão-Mestre e Grão-Mestre Adjunto são considerados eleitores os mestres
maçons que forem membros regulares e ativos de Lojas e triângulos regularmente constituídos e que façam
parte do GOSC. Para os cargos administrativos das lojas os maçons que o regimento interno da loja
estabelecer, devidamente homologados pelo GRÃO-MESTRADO.

```
Título II
```
```
Dos Órgãos Da Administração Eleitoral
```
```
E Suas Competências e da Comissão de Constituição e Legislação
```
**Art. 5º** O GRÃO-MESTRADO e o COLEGIADO são, respectivamente, os órgãos competentes para dirigir
e deliberar sobre eleições no âmbito do GOSC.

Parágrafo Único O COLEGIADO deliberará sobre matéria eleitoral, por iniciativa própria ou por
solicitação do GRÃO-MESTRADO, após parecer emitido pela comissão de constituição e legislação.

```
Capítulo II
```
```
Da Competência Originária
```
**Art. 6°** Compete originariamente ao GRÃO-MESTRADO, ad referendum do COLEGIADO e de acordo
com as normas estabelecidas neste Código, adotar as seguintes medidas:

I - O registro e o cancelamento do registro de candidatos a Grão-Mestre, Grão-Mestre Adjunto, veneráveis
mestres, vigilantes e tesoureiros;

II - Propor ao COLEGIADO a suspeição ou impedimento de membros do COLEGIADO;

III – O reconhecimento e as decisões de argüições de inelegibilidade;

IV - Baixar ato singularizando matéria eleitoral não prevista neste Código.

**Art. 7°** Compete originariamente ao COLEGIADO, segundo as normas estabelecidas neste Código, julgar
os recursos interpostos:

I - Dos atos e das decisões proferidas pelo GRÃO-MESTRADO;

II - Das decisões da comissão de conciliação e justiça;

III - Dos resultados totais ou parciais das eleições para Grão-Mestre e Grão-Mestre Adjunto;

IV - Dos conflitos de jurisdição argüidos por membros do COLEGIADO.


## CÓDIGO ELEITORAL

## Lei nº 32/200 4

```
Capítulo III
```
```
Da Competência Privativa
```
**Art. 8°** Compete privativamente ao GRÃO-MESTRADO:

I - Organizar secretaria especial para os atos, fatos e providências eleitorais;

II - Registrar as chapas concorrentes aos cargos de Grão-Mestre, Grão-Mestre Adjunto, veneráveis mestres,
vigilantes e tesoureiros;

III - Fixar datas e procedimentos de eleições quando não determinados por disposições constitucionais ou
neste Código;

IV - Fixar o processo eleitoral em geral e a sua apuração;

V - Proclamar e expedir diploma para os cargos eletivos de Grão-Mestre, Grão-Mestre Adjunto, veneráveis
mestres, vigilantes e tesoureiros;

VI - Responder às consultas que lhe forem endereçadas sobre matéria eleitoral;

VII - Zelar pelo cumprimento das decisões emanadas do COLEGIADO.

```
Capítulo IV
```
```
Da Comissão de Constituição e Legislação
```
**Art. 9°** O COLEGIADO, por intermédio da comissão de constituição e legislação, exercerá a função de
procuradoria eleitoral junto à comissão de conciliação e justiça para os efeitos do Art. 6° deste Código.

**Art. 10** A comissão de constituição e legislação poderá, sem prejuízo de suas funções, eleger, por maioria
de votos, outros membros da referida Comissão para auxiliar nas funções de Procuradoria.

```
Título III
```
```
Das Eleições do Prazo e Registro de Candidatos da Propaganda E do Voto Secreto
```
```
Capítulo I
```
```
Das Eleições
```
**Art. 11** Salvo as eleições das administrações das lojas jurisdicionadas, que poderão, a critério de cada loja,
ser realizadas em reunião presencial ou remota, com utilização de recursos virtuais, ou por meio eletrônico,
sem a necessidade de reunião de pessoas e através de voto secreto ou aberto, todas as demais eleições serão
diretas e secretas, assegurado aos mestres maçons que estejam na plenitude de seus direitos maçônicos o
direito de votarem e serem votados, sendo eleitos os candidatos que obtiverem maioria simples de votos.
**(Alterado pela Lei nº 154/GOSC/2020-2023, de 24 de abril de 2022)**

§1° O direito do exercício do voto é facultativo.

§2° As eleições, em todos os níveis, serão processadas em turno único e por maioria simples.

**Art. 12** Para votar e ser votado o maçom deverá:

I – Estar quite com a Tesouraria de sua loja até o mês de março, inclusive, do ano em que ocorrerá o pleito
eleitoral; **(alterado pela Lei nº 154/GOSC/2020-2023, de 24 de abril de 2022)**

II - Ter, nos últimos doze meses que antecederem as eleições, frequência mínima de 2/3 (dois terços) nas
sessões realizadas pela loja da qual é membro efetivo, no período de 1° de abril do ano anterior às eleições
a 31 de março do ano em que ocorrerá o pleito eleitoral, para as eleições para os cargos de Venerável


## CÓDIGO ELEITORAL

## Lei nº 32/200 4

Mestre, Vigilantes e Tesoureiro, e no período de 1° de janeiro do ano anterior às eleições a 31 de janeiro
do ano do pleito eleitoral, para as eleições para Grão-Mestre e Grão-Mestre Adjunto. **(Alterado pela Lei
nº 154/GOSC/2020-2023, de 24 de abril de 2022).**

§1° Dos mestres maçons pertencentes aos órgãos administrativos do GOSC serão exigidos apenas 25%
(vinte e cinco) por cento da freqüência mínima para eles prevista.

§2° Do Grão-Mestre e do Grão-Mestre Adjunto, em exercício, não será exigida nenhuma frequência na loja
à qual pertence.

§ 3º Do Maçom Emérito será exigida a frequência mínima de 1/3 (um terço) nas Sessões realizadas pela
loja à qual pertence para votar e 2/3 (dois terços) nas Sessões realizadas pela loja à qual pertence para ser
votado. **(Acrescentado pela Lei nº 133/GOSC/2017- 2020 , de 28 de junho de 2019)**

§ 4º A aptidão para o exercício do direito de votar e ser votado será estabelecida e auditada, no tocante à
frequência, através do sistema de gestão do Grande Oriente de Santa Catarina – GOSC, em “LOJA >
SISTEMA DE LOJA > RELATÓRIOS > FREQUENCIA > FREQUÊNCIA ELEITORAL”.
**(Acrescentado pela Lei nº 154/GOSC/2020-2023, de 24 de abril de 2022)**

§ 5º A frequência para fins eleitorais compreende as seguintes modalidades de reunião:

I – Reunião por videoconferência;

II – Ritualística – Sessão Econômica;

III – Ritualística – Sessão Especial;

IV – Ritualística – Sessão Magna. **(Acrescentado pela Lei nº 154/GOSC/2020-2023, de 24 de abril de
2022)**

**Art. 13** Os candidatos poderão se inscrever somente a um cargo e em uma única chapa. **(Alterado pela Lei
nº 154/GOSC/2020-2023, de 24 de abril de 2022)**

Parágrafo Único **(Revogado pela Lei nº 154/GOSC/2020- 2023 , de 24 de abril de 2022)**

**Art. 14** Os mandatos para os cargos eletivos terminarão com a posse dos novos eleitos.

**Art. 15** Para Grão-Mestre e Grão-Mestre Adjunto e para as eleições nas lojas aos cargos de venerável
mestre, vigilantes e tesoureiro somente poderão votar os mestres maçons ativos e regulares na potência.

Parágrafo único. **(Revogado pela Lei n.º 86/2008, art. 7°)**

```
Capítulo II
```
```
Do Prazo e Registro de Candidatos
```
**Art. 16** Somente poderão concorrer às eleições mestres maçons regulares do GOSC, obedecido:

I - Para os cargos de Grão-Mestre e Grão-Mestre Adjunto:

a) ter no mínimo sete anos de obediência ao GRANDE ORIENTE DE SANTA CATARINA;

b) ter sido exaltado há mais de cinco anos e que esteja no gozo de seus direitos maçônicos;

c) ter sido mestre instalado há mais de três anos;

d) ser brasileiro nato ou que, naturalizado, resida no país há mais de dez anos;

II - Para o cargo de venerável mestre, o candidato deverá ter sido exaltado há mais de três anos e ser membro
regular da oficina há mais de um ano, exceto no caso em que haja recusa formal registrada em balaústre,
pelos demais mestres aptos ao exercício do cargo.


## CÓDIGO ELEITORAL

## Lei nº 32/200 4

III - Para os cargos de vigilantes e tesoureiro, os mestres maçons deverão ter sido exaltados há mais de
dezoito meses e ser membro regular da oficina há mais de um ano.

Parágrafo Único A contagem dos prazos referidos neste artigo terá como referência a data da eleição.
**(Alterado pela Lei nº 107/2011 conciliado ao previsto no Regulamento Geral, de 28 de março de 2011)**

IV - O mestre maçom não poderá assumir qualquer cargo eletivo em loja se não for membro efetivo da
mesma há pelo menos 1 (um) ano.

Parágrafo Único O mestre maçom poderá como membro filiado, assumir qualquer cargo eletivo em loja
desde que essa seja a única loja filiada ao GOSC no município sede.

**Art. 17** Nenhum registro será admitido fora do prazo de inscrição estabelecido neste Código ou que não
venha acompanhado de todos os documentos exigidos:

I - Para os cargos de Grão-Mestre e de Grão-Mestre Adjunto no mês de fevereiro: do primeiro ao último
dia útil do mês do ano do pleito, no horário das 8h às 12h e das 14h às 18h.

II - Para os cargos de venerável mestre, vigilantes e tesoureiro no mês de abril: do primeiro ao décimo -
quinto dia do mês do ano do pleito eleitoral. **(Alterado Pela Lei nº 107/2011, art. 2°, conciliado com o
Regulamento Geral, de 28 de março de 2011)**

Parágrafo Único O prazo para impugnação dos registros de candidaturas aos cargos eletivos será contado a
partir da data dos registros dos candidatos junto ao GOSC.

**Art. 18** Serão registrados perante:

I - O GOSC os candidatos a Grão-Mestre e a Grão-Mestre Adjunto;

II – As lojas, pela forma definida no Edital de Convocação de Eleição, os candidatos a Venerável Mestre,
Primeiro Vigilante, Segundo Vigilante e Tesoureiro; **(alterado pela Lei nº 154/GOSC/2020-2023, de 24
de abril de 2022)**

III - No Boletim Oficial do mês de fevereiro, com circulação no mês de março, o GOSC informará os nomes
dos Candidatos à eleição para os cargos de Grão-Mestre e Grão-Mestre Adjunto e os nomes das chapas que
requereram registros; **(alterado pela Lei nº 154/GOSC/2020-2023, de 24 de abril de 2022)**

IV - No período de 01 a 15 de abril serão realizadas as inscrições das chapas, devendo as lojas comunicarem
ao GOSC até o dia 23 do mês de abril, os nomes dos candidatos a Venerável Mestre, a Primeiro e a Segundo
Vigilantes e a Tesoureiro, cujas nominatas serão publicadas no Boletim Oficial do mês de abril. **(Alterado
pela Lei nº 154/GOSC/2020-2023, de 24 de abril de 2022).**

**Art. 18-A** A inscrição de chapas para a administração das Lojas poderá ser feita mediante a apresentação
através da Bolsa de Propostas e Informações, ou através de e-mail enviado ao Venerável Mestre, com cópia
ao Tesoureiro, ao Orador, ao Secretário e ao Chanceler da Loja, até o dia 15 de abril do ano da eleição.
**(Acrescentado pela Lei nº 154/GOSC/2020-2023, de 24 de abril de 2022)**

**Art. 18-B** Recebido o pedido de inscrição de chapa, manifestar-se-ão:

I - O Tesoureiro da Loja, sobre a regularidade financeira dos candidatos;

II - O Chanceler da Loja, sobre a frequência dos candidatos, que será estabelecida e auditada conforme
disposto no § 4º, do artigo12, deste Código;

III - O Orador da Loja, sobre o preenchimento, pelos candidatos, de todos os requisitos para serem votados,
em especial o tempo de exaltação, em conformidade com a legislação maçônica. **(Acrescentado pela Lei
nº 154/GOSC/2020-2023, de 24 de abril de 2022)**

**Art. 18-C** Recebidas as manifestações acima, o Venerável Mestre emitirá parecer final sobre a regularidade
das candidaturas e:


## CÓDIGO ELEITORAL

## Lei nº 32/200 4

I – Deferirá o pedido de inscrição da chapa e determinará, a quem de direito, o encaminhamento ao GOSC,
até o dia 23 de abril, impreterivelmente, do pedido de inscrição e homologação da(s) chapa(s), em “LOJA
> PROCESSOS > ELEIÇÃO DE LOJA”; ou

II – Indeferirá o pedido, comunicando à chapa e solicitando a sua regularização, conforme o caso.

**Art. 18-D** O Grão-Mestre poderá, verificando o descumprimento de qualquer dos requisitos para ser
votado, indeferir a inscrição de qualquer candidato integrante da chapa, cabendo à Loja a sua substituição,
no prazo de 48 horas da comunicação. **(Acrescentado pela Lei nº 154/GOSC/2020-2023, de 24 de abril
de 2022)**

**Art. 18-E** O descumprimento dos prazos previstos nos artigos 18-A, 18-C e 18 - D implicará na não
homologação da chapa, impossibilitando a realização da eleição. **(Acrescentado pela Lei nº
154/GOSC/2020-2023, de 24 de abril de 2022)**

**Art. 19** Os registros dos candidatos a Grão-Mestre e a Grão-Mestre Adjunto deverão ser feitos em chapa
única e indivisível.

```
Capítulo III
```
```
Da Propaganda Eleitoral
```
**Art. 20** A propaganda aos cargos eletivos de Grão-Mestre e de Grão-Mestre Adjunto só será permitida após
1º de setembro do ano anterior às eleições.

§1° É vedada, 48 (quarenta e oito) horas antes das eleições, qualquer propaganda eleitoral.

§2° Os candidatos aos cargos eletivos de Grão-Mestre e de Grão-Mestre Adjunto somente poderão fazer
qualquer tipo de propaganda, nas lojas da jurisdição, a partir do dia 1º de setembro do ano anterior às
eleições.

§3° Entende-se por propaganda o envio de cartas, manifestos, programas de governo, enfim, todo e qualquer
material escrito ou impresso.

§4º Fica expressamente vedado, também, antes da data acima estabelecida, todo e qualquer pronunciamento
nas lojas da jurisdição, apresentando-se ou apresentando outrem como candidato, bem como a distribuição
de botons, adesivo ou similar.

§5° Não será considerada propaganda eleitoral:

I - A presença em sessão de qualquer loja, em caráter de visitação ou de prestigiamento de seus eventos;

II - A manifestação em qualquer loja sobre os atos desenvolvidos na sessão ou sobre assuntos de interesse
da própria loja, do GOSC ou da maçonaria em geral, desde que compatíveis com as limitações impostas
pelos parágrafos anteriores;

III – A participação em reuniões, seminários, congressos ou outros eventos oficiais desenvolvidos pelo
GOSC, bem como a livre manifestação de idéias, propostas e projetos, desde que não firam as limitações
impostas neste Artigo.

**Art. 21** Toda propaganda eleitoral será confeccionada, distribuída e realizada sob a responsabilidade do
candidato e/ou da chapa.

**Art. 22** Não será tolerada a propaganda:

I – De processos violentos para subverter a ordem no seio dos obreiros e das lojas;

II – Que provoque a animosidade entre as lojas e/ou obreiros;

III – Que instigue a desobediência à lei;


## CÓDIGO ELEITORAL

## Lei nº 32/200 4

IV – Que difame, calunie ou injurie qualquer obreiro e/ou candidato.

§1° Os candidatos e seus simpatizantes, quando da campanha eleitoral, em visita às lojas e triângulos,
deverão fazê-lo apenas em sessão no grau de mestre maçom, tão somente para apresentar a plataforma ou
proposta de administração, ficando vedado qualquer juízo de valor sobre outros candidatos, lojas e
triângulos da administração do GOSC, bem como manifestações desrespeitosas dirigidas aos ocupantes
atuais ou anteriores dos cargos pleiteados. **(Alterado pela Lei nº 86/2008, art. 5°, de 27 de setembro de
2008 )**

§2° Os candidatos e seus simpatizantes que infringem os dispositivos acima serão convidados a cobrirem
o Templo definitivamente, fato esse que deverá ser comunicado imediatamente ao GRÃO-MESTRADO, o
qual adotará as medidas previstas no Código Penal maçônico ou na legislação específica.

```
Capítulo IV
```
```
(Alterado pela Lei n. 154/GOSC/2020-2023, de 24 de abril de 2022).
```
```
Do Voto
```
**Art. 23** Ressalvado o disposto em relação às eleições para o Grão-Mestrado, a eleição para a administração
das lojas, a seu exclusivo critério, poderá ser realizada em reunião presencial ou virtual, por meio remoto
ou eletrônico, através de voto aberto ou secreto.

```
Título IV
```
```
Das Incompatibilidades Das Inelegibilidades e Disposições Gerais
```
```
Capítulo I
```
```
Das Incompatibilidades
```
**Art. 24** São incompatíveis:

I - Os cargos de Grão-Mestre e de Grão-Mestre Adjunto com os de venerável mestre, vigilantes e tesoureiro;

II - Os cargos de tesoureiro e hospitaleiro com os da comissão de finanças da loja;

III - Os cargos de Luzes com qualquer outro cargo ou comissão nas lojas, salvo quando as mesmas não
contarem com mais de 15 obreiros ativos no grau de mestre;

IV - O cargo de membro do conselho-geral com outro cargo eletivo;

V - O cargo de orador com qualquer comissão permanente da loja;

VI - O cargo de Grão-Mestre ou de Grão-Mestre Adjunto ou de venerável mestre, vigilante e tesoureiro
com o de superintendente ou superintendente adjunto e de delegado ou delegado adjunto.

§1° Os mestres maçons que receberem ordenado, ajuda de custo ou qualquer tipo de remuneração em
dinheiro, transitória ou periodicamente, do GOSC ou das lojas não poderão exercer cargos eletivos do
GOSC ou das lojas filiadas se não se desincompatibilizarem até 3 (três) meses antes da data do pleito a que
concorrerão.

§2° O maçom nomeado para os cargos de superintendente e de delegado regional titular, ou adjuntos, não
poderá exercer outro cargo ou função.

§3° É vedado o exercício simultâneo de dois cargos eletivos à administração da loja e desta com o GOSC.

```
Capítulo II
```

## CÓDIGO ELEITORAL

## Lei nº 32/200 4

```
Das Inelegibilidades
```
**Art. 25** São inelegíveis:

I - Para os cargos de Grão-Mestre e de Grão-Mestre Adjunto o mestre maçom que:

a) não for membro ativo de uma das lojas da jurisdição do GOSC;

b) não tiver completado sete anos de obediência ao GOSC;

c) não for exaltado há mais de três anos no grau de mestre;

d) não estiver em pleno gozo dos direitos maçônicos;

e) não sendo brasileiro nato, ou naturalizado, não resida no país há mais de dez anos;

f) for empregado, receber benefícios ou tiver contrato com o GOSC ou, sendo gestor financeiro, não se
desincompatibilizar até 06 (seis) meses antes das eleições;

g) tiver idade inferior a 33 (trinta e três) anos;

h) não for mestre instalado há mais de 3 (três) anos;

i) não assinar o termo de compromisso que não receberá ordenado, pró-labore, vencimentos ou valor
financeiro para o exercício do cargo.

Parágrafo Único Poderá o Grão-Mestre ou o Grão-Mestre Adjunto receber ajuda de custo quando em
viagem ou representação exclusiva do GOSC, devendo, para tanto, apresentar as notas fiscais e prestar
contas de seus gastos.

II - Para venerável mestre de oficina o mestre maçom que:

a) não for exaltado há pelo menos 2 (dois) anos;

b) for contratado, empregado ou beneficiário do GOSC e não se desincompatibilizar até 3 (três) meses antes
das eleições.

```
Capítulo III
```
```
Das Disposições Gerais
```
**Art. 26** Nas eleições realizadas para os cargos de Grão-Mestre e de Grão-Mestre Adjunto o maçom que
pertencer a mais de uma loja só poderá votar na loja à qual está registrado como membro efetivo.

**Art. 27** No momento da inscrição da chapa às eleições de Grão-Mestre e de Grão-Mestre Adjunto é
indispensável a expressa aquiescência dos candidatos bem como a apresentação de seus nomes ao GOSC
pelo mínimo de 5 (cinco) lojas ou 50 (cinqüenta) mestres maçons regulares da jurisdição.

Parágrafo Único O GRÃO-MESTRADO comunicará, em uma só prancha, até 5 (cinco) dias úteis após o
término do prazo estipulado para as inscrições, os nomes dos candidatos homologados bem como os dos
candidatos impugnados, com o respectivo motivo.

```
Título V
```
```
Das Eleições para Grão-Mestrado, da Cédula Eleitoral, da Votação, da apuração, da Totalização e
da Publicação do Resultado, da Proclamação dos Eleitores e da Diplomação
```
```
Capítulo I
```
```
Das Eleições para Grão-Mestrado
```

## CÓDIGO ELEITORAL

## Lei nº 32/200 4

**Art. 28** As eleições para Grão-Mestre e Grão-Mestre Adjunto far-se-ão, por sufrágio universal direto e
secreto do povo maçônico, trienalmente na primeira segunda-feira útil do mês de maio do ano que findar o
mandato, em sessão especial de eleição, no grau de mestre maçom.

Parágrafo Único Às eleições por este código convocadas cabe ao GRÃO-MESTRADO, com antecedência
de 30 (trinta) dias, remeter as cédulas e o modelo da ata respectivo.

**Art. 29** O mestre maçom que na data das eleições estiver ausente de seu oriente poderá votar, para os cargos
de Grão-Mestre e de Grão-Mestre Adjunto, em outra Loja do GOSC em que se achar presente, registrando-
se essa particularidade na ata.

Parágrafo único. **(Revogado pela Lei nº. 86/2008, art. 7°)**

**Art. 30** Não poderão participar das eleições para Grão-Mestre e Grão-Mestre Adjunto as oficinas que
estiverem em atraso com o pagamento de suas obrigações pecuniárias para com o GOSC que, em publicação
com 60 (sessenta) dias de antecedência, relacionará e dará publicidade das inadimplências.

Parágrafo Único A loja inadimplente, todavia, poderá regularizar essa situação no prazo de trinta dias.

```
Capítulo II
```
```
Da Cédula Eleitoral
```
**Art. 31** As cédulas oficiais para as eleições de Grão-Mestre e de Grão-Mestre Adjunto serão confeccionadas
e distribuídas, exclusivamente, pelo GRÃO-MESTRADO do GOSC.

§1° A impressão será uniforme para todas as cédulas, bem como as letras para todas as chapas e destas
últimas para com todos os candidatos.

§2° Nas cédulas os nomes dos candidatos ou chapas figurarão na ordem determinada por sorteio.

§3° O sorteio será realizado, após o deferimento do último pedido de registro, em audiência presidida pela
comissão de constituição e legislação.

§4° A audiência para o sorteio será realizada no décimo quinto dia útil do mês de março do ano das eleições,
às 14 horas, na sede do GOSC.

§5° As cédulas oficiais serão confeccionadas de maneira tal que, dobradas, resguardem o sigilo do voto.

```
Capítulo III
```
```
Da Votação
```
**Art. 32** A sessão especial de eleição será aberta pelo venerável mestre, ou seu substituto legal, na data
prevista, com início e término no horário regimental da loja, passando-se de imediato à Ordem do Dia, sem
formalidades ritualísticas.

Parágrafo Único Imediatamente após o encerramento da votação dar-se-á início ao escrutínio dos votos.

**Art. 33** O venerável mestre, ou seu substituto legal, organizará a mesa eleitoral receptora dos votos, que
deve assim ser composta:

I - Venerável mestre, ou seu substituto legal;

II - Secretário;

III - Orador;

IV **- (Revogado pela Lei nº 86/2008, art. 6°, de 27 de setembro de 2008)**


## CÓDIGO ELEITORAL

## Lei nº 32/200 4

IV - Fiscais.

Parágrafo Único Os fiscais, em número máximo de dois por chapa, serão por ela indicados.

**Art. 34** Composta a mesa eleitoral receptora de votos, o venerável mestre, ou seu substituto legal, declarará
a finalidade da Sessão, passando imediatamente à Ordem do Dia.

**Art. 35** Antes do início da votação o venerável mestre, ou seu substituto legal, exibirá aos presentes a urna
vazia.

**Art. 36** O secretário da mesa eleitoral procederá à chamada dos obreiros, na ordem em que assinaram o
livro de presença, desde que em condições de voto, ouvidos, para tanto e com antecedência, o tesoureiro e
o chanceler.

**Art. 37** O eleitor que for liberado na forma do artigo anterior subirá ao Oriente para assinar, no Altar, a
folha de votação e receber do venerável mestre, ou seu substituto legal, a cédula devidamente rubricada em
conjunto com o secretário.

**Art. 38** De posse da cédula única, o obreiro eleitor dirigir-se-á ao espaço apropriado, onde assinalará, no
local indicado, o(s) nome(s) do(s) Candidato(s), fechando-a depois nas dobras respectivas e próprias.

**Art. 39** Voltando ao Altar, o eleitor mostrará à mesa a cédula dobrada, a fim de que seja verificada a sua
autenticidade, e a depositará na urna.

**Art. 40** Encerrada a votação, dentro do horário previsto no Art. 32º deste Código, o venerável mestre, ou
seu substituto legal, encerrará e assinará a folha de votação e o livro de presença.

```
Capítulo IV
```
```
Da Apuração
```
**Art. 41** Finda a votação o venerável mestre, ou seu substituto legal, comporá a mesa eleitoral escrutinadora
dos votos, dela não podendo participar quaisquer candidatos, que deve assim ser composta:

I - Venerável mestre, ou seu substituto legal;

II - Secretário;

III - Orador;

IV - Escrutinadores;

V - Fiscais.

§1° Os fiscais serão indicados pelas chapas concorrentes.

§2° Não havendo indicação de fiscais por parte das chapas o venerável mestre, ou seu substituto legal,
designará, para o exercício dessas funções, dois mestres maçons dentre os eleitores presentes.

§3° Os fiscais indicados pelas chapas deverão acompanhar os atos de apuração dos votos.

**Art. 42** Formada a mesa escrutinadora dar-se-á início aos trabalhos:

I - Com a conferência da quantidade de cédulas existente na urna, confrontando-a com o número de votantes
que assinaram a folha de votação;

II - Coincidindo o número de cédulas com o de votantes proceder-se-á à apuração com a contagem dos:

a) votos brancos;

b) votos nulos;


## CÓDIGO ELEITORAL

## Lei nº 32/200 4

c) votos válidos;

III - Apurando-se os votos válidos por chapa.

Parágrafo Único Quando na apuração dos votos o número de cédulas não corresponder ao número de
votantes a votação será declarada nula, devendo a mesma ser renovada imediatamente.

**Art. 43** As cédulas oficiais; na medida, em que forem sendo abertas pelo venerável mestre, ou seu substituto
legal, serão examinadas e lidas em voz alta.

**Art. 44** A contagem das cédulas válidas será feita uma a uma, com a confirmação dos mesários, devendo
o resultado ser anunciado após a concordância de todos os escrutinadores e fiscais.

**Art. 45** São nulas as cédulas:

I - Que contiverem votos para mais de uma chapa;

II - Que não corresponderem ao modelo oficial;

III - Que não estiverem devidamente assinadas pelo venerável mestre, ou seu substituto legal, e pelo
secretário;

IV - Que contiverem expressões, frases ou sinais que possam identificar o voto;

V - Quando a assinalação estiver fora do quadrilátero próprio, desde que torne duvidosa a manifestação da
vontade do obreiro eleitor.

**Art. 46** À medida que os votos forem apurados poderão os fiscais apresentar impugnações, que serão
decididas, por maioria de votos, pela mesa eleitoral escrutinadora.

**Art. 47** Durante o processo de escrutinação as cédulas permanecerão sobre a mesa escrutinadora, só
podendo ser incineradas depois de anunciado o resultado definitivo das eleições.

**Art. 48** Terminada a apuração, o venerável mestre, ou seu representante legal, anunciará o resultado das
eleições para Grão-Mestre e Grão-Mestre Adjunto e concederá a palavra a quaisquer dos mestres maçons
votantes que desejarem fazer reclamação ou protesto sobre o pleito. Não havendo manifestação o venerável
mestre, ou seu substituto legal, anunciará o resultado final.

**Art. 49** Após anunciado o resultado final das eleições será lavrada a respectiva ata.

§1° A Ata deverá ser preenchida conforme o modelo previamente distribuído pelo GOSC, devendo conter,
obrigatoriamente:

I - O dia das eleições;

II - O local e horário do início e término dos trabalhos eleitorais;

III - O número de maçons que votaram;

IV - Os nomes dos eleitos e os respectivos cargos;

V - A especificação quantitativa da apuração dos votos brancos, nulos e válidos;

VI - A especificação dos votos válidos por chapa;

VII - As ocorrências se houverem.

§2° Após a apreciação e votação da ata serão colhidas as seguintes assinaturas:

I - Do venerável mestre, ou seu substituto legal;

II - Do secretário;

III - Dos escrutinadores;


## CÓDIGO ELEITORAL

## Lei nº 32/200 4

IV - Dos fiscais.

§3° A folha de votação deverá ser apensada à ata.

**Art. 50** Cumpridas as formalidades dos artigos anteriores, o venerável mestre, ou seu substituto legal,
declarará, com um golpe de malhete, encerrada a sessão eleitoral.

**Art. 51** No dia imediatamente posterior às eleições a secretaria da loja remeterá à COMISSÃO
ELEITORAL do GOSC a ata e a folha de votação, devidamente assinadas e rubricadas.

§1° Essa remessa será feita em invólucro fechado, lacrado e rubricado pelo venerável mestre, ou seu
substituto legal, e pelo secretário da loja, por via postal ou sob protocolo, conforme for mais rápido e seguro.

§2° A secretaria da loja deverá manter em seus arquivos o comprovante da remessa e a cópia de todo o
material eleitoral enviado ao GOSC.

```
Capítulo V
```
```
Da Totalização e da Publicação do Resultado
```
**Art. 52** A COMISSÃO ELEITORAL do GOSC, de posse de todos os resultados oficiais das lojas e
triângulos jurisdicionados, procederá à totalização final das eleições para Grão-Mestre e Grão-Mestre
Adjunto

**Art. 53** Totalizado, o resultado final das eleições para Grão-Mestre e Grão-Mestre Adjunto será publicado
no Boletim Oficial Especial e no mural do GOSC.

Parágrafo Único Após a publicação dos resultados das eleições caberá recurso no prazo de 15 (quinze) dias,
que será julgado pela comissão de conciliação e justiça dentro de 15 (quinze) dias do recebimento
devidamente protocolizado.

**Art. 54** A parte recorrente que se mostrar insatisfeita com a decisão exarada pela comissão de conciliação
e justiça poderá ainda recorrer, no prazo de 15 dias, ao COLEGIADO, o qual deverá ser convocado
extraordinariamente para deliberar sobre o recurso.

```
Capítulo VI
```
```
Da Proclamação dos Eleitos
```
**Art. 55** Em sessão extraordinária serão julgados todos os recursos, se houverem, e proclamados os
resultados gerais das eleições, lavrando-se a ata em livro especial, aprovada e assinada nessa mesma sessão

Parágrafo Único Não havendo recurso dentro do prazo estipulado, o GRÃO-MESTRADO proclamará os
eleitos, cujo ato de proclamação será apresentado ao COLEGIADO na Reunião Ordinária do mês de junho,
coincidente com a posse do Grão-Mestre e do Grão-Mestre Adjunto eleitos.

```
Capítulo VII
```
```
Da Proclamação
```
**Art. 56** O Ato de Diplomação bem como o Diploma serão assinados pelo Grão-Mestre, pelo Grão-Mestre
Adjunto e pelos 4 (quatro) Presidentes das Comissões Permanentes do COLEGIADO do GOSC.

```
Título VI
```

## CÓDIGO ELEITORAL

## Lei nº 32/200 4

```
Das Eleições para a Administração das Lojas, da Época das Eleições, da Cédula Eleitoral, da
Votação, da Apuração, Proclamação e da Ata, da Publicação do Resultado, da Diplomação, da
Vacância e da Reeleição dos Veneráveis Mestres.
```
```
Capítulo I
```
```
Das Eleições para a Administração das Lojas
```
**Art. 57** Quatorze dias antes de quaisquer eleições o secretário da loja fixará, na Sala dos Passos Perdidos,
o edital anunciando as chapas inscritas e convocando os obreiros para o dia e hora em que devem ser
realizadas as eleições.

§1° Nas duas sessões que antecederem as eleições nas oficinas, por ocasião da Ordem do Dia, poderão os
candidatos:

I - Fazer a apresentação de suas plataformas eleitorais, desde que requeridas por eles ou seus representantes;

II - Prestar esclarecimentos gerais;

III - Ser questionados sobre os procedimentos a serem observados na realização do pleito, com a apreciação
das impugnações de candidatos, se houverem, com o parecer do orador.

§2° O candidato a qualquer cargo eletivo das oficinas deverá comunicar, por escrito, o seu desejo de se
candidatar, nos moldes determinados no Art.17º deste Código.

§3° Qualquer mestre maçom do quadro de obreiros poderá apresentar impugnação, por escrito, à
candidatura de quaisquer dos candidatos, em prancha dirigida ao orador da oficina, manifestando as razões
de sua atitude, até o prazo de 15 (quinze) dias antes das eleições.

§4° As oficinas afixarão, na Sala dos Passos Perdidos, a nominata dos concorrentes aos diversos cargos
eletivos, por chapa.

**Art. 58** São nulas as eleições para as quais não forem respeitadas as exigências deste Código Eleitoral.

```
Capítulo II
```
```
Da Época das Eleições
```
**Art. 59** As eleições para venerável mestre, vigilantes e tesoureiro das Lojas far-se-ão, anualmente, na
primeira quinzena do mês de maio. **(Alterado pela Lei nº 87/2009, art. 6°, de 09 de fevereiro de 2009)**

```
Capítulo III
```
```
Da Cédula Eleitoral
```
**Art.60 (Revogado pela Lei n. 154/GOSC/2020-2023)**

```
Capítulo IV
```
```
(Alterado pela Lei n. 154/GOSC/2020-2023, de 24 de abril de 2022)
```
```
Da Votação
```
**Art. 61** A votação será realizada em Sessão Especial de Eleição, que poderá ser realizada em qualquer das
modalidades previstas no art. 23 deste Código, com ou sem formalidades, a critério da loja.

**Art. 62** Concorrendo chapa única para a administração da loja, a eleição poderá ser feita por aclamação.


## CÓDIGO ELEITORAL

## Lei nº 32/200 4

**Art. 63** Concorrendo mais de uma chapa para a administração da Loja, as opções serão as seguintes, de
acordo com o número de chapas concorrentes:

I - Chapa (denominação da chapa);

II - Chapa (denominação da chapa);

III – Abstenção.

**Art. 64 (Revogado pela Lei nº 154/GOSC/2020- 2023 , de 24 de abril de 2022)**

**Art. 65 (Revogado pela Lei nº 154/GOSC/2020- 2023 , de 24 de abril de 2022)**

```
Capítulo V
```
```
(Alterado pela Lei nº 154/GOSC/2020-2023, de 24 de abril de 2022)
```
```
Da Apuração, Proclamação e da Ata
```
**Art. 66** Finda a votação, far-se-á a contagem dos votos, de acordo com a modalidade de votação realizada,
confrontando-se o número de votantes com o número de Obreiros aptos a votar presentes na reunião.

**Art. 67** Quando o número de votos não corresponder ao número de obreiros aptos a votar presentes à
reunião, a votação será declarada nula, devendo ser renovada imediatamente.

**Art. 68** Encerrada a apuração dos votos, o Venerável Mestre anunciará o resultado da eleição e concederá
a palavra aos obreiros aptos a votar presentes à reunião, momento em que deverão ser feitas eventuais
reclamações e impugnações de votos e/ou do resultado do pleito.

**Art. 69** Finda a eleição, será elaborada ata circunstanciada, que será assinada pelo Venerável Mestre,
Orador e Secretário, admitindo-se assinatura eletrônica ou por meio eletrônico, e que deverá conter:

I – A data da eleição;

II - A descrição do método utilizado para a eleição;

II - O nome e o CIM dos Mestres Maçons presentes à sessão e o número de Mestres Maçons aptos a votar;

III - O número de Mestres Maçons presentes à sessão e o número de Mestres Maçons votantes;

IV - O número de votos computados para cada uma das opções de voto, de acordo com o art. 63 deste
Código, caso concorra mais de uma chapa;

V – O nome dos eleitos e os respectivos cargos;

VI - A existência ou não de impugnação;

VII - A existência ou não de qualquer outra manifestação;

VIII - Outras ocorrências ou particularidades verificadas.

§ 1º A falta de indicação do disposto nos incisos I a VII implicará a nulidade da eleição.

§ 2º A fraude e a manipulação de resultado ou do processo eleitoral, ou a sua tentativa, constituem infrações
maçônicas de natureza grave (art. 9º do Código Eleitoral) e sujeitarão o infrator às medidas legais cabíveis,
maçônicas e profanas.

§ 3º É direito de todo Maçom e dever do Orador e do Venerável Mestre, em tomando conhecimento de
quaisquer dos fatos descritos no parágrafo anterior, comunicar a quem de direito, para que as medidas
cabíveis sejam adotadas.


## CÓDIGO ELEITORAL

## Lei nº 32/200 4

**Art. 70** A Loja deverá manter arquivada a documentação eleitoral, em formato digital, pelo período de 90
dias, ou até o julgamento de eventuais impugnações e recursos, para dirimir eventuais dúvidas.

**Art. 71 (Revogado pela Lei nº 154/GOSC/2020- 2023 , de 24 de abril de 2022)**

**Art. 72 (Revogado pela Lei nº 154/GOSC/2020- 2023 , de 24 de abril de 2022)**

```
Capítulo VI
```
```
Da Publicação do Resultado
```
**Art. 73** O GOSC, por intermédio do GRÃO-MESTRADO, homologará o resultado das eleições e o
publicará por meio do Boletim Oficial.

**Art. 74** Da homologação das eleições para a administração das lojas caberá recurso à Assembleia Geral de
obreiros da loja, em Câmara do Meio.

§1° A chapa ou obreiro que quiser recorrer do processo eleitoral deverá fazê-lo antes do encerramento da
ata, podendo editá-lo no prazo de 48 (quarenta e oito) horas.

§2° O venerável mestre, ou seu substituto legal, abrirá vistas ao orador, também pelo prazo de 48 (quarenta
e oito) horas, para seu parecer.

§3° Em igual prazo qualquer obreiro ou chapa poderá se manifestar como oponente ou litisconsorte.

§4° O venerável mestre, ou seu substituto legal, convocará asssembleia para decisão do recurso, que se dará
na primeira sessão subsequente à eleição.

```
Capítulo VII
```
```
Da Diplomação
```
**Art. 75** A diplomação dos eleitos para as administrações das lojas será feita pelo Grão-Mestrado no mês de
junho. **(Alterado pela Lei nº 87/2009, art. 11°, 09 de fevereiro de 2009)**

§ 1º O venerável mestre recém diplomado não poderá participar de reunião do COLEGIADO sem antes
tomar posse em sua loja, ex vi do art. 7° do Regulamento Geral do GOSC. **(Renumerado pela Lei nº
154/GOSC/2020-2023, de 24 de abril de 2022)**

§ 2º Na eventualidade de existência de situações excepcionais que impeçam a diplomação ou a transmissão
de cargo e posse dos eleitos em sessão ordinária do Colegiado, esses atos poderão ser realizados, por
delegação, pelos Veneráveis Mestres das Lojas jurisdicionadas que deixam o cargo, desde que sejam
Mestres Instalados, ou pelos Mestres Instalados mais modernos, para diplomação e posse dos Veneráveis
Mestres, Vigilantes e Tesoureiros eleitos para a administração da respectiva Loja. **(Acrescentado pela Lei
nº 154/GOSC/2020-2023, de 24 de abril de 2022)**

**Art. 76** Depois de diplomados, no mesmo dia, ou em dias específicos, os veneráveis mestres eleitos deverão
ser instalados.

```
Capítulo VIII
```
```
Da Vacância
```
**Art. 77** Na vacância de qualquer cargo eletivo, não havendo substituto legal, proceder-se-á ao
preenchimento dentro de 30 (trinta) dias, mediante eleição.

Parágrafo Único O venerável mestre, ou seu substituto legal, dentro do prazo que trata o caput deste artigo,
determinará a expedição de Edital comunicando ao GRÃO-MESTRADO:


## CÓDIGO ELEITORAL

## Lei nº 32/200 4

I - A fixação de prazo de sete dias para a inscrição de candidato(s) ao cargo declarado vago;

II – A reserva de sete dias posteriores para impugnação;

III - A marcação de eleições para os sete dias posteriores ao término do prazo destinado à impugnação.

**Art. 78** Será declarado vago o cargo:

I - Se o eleito, sem motivo justificado, não comparecer à sua posse nem à sessão seguinte;

II - Quando, depois de empossado, o eleito não possuir a frequência exigida pelo regimento interno da loja;

III - Quando qualquer eleito, antes ou após a sua posse, desistir ou renunciar ao respectivo cargo.

Parágrafo Único Quando ocorrer a vacância de qualquer cargo eletivo o adjunto ou substituto legal, se
houver, concluirá o período.

```
Capítulo IX
```
```
Da Reeleição dos Veneráveis Mestres
```
**Art. 79** E admitida a reeleição dos veneráveis mestres de loja apenas por mais um mandato consecutivo.

```
Título VII
```
```
Dos Recursos
```
**Art. 80** Os recursos sobre matéria eleitoral terão efeitos suspensivos.

**Art. 81** Os recursos serão interpostos por petições devidamente fundamentadas, dirigidas à comissão de
conciliação e justiça do COLEGIADO, acompanhadas dos documentos que deverão instruí-las.

Parágrafo Único Protocolada a petição do recurso, dentro de 48 (quarenta e oito) horas serão os autos
conclusos ao GRÃO-MESTRE que, no mesmo prazo, decidirá, fundamentadamente, sobre a sua
admissibilidade.

**Art. 82** O prazo para interposição de recursos será de 15 (quinze) dias, contados da publicação dos
resultados das eleições, os quais deverão ser julgados pelo COLEGIADO após pareceres das comissões de
constituição e legislação e de conciliação e justiça.

Parágrafo Único O prazo para interposição de decurso é preclusivo.

**Art. 83** Recebido o recurso pela Comissão de Conciliação e Justiça, será distribuído, primeiramente, à
Comissão de Constituição e Legislação.

Parágrafo Único Recebido e distribuído o recurso, será cientificado o recorrido para que, por igual prazo,
ofereça, querendo, as suas contra-razões.

**Art. 84** Apresentadas as contra-razões ou decorrido ín albis o prazo legal, os autos serão remetidos à
Comissão de Constituição e Legislação para parecer a ser exarado no prazo de 15 (quinze) dias. Após,
deverão ser devolvidos à Comissão de Conciliação e Justiça, que marcará, intimando as partes, a data da
sessão de julgamento.

Parágrafo Único No caso específico a Comissão de Conciliação e Justiça funcionará com as funções de
Procuradoria-Geral.

**Art. 85** Na Reunião Ordinária do COLEGIADO, transformada em sessão de julgamento, poderão as partes
promover sustentação oral de suas razões, por 15 (quinze) minutos, desde que requeiram até 15 (quinze)
minutos antes de iniciada a respectiva sessão de julgamento.


## CÓDIGO ELEITORAL

## Lei nº 32/200 4

**Art. 86** Realizado o julgamento, a Comissão de Constituição e Justiça terá o prazo de 15 (quinze) dias para
redigir o Acórdão.

**Art. 87** As intimações e citações serão feitas por Registro Postal com AR (Aviso de Recebimento), valendo
para contagem do prazo a data da juntada do AR aos autos, lavrando o secretário da Comissão de
Constituição e Justiça o competente Termo de Juntada.

**Art. 88** Recebidas as contra-razões ou decorrido in albis o prazo legal, os autos serão examinados pela
Comissão de Conciliação e Justiça, cujo parecer será deliberado pelo COLEGIADO na Reunião Ordinária
imediatamente posterior.

```
Título VIII
```
```
Da Desistência, da Renúncia e do Falecimento
```
**Art. 89** Qualquer candidato pode requerer, por petição, antes das eleições para o respectivo pleito, no prazo
estipulado neste Código Eleitoral, o cancelamento do registro de sua candidatura.

**Art. 90** Qualquer candidato pode requerer, por petição, antes de sua posse, a renúncia ao cargo para o qual
foi eleito.

Parágrafo Único Recebida a renúncia, e não havendo substituto legal, processar-se-á o preenchimento do
cargo dentro de 30 (trinta) dias, mediante eleição.

**Art. 91** Ocorrendo o falecimento do candidato, dentro dos últimos 30 (trinta) dias que precederem as
eleições, poderá ocorrer o registro de seu substituto, adiando o GRÃO MESTRADO a data das eleições por
30 (trinta) dias, submetendo essa decisão ao COLEGIADO na reunião Ordinária subseqüente ou, conforme
a gravidade do caso, convocar Reunião Extraordinária.

```
Título IX
```
```
Das Disposições Transitórias, Gerais e Finais
```
**Art. 92** Ocorrendo, após as eleições para os cargos de Grão-Mestre e Grão-Mestre Adjunto, a declaração
de inelegibilidade do(s) Candidato(s) eleito(s) reavisar-se-á nova eleição até 21 (vinte e um) dias após a
publicação ou intimação da decisão transitada em julgado.

**Art. 93** É nula qualquer eleição quando realizada em hora, dia e local diversos dos designados no Edital de
convocação; quando preterida formalidade essencial ao sigilo do sufrágio; ou, quando não observados os
preceitos deste código.

**Art. 94** Incumbe às Lojas deliberar e estabelecer, em conformidade com o seu Regimento Interno, ou por
decisão da maioria dos Mestres Maçons do seu quadro, os procedimentos não especificamente regulados
por este Código, especial, mas não exclusivamente, no tocante a:

I - Sigilo ou não do voto;

II - Procedimentos de segurança para evitar fraudes;

III - Plataforma, aplicativo ou recurso virtual para realização da eleição de forma remota, se esta for a
modalidade de reunião eleita;

IV - Forma e conveniência de apresentação dos planos pelos candidatos. **(Alterado pela Lei nº
154/GOSC/2020-2023, de 24 de abril de 2022)**

**Art. 95** Os crimes eleitorais estão os previstos e tipificados no Código Penal maçônico.

**Art. 96** As ações penais decorrentes de crimes eleitorais estão previstas no Código de Processo Penal
maçônico.


## CÓDIGO ELEITORAL

## Lei nº 32/200 4

**Art. 97** O presente Código Eleitoral poderá ser alterado, no todo ou em parte, por iniciativa do GRÃO-
MESTRADO ou por proposta de, no mínimo, 10% (dez por cento) das lojas jurisdicionadas ao GOSC.

**Art. 98** Para os casos não previstos neste Código Eleitoral serão aplicáveis a legislação maçônica e,
subsidiariamente, a profana.

**Art. 99** Este Código passou a vigorar a partir de sua aprovação pelo COLEGIADO, em 26 de junho do ano
de 2004 da E\V\ cuja publicação será efetuada no Boletim Oficial do GRANDE ORIENTE DE SANTA
CATARINA.

**Art. 100** Ficam revogadas todas as disposições em contrário.


